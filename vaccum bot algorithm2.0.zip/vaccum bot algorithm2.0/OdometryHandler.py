"""
OdometryHandler.py
Handles odometry tracking and visualization for the autonomous navigation system
Uses pygame to display robot position and trajectory on a 20x20 grid
"""

import pygame
import numpy as np
import json
import os
from collections import deque


class OdometryHandler:
    def __init__(self, grid_size=20, cell_size=20, use_keyboard=True):
        """
        Initialize the Odometry Handler
        
        Args:
            grid_size (int): Size of the grid (default: 20x20)
            cell_size (int): Size of each cell in pixels (default: 20, reduced for smaller screens)
            use_keyboard (bool): If True, use keyboard for input; if False, use external sensors
        """
        self.grid_size = grid_size
        self.cell_size = cell_size
        self.use_keyboard = use_keyboard
        
        # Window dimensions (20x20 grid = 400x400 pixels, fits most laptop screens)
        self.window_width = grid_size * cell_size
        self.window_height = grid_size * cell_size
        
        # Robot position (start at center - origin)
        self.robot_x = grid_size // 2  # Grid position (10)
        self.robot_y = grid_size // 2  # Grid position (10)
        self.robot_angle = 0  # Facing direction in degrees (0 = North/Up)
        
        # Origin position (for reference - FIXED in world coordinates)
        self.origin_x = grid_size // 2
        self.origin_y = grid_size // 2
        
        # Grid viewport offset (for infinite expansion)
        self.viewport_offset_x = 0  # Offset in grid units
        self.viewport_offset_y = 0  # Offset in grid units
        
        # Movement history/trajectory
        self.trajectory = deque(maxlen=1000)
        self.trajectory.append((self.robot_x, self.robot_y))
        
        # Colors
        self.COLOR_BACKGROUND = (30, 30, 30)
        self.COLOR_GRID = (60, 60, 60)
        self.COLOR_ORIGIN = (255, 0, 0)  # Red
        self.COLOR_ROBOT = (0, 255, 0)   # Green
        self.COLOR_TRAJECTORY = (100, 100, 255)  # Light blue
        self.COLOR_TEXT = (255, 255, 255)  # White
        self.COLOR_DESTINATION = (0, 255, 0)  # Green for destination path
        
        # Buttons
        self.button_rect = None
        self.button_hovered = False
        
        # Animation for smooth movement
        self.target_x = self.robot_x  # Target position for animation
        self.target_y = self.robot_y
        self.is_animating = False
        # Robot speed: 0.35 cm/ms = 35 cm/s = 3.5 grid units/s (1 grid = 10cm)
        # At 30 FPS: 3.5 / 30 = 0.1167 grid units per frame
        self.animation_speed = 0.1167  # Grid units per frame (matches real robot speed)
        
        # IMU integration for heading
        self.use_imu = True  # If True, use IMU for heading instead of keyboard
        self.imu_handler = None  # Reference to IMUHandler
        
        # Pygame state
        self.screen = None
        self.clock = None
        self.is_initialized = False
        self.font = None
        self.exploration_state = None  # Store exploration state for rendering
        
        # Movement parameters (0.35 cm/ms = 35 cm/s)
        # Assuming each grid cell = 10 cm, movement speed = 3.5 cells/second
        # At 30 FPS: 3.5/30 = 0.1167 cells per frame
        self.move_step = 0.1167  # Grid units per frame (proportional to 0.35 cm/ms)
        self.rotation_step = 15  # Degrees per rotation
        
        # Sensor data (for external odometry when use_keyboard=False)
        self.sensor_data = {
            'left_encoder': 0,
            'right_encoder': 0,
            'imu_heading': 0,
            'velocity': 0
        }
        
        # LIDAR mapping data - stores obstacle map with confidence
        self.obstacle_map = {}  # {(grid_x, grid_y): {'confidence': float, 'time': float, 'observations': int}}
        self.lidar_history_size = 1000  # Limit map size for performance
        
        # Confidence thresholds
        self.CONFIDENCE_OBSTACLE_INCREASE = 40  # Add when obstacle detected
        self.CONFIDENCE_CLEAR_DECREASE = 20     # Subtract when clear detected
        self.CONFIDENCE_RENDER_OBSTACLE = 30    # Render RED if confidence >= 30
        self.CONFIDENCE_RENDER_CLEAR = -10      # Render BLUE if confidence <= -10
        self.CONFIDENCE_PERSISTENT = 50         # High-confidence persistent obstacles (dark red)
        self.CONFIDENCE_MAX = 100               # Cap at +100
        self.CONFIDENCE_MIN = -100              # Cap at -100
        
        # Field of View (FOV) parameters for angle-aware mapping
        self.FOV_ANGLE = 90  # Total FOV: 90° (±45° from heading)
        self.FOV_HALF_ANGLE = 45  # Half FOV for calculations
        
        # Map file path
        self.map_file = "obstacle_map.json"
        
        print(f"[ODOMETRY] Initialized {grid_size}x{grid_size} grid")
        print(f"[ODOMETRY] Keyboard control: {use_keyboard}")
        print(f"[ODOMETRY] Press 'S' to save map, 'L' to load map")
    
    def initialize(self):
        """
        Initialize pygame and create the display window
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            pygame.init()
            self.screen = pygame.display.set_mode((self.window_width, self.window_height))
            pygame.display.set_caption("Odometry - Robot Position Tracking")
            self.clock = pygame.time.Clock()
            self.font = pygame.font.Font(None, 24)
            
            self.is_initialized = True
            print("[ODOMETRY] Pygame initialized successfully!")
            return True
        
        except Exception as e:
            print(f"[ODOMETRY ERROR] Failed to initialize pygame: {e}")
            return False
    
    def update(self, lidar_data=None, exploration_state=None):
        """
        Update odometry based on input source (keyboard or sensors)
        
        Args:
            lidar_data (list): Optional LIDAR view data [T,F,T,...] for mapping
            exploration_state (dict): Optional exploration state for path visualization
        
        Returns:
            dict: Current odometry data
        """
        if not self.is_initialized:
            print("[ODOMETRY ERROR] Not initialized!")
            return None
        
        # Store exploration state for rendering
        self.exploration_state = exploration_state
        
        # Handle pygame events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
            elif event.type == pygame.KEYDOWN:
                # Save map with 'S' key
                if event.key == pygame.K_s:
                    self.save_map()
                # Load map with 'L' key
                elif event.key == pygame.K_l:
                    self.load_map()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                # Check if button clicked
                if self.button_rect and self.button_rect.collidepoint(event.pos):
                    return 'toggle_randomizer'  # Signal to toggle
                elif hasattr(self, 'save_button_rect') and self.save_button_rect.collidepoint(event.pos):
                    self.save_map()
                elif hasattr(self, 'load_button_rect') and self.load_button_rect.collidepoint(event.pos):
                    self.load_map()
            elif event.type == pygame.MOUSEMOTION:
                # Check if hovering over buttons
                if self.button_rect:
                    self.button_hovered = self.button_rect.collidepoint(event.pos)
        
        # Update obstacle map if LIDAR data provided
        if lidar_data is not None:
            self._update_obstacle_map(lidar_data)
        
        # Update heading from IMU if enabled (use real phone heading)
        if self.use_imu and self.imu_handler:
            if self.imu_handler.is_connected:
                imu_heading = self.imu_handler.get_heading(smoothed=True)
                if imu_heading is not None:
                    # ALWAYS use IMU heading (real physical robot orientation)
                    # This overrides any command-based angle updates
                    self.robot_angle = imu_heading
                    # Debug: Print every 30 frames (once per second at 30 FPS)
                    if not hasattr(self, '_imu_frame_count'):
                        self._imu_frame_count = 0
                    self._imu_frame_count += 1
                    if self._imu_frame_count % 30 == 0:
                        print(f"[ODOMETRY] IMU Heading: {imu_heading:.1f}°")
            else:
                # IMU disconnected
                if not hasattr(self, '_imu_warned'):
                    print("[ODOMETRY] WARNING: IMU not connected!")
                    self._imu_warned = True
        
        # Get movement based on input source
        if self.use_keyboard:
            self._handle_keyboard_input()
        else:
            self._handle_sensor_input()
        
        # Update smooth animation
        self._update_animation()
        
        # Render the display
        self._render()
        
        # Control frame rate
        self.clock.tick(30)  # 30 FPS
        
        # Return current odometry data
        return self.get_odometry_data()
    
    def _handle_keyboard_input(self):
        """Handle keyboard input for robot movement (experimental/R&D mode)"""
        keys = pygame.key.get_pressed()
        
        moved = False
        
        # Forward/Backward movement
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            self._move_forward()
            moved = True
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            self._move_backward()
            moved = True
        
        # Rotation - only allow if IMU is NOT being used
        if not self.use_imu:
            if keys[pygame.K_LEFT] or keys[pygame.K_a]:
                self._rotate_left()
                moved = True
            if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
                self._rotate_right()
                moved = True
        
        # Add to trajectory if moved
        if moved:
            self.trajectory.append((self.robot_x, self.robot_y))
    
    def _handle_sensor_input(self):
        """Handle external sensor input for odometry (when use_keyboard=False)"""
        # TODO: Implement sensor-based odometry
        # This will use encoder data, IMU, and other sensors
        # For now, placeholder
        pass
    
    def _update_animation(self):
        """Update smooth animation towards target position"""
        if not self.is_animating:
            return
        
        # Calculate distance to target
        dx = self.target_x - self.robot_x
        dy = self.target_y - self.robot_y
        distance = np.sqrt(dx**2 + dy**2)
        
        # If close enough to target, snap to it
        if distance < 0.01:  # Close enough threshold
            self.robot_x = self.target_x
            self.robot_y = self.target_y
            self.is_animating = False
            self.trajectory.append((self.robot_x, self.robot_y))
            self._update_viewport()
            return
        
        # Move towards target at animation speed
        if distance > 0:
            # Normalize direction and move at animation_speed
            move_distance = min(self.animation_speed, distance)
            self.robot_x += (dx / distance) * move_distance
            self.robot_y += (dy / distance) * move_distance
            self._update_viewport()
    
    def update_from_command(self, command, duration_ms):
        """
        Update odometry based on movement command from Hard_Linker
        Args:
            command (str): 'f', 'b', 'l', 'r', 's' (forward, backward, left, right, stop)
            duration_ms (int): Duration of movement in milliseconds
        """
        SPEED_CM_PER_MS = 0.35  # Robot speed: 0.35 cm/ms
        CM_PER_GRID_CELL = 10.0  # Each grid cell = 10cm in real world
        
        if command == 'f':  # Forward
            distance_cm = SPEED_CM_PER_MS * duration_ms
            distance_grid = distance_cm / CM_PER_GRID_CELL  # Convert cm to grid units
            rad = np.radians(self.robot_angle)
            
            # Set target position for smooth animation
            self.target_x = self.robot_x + distance_grid * np.sin(rad)
            self.target_y = self.robot_y - distance_grid * np.cos(rad)
            self.is_animating = True
            
            print(f"[ODOMETRY] Forward target: {distance_cm:.1f}cm = {distance_grid:.2f} grid units (angle={self.robot_angle:.0f}°)")
            
        elif command == 'b':  # Backward
            distance_cm = SPEED_CM_PER_MS * duration_ms
            distance_grid = distance_cm / CM_PER_GRID_CELL  # Convert cm to grid units
            rad = np.radians(self.robot_angle)
            
            # Set target position for smooth animation
            self.target_x = self.robot_x - distance_grid * np.sin(rad)
            self.target_y = self.robot_y + distance_grid * np.cos(rad)
            self.is_animating = True
            
            print(f"[ODOMETRY] Backward target: {distance_cm:.1f}cm = {distance_grid:.2f} grid units (angle={self.robot_angle:.0f}°)")
            
        elif command == 'l':  # Left turn
            # CRITICAL: Stop any ongoing animation first and clear target
            if self.is_animating:
                self.robot_x = self.target_x
                self.robot_y = self.target_y
                self.is_animating = False
            
            # Clear target to prevent animation from restarting
            self.target_x = self.robot_x
            self.target_y = self.robot_y
            
            # Rotation in place - position does NOT change
            # Note: If IMU is enabled, angle will be overwritten by real heading
            # This is correct - physical robot rotation is tracked by IMU
            rotation_degrees = (duration_ms / 300.0) * 30.0  # 300ms = 30° turn
            
            if not self.use_imu:
                # Only update angle if IMU is disabled (simulation mode)
                self.robot_angle -= rotation_degrees
                self.robot_angle = self.robot_angle % 360
                print(f"[ODOMETRY] Left turn: {rotation_degrees:.1f}° → New angle: {self.robot_angle:.0f}°")
            else:
                print(f"[ODOMETRY] Left turn command sent (IMU will track real rotation)")
            
        elif command == 'r':  # Right turn
            # CRITICAL: Stop any ongoing animation first and clear target
            if self.is_animating:
                self.robot_x = self.target_x
                self.robot_y = self.target_y
                self.is_animating = False
            
            # Clear target to prevent animation from restarting
            self.target_x = self.robot_x
            self.target_y = self.robot_y
            
            # Rotation in place - position does NOT change
            rotation_degrees = (duration_ms / 300.0) * 30.0  # 300ms = 30° turn
            
            if not self.use_imu:
                # Only update angle if IMU is disabled (simulation mode)
                self.robot_angle += rotation_degrees
                self.robot_angle = self.robot_angle % 360
                print(f"[ODOMETRY] Right turn: {rotation_degrees:.1f}° → New angle: {self.robot_angle:.0f}°")
            else:
                print(f"[ODOMETRY] Right turn command sent (IMU will track real rotation)")
            
        elif command == 's':  # Stop - immediately finish any animation
            if self.is_animating:
                # Snap to target position immediately
                self.robot_x = self.target_x
                self.robot_y = self.target_y
                self.is_animating = False
                print(f"[ODOMETRY] Stop command - animation stopped at ({self.robot_x:.2f}, {self.robot_y:.2f})")
    
    def _move_forward(self):
        """Move robot forward in current direction"""
        rad = np.radians(self.robot_angle)
        self.robot_x += self.move_step * np.sin(rad)
        self.robot_y -= self.move_step * np.cos(rad)  # Y decreases going up
        
        # Update viewport if robot approaches edges (infinite grid expansion)
        self._update_viewport()
    
    def _move_backward(self):
        """Move robot backward"""
        rad = np.radians(self.robot_angle)
        self.robot_x -= self.move_step * np.sin(rad)
        self.robot_y += self.move_step * np.cos(rad)
        
        # Update viewport if robot approaches edges (infinite grid expansion)
        self._update_viewport()
    
    def _rotate_left(self):
        """Rotate robot counter-clockwise"""
        self.robot_angle -= self.rotation_step
        self.robot_angle = self.robot_angle % 360
    
    def _rotate_right(self):
        """Rotate robot clockwise"""
        self.robot_angle += self.rotation_step
        self.robot_angle = self.robot_angle % 360
    
    def _update_viewport(self):
        """
        Update viewport offset to keep robot in view (infinite grid expansion)
        Shifts the viewport when robot approaches edges
        """
        # Calculate robot's position relative to current viewport
        viewport_x = self.robot_x - self.viewport_offset_x
        viewport_y = self.robot_y - self.viewport_offset_y
        
        # Define edge threshold (when to start shifting viewport)
        edge_threshold = 3  # Shift when within 3 cells of edge
        
        # Shift viewport right if robot approaches right edge
        if viewport_x > (self.grid_size - edge_threshold):
            shift = viewport_x - (self.grid_size - edge_threshold)
            self.viewport_offset_x += shift
        
        # Shift viewport left if robot approaches left edge
        elif viewport_x < edge_threshold:
            shift = edge_threshold - viewport_x
            self.viewport_offset_x -= shift
        
        # Shift viewport down if robot approaches bottom edge
        if viewport_y > (self.grid_size - edge_threshold):
            shift = viewport_y - (self.grid_size - edge_threshold)
            self.viewport_offset_y += shift
        
        # Shift viewport up if robot approaches top edge
        elif viewport_y < edge_threshold:
            shift = edge_threshold - viewport_y
            self.viewport_offset_y -= shift
    
    def _is_cell_in_fov(self, cell_x, cell_y):
        """
        Check if a cell is within robot's field of view (FOV)
        FOV is 90° cone (±45° from robot heading)
        
        Args:
            cell_x (float): Cell X coordinate in world
            cell_y (float): Cell Y coordinate in world
        
        Returns:
            bool: True if cell is in FOV, False otherwise
        """
        # Calculate vector from robot to cell
        dx = cell_x - self.robot_x
        dy = cell_y - self.robot_y
        
        # Calculate angle from robot to cell (in degrees)
        angle_to_cell = np.degrees(np.arctan2(dx, -dy))
        
        # Calculate angle difference
        angle_diff = (angle_to_cell - self.robot_angle + 360) % 360
        if angle_diff > 180:
            angle_diff -= 360
        
        # Check if within FOV (±45°)
        return abs(angle_diff) <= self.FOV_HALF_ANGLE
    
    def _update_obstacle_map(self, lidar_data):
        """
        Update obstacle map with correct LIDAR-to-grid mapping
        
        LIDAR Structure (5 rows x 10 columns):
        - Rows c-g: Different distances (c=farthest ~3 units, g=nearest ~1 unit)
        - Columns 1-10: Horizontal left-to-right spread (±45° FOV)
        
        Mapping logic:
        - Each column maps to angular offset: column_idx → angle
        - Row voting already done by DepthEstimation (uses first row of corrected_array)
        - Distance based on obstacle detection patterns
        
        Args:
            lidar_data (list): List of 10 booleans [T,F,T,...] from LIDAR view
        """
        import time
        
        # Only update if we have valid LIDAR data
        if not lidar_data or len(lidar_data) != 10:
            return
        
        current_time = time.time()
        
        # Step 1: Update cells that are currently being observed (in FOV)
        observed_cells = set()
        
        # LIDAR has 90° FOV (-45° to +45°) divided into 10 columns
        # Each column covers 9° of view
        fov_total = 90.0  # Total field of view in degrees
        angle_per_column = fov_total / 10  # 9° per column
        
        # For each LIDAR column (10 columns = left to right)
        for col_idx, has_obstacle in enumerate(lidar_data):
            # Calculate angular offset for this column
            # Column 0 = -45°, Column 5 = 0° (center), Column 9 = +45°
            column_angle_offset = -45 + (col_idx * angle_per_column)
            absolute_angle = self.robot_angle + column_angle_offset
            
            # Distance mapping: If obstacle detected, place at ~2 grid units ahead
            # (Rows c-g represent detection zones, voting picks closest)
            if has_obstacle:
                projection_distance = 2.0  # Obstacle detected - 2 grid units
            else:
                projection_distance = 3.0  # Clear - mark farther cell as clear
            
            # Calculate world position
            rad = np.radians(absolute_angle)
            map_x = self.robot_x + projection_distance * np.sin(rad)
            map_y = self.robot_y - projection_distance * np.cos(rad)
            
            # Round to grid cell
            grid_x = int(round(map_x))
            grid_y = int(round(map_y))
            cell_key = (grid_x, grid_y)
            observed_cells.add(cell_key)
            
            # Calculate distance from robot to cell
            distance = np.sqrt((grid_x - self.robot_x)**2 + (grid_y - self.robot_y)**2)
            
            # Initialize cell if not exists
            if cell_key not in self.obstacle_map:
                self.obstacle_map[cell_key] = {
                    'confidence': 0.0,
                    'time': current_time,
                    'observations': 0,
                    'distance': distance,
                    'detection_angle': self.robot_angle
                }
            
            # Update confidence based on observation
            if has_obstacle:
                # Obstacle detected - increase confidence
                self.obstacle_map[cell_key]['confidence'] += self.CONFIDENCE_OBSTACLE_INCREASE
                # Cap at max
                self.obstacle_map[cell_key]['confidence'] = min(
                    self.CONFIDENCE_MAX, 
                    self.obstacle_map[cell_key]['confidence']
                )
                # Update distance and angle on obstacle detection
                self.obstacle_map[cell_key]['distance'] = distance
                self.obstacle_map[cell_key]['detection_angle'] = self.robot_angle
            else:
                # Clear detected - decrease confidence (only if in FOV)
                self.obstacle_map[cell_key]['confidence'] -= self.CONFIDENCE_CLEAR_DECREASE
                # Cap at min
                self.obstacle_map[cell_key]['confidence'] = max(
                    self.CONFIDENCE_MIN, 
                    self.obstacle_map[cell_key]['confidence']
                )
            
            # Update metadata
            self.obstacle_map[cell_key]['time'] = current_time
            self.obstacle_map[cell_key]['observations'] += 1
        
        # Step 2: Check existing map cells NOT currently observed
        # Only decay if they SHOULD be visible (in FOV) but aren't detected
        for cell_key, cell_data in list(self.obstacle_map.items()):
            if cell_key not in observed_cells:
                # Cell not directly observed this frame
                # Check if it's in the robot's FOV
                if self._is_cell_in_fov(cell_key[0], cell_key[1]):
                    # Cell IS in FOV but not detected by any LIDAR zone
                    # This means it should be clear (was obstacle, now gone)
                    # Apply gentle decay for persistent obstacles
                    if cell_data['confidence'] > 0:
                        # Positive confidence (was obstacle) - gentle decay
                        cell_data['confidence'] -= 5  # Gentle decay (not full 20)
                        cell_data['time'] = current_time
                # else: Cell not in FOV - PRESERVE confidence (robot can't see it)
        
        # Limit map size to prevent memory overflow
        if len(self.obstacle_map) > self.lidar_history_size:
            # Remove cells with lowest absolute confidence (most uncertain)
            sorted_cells = sorted(
                self.obstacle_map.items(),
                key=lambda x: abs(x[1]['confidence'])
            )
            # Remove lowest 20%
            remove_count = len(self.obstacle_map) // 5
            for key, _ in sorted_cells[:remove_count]:
                del self.obstacle_map[key]
    
    def _draw_obstacle_map(self):
        """
        Draw the obstacle map with angle-aware persistent rendering
        Dark Red = Persistent high-confidence obstacle (>= 50)
        Red = Recent obstacle (30-49)
        Blue = High confidence clear (<= -10)
        Orange = Low confidence obstacle (in FOV, uncertain)
        (No render for out-of-FOV or very uncertain)
        """
        # Only draw cells visible in current viewport
        for (map_x, map_y), cell_data in self.obstacle_map.items():
            # Convert world coordinates to viewport coordinates
            viewport_x = map_x - self.viewport_offset_x
            viewport_y = map_y - self.viewport_offset_y
            
            # Only draw if in visible viewport
            if (0 <= viewport_x < self.grid_size and 
                0 <= viewport_y < self.grid_size):
                
                # Calculate pixel position
                px = int(viewport_x * self.cell_size)
                py = int(viewport_y * self.cell_size)
                
                # Get confidence
                confidence = cell_data['confidence']
                
                # Choose color based on confidence tiers
                if confidence >= self.CONFIDENCE_PERSISTENT:
                    # Tier 1: Persistent high-confidence obstacle - DARK RED
                    color = (180, 0, 0, 150)  # Dark red, higher opacity
                elif confidence >= self.CONFIDENCE_RENDER_OBSTACLE:
                    # Tier 2: Recent obstacle - BRIGHT RED
                    color = (255, 0, 0, 120)  # Bright red
                elif confidence <= self.CONFIDENCE_RENDER_CLEAR:
                    # Confirmed clear path - BLUE
                    color = (0, 0, 255, 120)  # Blue
                elif 10 <= confidence < self.CONFIDENCE_RENDER_OBSTACLE:
                    # Low confidence obstacle (uncertain) - ORANGE
                    color = (255, 165, 0, 80)  # Orange with low transparency
                else:
                    # Very uncertain or negative - don't render
                    continue
                
                # Draw semi-transparent rectangle
                s = pygame.Surface((self.cell_size, self.cell_size))
                s.set_alpha(color[3])  # Use alpha from color
                s.fill(color[:3])
                self.screen.blit(s, (px, py))
    
    def _draw_exploration_path(self):
        """
        Draw the exploration path (green dotted line to destination)
        """
        if not self.exploration_state or not self.exploration_state.get('has_destination'):
            return
        
        path_points = self.exploration_state.get('path_points', [])
        if len(path_points) < 2:
            return
        
        # Convert world coordinates to viewport coordinates
        viewport_points = []
        for x, y in path_points:
            viewport_x = x - self.viewport_offset_x
            viewport_y = y - self.viewport_offset_y
            
            # Only include points visible in viewport
            if (0 <= viewport_x < self.grid_size and 
                0 <= viewport_y < self.grid_size):
                
                px = int(viewport_x * self.cell_size + self.cell_size / 2)
                py = int(viewport_y * self.cell_size + self.cell_size / 2)
                viewport_points.append((px, py))
        
        # Draw dotted line (green)
        if len(viewport_points) >= 2:
            # Draw every other segment for dotted effect
            for i in range(0, len(viewport_points) - 1, 2):
                pygame.draw.line(self.screen, self.COLOR_DESTINATION,
                               viewport_points[i], viewport_points[i+1], 2)
    
    def _draw_line_to_destination(self):
        """
        Draw line from robot to destination point
        """
        if not self.exploration_state or not self.exploration_state.get('has_destination'):
            return
        
        destination = self.exploration_state.get('destination')
        if not destination:
            return
        
        dest_x, dest_y = destination
        
        # Convert robot position to viewport
        robot_viewport_x = self.robot_x - self.viewport_offset_x
        robot_viewport_y = self.robot_y - self.viewport_offset_y
        
        # Convert destination to viewport
        dest_viewport_x = dest_x - self.viewport_offset_x
        dest_viewport_y = dest_y - self.viewport_offset_y
        
        # Calculate pixel positions
        robot_px = int(robot_viewport_x * self.cell_size + self.cell_size / 2)
        robot_py = int(robot_viewport_y * self.cell_size + self.cell_size / 2)
        dest_px = int(dest_viewport_x * self.cell_size + self.cell_size / 2)
        dest_py = int(dest_viewport_y * self.cell_size + self.cell_size / 2)
        
        # Draw dashed line from robot to destination (cyan color)
        import math
        dx = dest_px - robot_px
        dy = dest_py - robot_py
        distance = math.sqrt(dx**2 + dy**2)
        
        if distance > 0:
            # Draw dashed line
            dash_length = 10
            gap_length = 5
            num_dashes = int(distance / (dash_length + gap_length))
            
            for i in range(num_dashes):
                start_ratio = i * (dash_length + gap_length) / distance
                end_ratio = (i * (dash_length + gap_length) + dash_length) / distance
                
                if end_ratio > 1.0:
                    end_ratio = 1.0
                
                start_x = int(robot_px + dx * start_ratio)
                start_y = int(robot_py + dy * start_ratio)
                end_x = int(robot_px + dx * end_ratio)
                end_y = int(robot_py + dy * end_ratio)
                
                pygame.draw.line(self.screen, (0, 255, 255), (start_x, start_y), (end_x, end_y), 2)
    
    def _draw_destination(self):
        """
        Draw the destination point (green circle)
        """
        if not self.exploration_state or not self.exploration_state.get('has_destination'):
            return
        
        destination = self.exploration_state.get('destination')
        if not destination:
            return
        
        dest_x, dest_y = destination
        
        # Convert to viewport coordinates
        viewport_x = dest_x - self.viewport_offset_x
        viewport_y = dest_y - self.viewport_offset_y
        
        # Only draw if in visible viewport
        if (0 <= viewport_x < self.grid_size and 
            0 <= viewport_y < self.grid_size):
            
            center_x = int(viewport_x * self.cell_size + self.cell_size / 2)
            center_y = int(viewport_y * self.cell_size + self.cell_size / 2)
            
            # Draw destination marker (green circle with white outline)
            pygame.draw.circle(self.screen, (255, 255, 255), (center_x, center_y), 8)
            pygame.draw.circle(self.screen, self.COLOR_DESTINATION, (center_x, center_y), 6)
    
    def _draw_ui_buttons(self):
        """
        Draw UI buttons (Randomizer toggle, AUTO mode, Save, Load)
        """
        # Button dimensions
        button_width = 120
        button_height = 35
        button_margin = 10
        
        # Calculate positions (bottom of screen)
        y_pos = self.window_height - button_height - button_margin
        
        # Randomizer button (bottom left)
        randomizer_x = button_margin
        self.button_rect = pygame.Rect(randomizer_x, y_pos, button_width, button_height)
        
        # Determine button state
        is_enabled = self.exploration_state and self.exploration_state.get('randomizer_enabled', False)
        
        # Button colors
        if is_enabled:
            button_color = (0, 150, 0)  # Green when ON
            text_label = "Explorer: ON"
        else:
            button_color = (100, 100, 100)  # Gray when OFF
            text_label = "Explorer: OFF"
        
        # Hover effect
        if self.button_hovered:
            button_color = tuple(min(c + 30, 255) for c in button_color)
        
        # Draw button background
        pygame.draw.rect(self.screen, button_color, self.button_rect, border_radius=5)
        pygame.draw.rect(self.screen, (200, 200, 200), self.button_rect, 2, border_radius=5)
        
        # Draw button text
        button_font = pygame.font.Font(None, 22)
        text_surface = button_font.render(text_label, True, (255, 255, 255))
        text_rect = text_surface.get_rect(center=self.button_rect.center)
        self.screen.blit(text_surface, text_rect)
        
        # Save button (after Explorer)
        save_x = randomizer_x + button_width + button_margin
        save_button = pygame.Rect(save_x, y_pos, 70, button_height)
        pygame.draw.rect(self.screen, (50, 50, 150), save_button, border_radius=5)
        pygame.draw.rect(self.screen, (200, 200, 200), save_button, 2, border_radius=5)
        
        save_text = button_font.render("Save", True, (255, 255, 255))
        save_text_rect = save_text.get_rect(center=save_button.center)
        self.screen.blit(save_text, save_text_rect)
        
        # Load button (next to save)
        load_x = save_x + 70 + button_margin
        load_button = pygame.Rect(load_x, y_pos, 70, button_height)
        pygame.draw.rect(self.screen, (150, 50, 50), load_button, border_radius=5)
        pygame.draw.rect(self.screen, (200, 200, 200), load_button, 2, border_radius=5)
        
        load_text = button_font.render("Load", True, (255, 255, 255))
        load_text_rect = load_text.get_rect(center=load_button.center)
        self.screen.blit(load_text, load_text_rect)
        
        # Store button rects for click detection
        self.save_button_rect = save_button
        self.load_button_rect = load_button
    
    def _render(self):
        """Render the odometry visualization"""
        # Clear screen
        self.screen.fill(self.COLOR_BACKGROUND)
        
        # Draw obstacle map (LIDAR data)
        self._draw_obstacle_map()
        
        # Draw grid
        self._draw_grid()
        
        # Draw exploration path (green dotted line) - before trajectory
        if self.exploration_state:
            self._draw_exploration_path()
        
        # Draw trajectory
        self._draw_trajectory()
        
        # Draw origin marker
        self._draw_origin()
        
        # Draw robot
        self._draw_robot()
        
        # Draw line from robot to destination
        if self.exploration_state and self.exploration_state.get('has_destination'):
            self._draw_line_to_destination()
        
        # Draw destination point
        if self.exploration_state:
            self._draw_destination()
        
        # Draw UI buttons
        self._draw_ui_buttons()
        
        # Draw info overlay
        self._draw_info()
        
        # Update display
        pygame.display.flip()
    
    def _draw_grid(self):
        """Draw the grid lines with labels for visible viewport"""
        for i in range(self.grid_size + 1):
            # Vertical lines
            x = i * self.cell_size
            pygame.draw.line(self.screen, self.COLOR_GRID, 
                           (x, 0), (x, self.window_height), 1)
            
            # Horizontal lines
            y = i * self.cell_size
            pygame.draw.line(self.screen, self.COLOR_GRID, 
                           (0, y), (self.window_width, y), 1)
    
    def _draw_origin(self):
        """Draw the origin marker (red dot at fixed world position)"""
        # Calculate origin position in viewport coordinates
        viewport_origin_x = self.origin_x - self.viewport_offset_x
        viewport_origin_y = self.origin_y - self.viewport_offset_y
        
        # Only draw if origin is visible in current viewport
        if (0 <= viewport_origin_x < self.grid_size and 
            0 <= viewport_origin_y < self.grid_size):
            
            center_x = int(viewport_origin_x * self.cell_size + self.cell_size / 2)
            center_y = int(viewport_origin_y * self.cell_size + self.cell_size / 2)
        
            # Draw red circle for origin
            pygame.draw.circle(self.screen, self.COLOR_ORIGIN, 
                              (center_x, center_y), 5)
            
            # Draw cross marker
            cross_size = 10
            pygame.draw.line(self.screen, self.COLOR_ORIGIN,
                            (center_x - cross_size, center_y),
                            (center_x + cross_size, center_y), 2)
            pygame.draw.line(self.screen, self.COLOR_ORIGIN,
                            (center_x, center_y - cross_size),
                            (center_x, center_y + cross_size), 2)
    
    def _draw_trajectory(self):
        """Draw the robot's trajectory path (only visible portion)"""
        if len(self.trajectory) < 2:
            return
        
        points = []
        for x, y in self.trajectory:
            # Convert world coordinates to viewport coordinates
            viewport_x = x - self.viewport_offset_x
            viewport_y = y - self.viewport_offset_y
            
            # Only add points that are visible in current viewport
            if (0 <= viewport_x < self.grid_size and 
                0 <= viewport_y < self.grid_size):
                
                px = int(viewport_x * self.cell_size + self.cell_size / 2)
                py = int(viewport_y * self.cell_size + self.cell_size / 2)
                points.append((px, py))
        
        # Draw trajectory line
        if len(points) >= 2:
            pygame.draw.lines(self.screen, self.COLOR_TRAJECTORY, 
                            False, points, 2)
    
    def _draw_robot(self):
        """Draw the robot (green circle with direction indicator)"""
        # Convert robot world position to viewport coordinates
        viewport_x = self.robot_x - self.viewport_offset_x
        viewport_y = self.robot_y - self.viewport_offset_y
        
        center_x = int(viewport_x * self.cell_size + self.cell_size / 2)
        center_y = int(viewport_y * self.cell_size + self.cell_size / 2)
        
        # Draw robot body (circle)
        pygame.draw.circle(self.screen, self.COLOR_ROBOT, 
                          (center_x, center_y), 8)
        
        # Draw direction indicator (line showing where robot is facing)
        indicator_length = 15
        rad = np.radians(self.robot_angle)
        end_x = int(center_x + indicator_length * np.sin(rad))
        end_y = int(center_y - indicator_length * np.cos(rad))
        
        pygame.draw.line(self.screen, (255, 255, 0),  # Yellow
                        (center_x, center_y), (end_x, end_y), 3)
    
    def _draw_info(self):
        """Draw information overlay (only useful info: position and angle)"""
        info_lines = [
            f"Position: ({self.robot_x:.2f}, {self.robot_y:.2f})",
            f"Angle: {self.robot_angle:.1f}°"
        ]
        
        y_offset = 10
        for line in info_lines:
            text_surface = self.font.render(line, True, self.COLOR_TEXT)
            self.screen.blit(text_surface, (10, y_offset))
            y_offset += 25
    
    def get_odometry_data(self):
        """
        Get current odometry data
        
        Returns:
            dict: Current position, angle, and displacement from origin
        """
        # Calculate displacement from origin
        dx = self.robot_x - self.origin_x
        dy = self.robot_y - self.origin_y
        distance_from_origin = np.sqrt(dx**2 + dy**2)
        
        return {
            'x': self.robot_x,
            'y': self.robot_y,
            'angle': self.robot_angle,
            'origin_x': self.origin_x,
            'origin_y': self.origin_y,
            'dx': dx,
            'dy': dy,
            'distance_from_origin': distance_from_origin,
            'trajectory_length': len(self.trajectory),
            'mapped_cells': len(self.obstacle_map)
        }
    
    def reset_position(self):
        """Reset robot to origin"""
        self.robot_x = self.origin_x
        self.robot_y = self.origin_y
        self.robot_angle = 0
        self.trajectory.clear()
        self.trajectory.append((self.robot_x, self.robot_y))
        print("[ODOMETRY] Position reset to origin")
    
    def clear_obstacle_map(self):
        """Clear the obstacle map"""
        self.obstacle_map.clear()
        print("[ODOMETRY] Obstacle map cleared")
    
    def save_map(self, filename=None):
        """
        Save obstacle map to JSON file (confidence-based format)
        
        Args:
            filename (str): Optional custom filename
        """
        if filename is None:
            filename = self.map_file
        
        try:
            # Convert tuple keys to string for JSON serialization
            serializable_map = {f"{x},{y}": value 
                               for (x, y), value in self.obstacle_map.items()}
            
            map_data = {
                'obstacle_map': serializable_map,
                'robot_position': {
                    'x': self.robot_x,
                    'y': self.robot_y,
                    'angle': self.robot_angle
                },
                'origin': {
                    'x': self.origin_x,
                    'y': self.origin_y
                },
                'map_size': len(self.obstacle_map),
                'format_version': 'confidence_v1'  # Mark as confidence-based format
            }
            
            with open(filename, 'w') as f:
                json.dump(map_data, f, indent=2)
            
            print(f"[ODOMETRY] Map saved to {filename} ({len(self.obstacle_map)} cells, confidence-based)")
        
        except Exception as e:
            print(f"[ODOMETRY ERROR] Failed to save map: {e}")
    
    def load_map(self, filename=None):
        """
        Load obstacle map from JSON file (handles both old boolean and new confidence formats)
        
        Args:
            filename (str): Optional custom filename
        """
        if filename is None:
            filename = self.map_file
        
        if not os.path.exists(filename):
            print(f"[ODOMETRY WARNING] Map file not found: {filename}")
            return False
        
        try:
            with open(filename, 'r') as f:
                map_data = json.load(f)
            
            # Check format version
            is_confidence_format = map_data.get('format_version') == 'confidence_v1'
            
            # Convert string keys back to tuple
            loaded_map = {}
            for key, value in map_data['obstacle_map'].items():
                tuple_key = tuple(map(int, key.split(',')))
                
                if is_confidence_format or isinstance(value, dict):
                    # New confidence format
                    loaded_map[tuple_key] = value
                else:
                    # Old boolean format - convert to confidence
                    import time
                    if value:  # Was True (obstacle)
                        loaded_map[tuple_key] = {'confidence': 60.0, 'time': time.time(), 'observations': 2}
                    else:  # Was False (clear)
                        loaded_map[tuple_key] = {'confidence': -30.0, 'time': time.time(), 'observations': 2}
            
            self.obstacle_map = loaded_map
            
            # Optionally restore robot position
            # Uncomment if you want to restore position too
            # self.robot_x = map_data['robot_position']['x']
            # self.robot_y = map_data['robot_position']['y']
            # self.robot_angle = map_data['robot_position']['angle']
            
            format_str = "confidence-based" if is_confidence_format else "legacy (converted)"
            print(f"[ODOMETRY] Map loaded from {filename} ({len(self.obstacle_map)} cells, {format_str})")
            return True
        
        except Exception as e:
            print(f"[ODOMETRY ERROR] Failed to load map: {e}")
            return False
    
    def set_external_odometry(self, x=None, y=None, angle=None):
        """
        Set robot position from external sensors (when use_keyboard=False)
        
        Args:
            x (float): X position
            y (float): Y position
            angle (float): Heading angle in degrees
        """
        if not self.use_keyboard:
            if x is not None:
                self.robot_x = x
            if y is not None:
                self.robot_y = y
            if angle is not None:
                self.robot_angle = angle
            
            self.trajectory.append((self.robot_x, self.robot_y))
    
    def toggle_input_mode(self):
        """Toggle between keyboard and sensor input modes"""
        self.use_keyboard = not self.use_keyboard
        mode = "KEYBOARD" if self.use_keyboard else "SENSOR"
        print(f"[ODOMETRY] Input mode switched to: {mode}")
    
    def cleanup(self):
        """Cleanup pygame resources"""
        if self.is_initialized:
            pygame.quit()
            self.is_initialized = False
            print("[ODOMETRY] Cleanup complete")
