#!/usr/bin/env python3
"""
IMU Handler - Android Sensor Server Integration
================================================
Reads heading/orientation from Android phone via WebSocket
for accurate robot heading in vacuum bot navigation system

Sensor Server App: https://play.google.com/store/apps/details?id=de.lorenz_fenster.sensorstreamserver
"""

import asyncio
import websockets
import json
import math
import threading
from collections import deque
import time


class IMUHandler:
    def __init__(self, android_ip="192.168.1.100", port=8080, sensor_type="orientation"):
        """
        Initialize IMU Handler for Android Sensor Server
        
        Args:
            android_ip (str): IP address of Android phone
            port (int): WebSocket port (default: 8080)
            sensor_type (str): 'orientation' or 'rotation_vector'
        """
        self.android_ip = android_ip
        self.port = port
        self.sensor_type = sensor_type
        
        # WebSocket URL
        if sensor_type == "orientation":
            self.ws_url = f"ws://{android_ip}:{port}/sensor/connect?type=android.sensor.orientation"
        elif sensor_type == "rotation_vector":
            self.ws_url = f"ws://{android_ip}:{port}/sensor/connect?type=android.sensor.rotation_vector"
        else:
            raise ValueError(f"Unknown sensor type: {sensor_type}")
        
        # Current sensor data
        self.heading = 0.0  # Current heading in degrees (0-360)
        self.pitch = 0.0    # Pitch angle
        self.roll = 0.0     # Roll angle
        self.is_connected = False
        
        # Heading history for smoothing
        self.heading_history = deque(maxlen=10)
        
        # Threading
        self.running = False
        self.thread = None
        self.loop = None
        
        print(f"[IMU] Initialized for {android_ip}:{port}")
        print(f"[IMU] Sensor type: {sensor_type}")
    
    def start(self):
        """Start the IMU handler in background thread"""
        if self.running:
            print("[IMU] Already running!")
            return False
        
        self.running = True
        self.thread = threading.Thread(target=self._run_async_loop, daemon=True)
        self.thread.start()
        
        print(f"[IMU] Starting connection to {self.ws_url}")
        
        # Wait for connection
        timeout = 5
        start_time = time.time()
        while not self.is_connected and (time.time() - start_time) < timeout:
            time.sleep(0.1)
        
        if self.is_connected:
            print("[IMU] ✓ Connected to Android Sensor Server")
            return True
        else:
            print("[IMU] ✗ Connection timeout")
            return False
    
    def _run_async_loop(self):
        """Run asyncio event loop in thread"""
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.loop.run_until_complete(self._connect_and_read())
    
    async def _connect_and_read(self):
        """Connect to WebSocket and continuously read sensor data"""
        retry_count = 0
        max_retries = 3
        
        while self.running and retry_count < max_retries:
            try:
                async with websockets.connect(self.ws_url) as websocket:
                    self.is_connected = True
                    print("[IMU] WebSocket connected")
                    
                    # Read sensor data continuously
                    async for message in websocket:
                        if not self.running:
                            break
                        
                        try:
                            data = json.loads(message)
                            
                            if 'values' in data:
                                self._process_sensor_data(data['values'])
                        
                        except json.JSONDecodeError:
                            print(f"[IMU] Invalid JSON: {message}")
                        except Exception as e:
                            print(f"[IMU] Error processing data: {e}")
            
            except websockets.exceptions.WebSocketException as e:
                self.is_connected = False
                retry_count += 1
                print(f"[IMU] Connection error (attempt {retry_count}/{max_retries}): {e}")
                
                if retry_count < max_retries:
                    await asyncio.sleep(2)  # Wait before retry
            
            except Exception as e:
                self.is_connected = False
                print(f"[IMU] Unexpected error: {e}")
                break
        
        self.is_connected = False
        print("[IMU] Connection closed")
    
    def _process_sensor_data(self, values):
        """
        Process sensor data based on sensor type
        
        Args:
            values (list): Sensor values from Android
        """
        if self.sensor_type == "orientation":
            # Orientation sensor: [azimuth, pitch, roll]
            if len(values) >= 3:
                self.heading = values[0]  # Azimuth (0-360°)
                self.pitch = values[1]
                self.roll = values[2]
                
                # Add to history for smoothing
                self.heading_history.append(self.heading)
        
        elif self.sensor_type == "rotation_vector":
            # Rotation vector: [x, y, z, w] (quaternion)
            if len(values) >= 4:
                x, y, z, w = values[0], values[1], values[2], values[3]
                
                # Convert quaternion to Euler angles (heading)
                # Heading (yaw) = atan2(2*(w*z + x*y), 1 - 2*(y^2 + z^2))
                heading_rad = math.atan2(2*(w*z + x*y), 1 - 2*(y**2 + z**2))
                self.heading = math.degrees(heading_rad)
                
                # Normalize to 0-360
                if self.heading < 0:
                    self.heading += 360
                
                # Calculate pitch and roll
                pitch_rad = math.asin(2*(w*y - z*x))
                roll_rad = math.atan2(2*(w*x + y*z), 1 - 2*(x**2 + y**2))
                
                self.pitch = math.degrees(pitch_rad)
                self.roll = math.degrees(roll_rad)
                
                # Add to history
                self.heading_history.append(self.heading)
    
    def get_heading(self, smoothed=True):
        """
        Get current heading
        
        Args:
            smoothed (bool): If True, return averaged heading from history
        
        Returns:
            float: Heading in degrees (0-360)
        """
        if not self.is_connected:
            return None
        
        if smoothed and len(self.heading_history) > 0:
            # Return average of recent headings
            return sum(self.heading_history) / len(self.heading_history)
        else:
            return self.heading
    
    def get_orientation(self):
        """
        Get complete orientation data
        
        Returns:
            dict: {'heading': float, 'pitch': float, 'roll': float, 'connected': bool}
        """
        return {
            'heading': self.heading,
            'pitch': self.pitch,
            'roll': self.roll,
            'connected': self.is_connected
        }
    
    def stop(self):
        """Stop the IMU handler"""
        print("[IMU] Stopping...")
        self.running = False
        self.is_connected = False
        
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=2)
        
        print("[IMU] Stopped")
    
    def test_connection(self):
        """Test connection to Android sensor server"""
        print("[IMU] Testing connection...")
        
        if self.start():
            print(f"[IMU] ✓ Connection successful!")
            print(f"[IMU] Current heading: {self.get_heading():.1f}°")
            return True
        else:
            print("[IMU] ✗ Connection failed")
            print("\nTroubleshooting:")
            print("1. Ensure Sensor Server app is running on Android")
            print("2. Check IP address matches your phone")
            print("3. Verify phone and PC are on same WiFi network")
            return False


# Test code
if __name__ == '__main__':
    print("=" * 60)
    print("IMU Handler Test")
    print("=" * 60)
    print()
    
    # Get Android IP from user
    android_ip = input("Enter Android IP address (default: 192.168.1.100): ").strip()
    if not android_ip:
        android_ip = "192.168.1.100"
    
    # Create IMU handler
    imu = IMUHandler(android_ip=android_ip, sensor_type="orientation")
    
    try:
        # Start connection
        if imu.start():
            print("\n" + "=" * 60)
            print("Reading heading data (Ctrl+C to stop)...")
            print("=" * 60)
            
            # Read heading continuously
            while True:
                if imu.is_connected:
                    orientation = imu.get_orientation()
                    print(f"Heading: {orientation['heading']:6.1f}° | "
                          f"Pitch: {orientation['pitch']:6.1f}° | "
                          f"Roll: {orientation['roll']:6.1f}°", end='\r')
                else:
                    print("Disconnected... ", end='\r')
                
                time.sleep(0.1)
        else:
            print("Failed to connect to Android sensor server")
    
    except KeyboardInterrupt:
        print("\n\nStopping...")
    
    finally:
        imu.stop()
