#!/usr/bin/env python3
"""
Unified Raspberry Pi Server
============================
Combines camera streaming and serial communication with Arduino Mega into one server.

Features:
1. Camera Stream - High-speed video streaming (320x240 @ 30 FPS)
2. Serial Communication - Send/receive commands to/from Arduino Mega
3. Unified HTTP API - Single server for all operations

GPIO Pins Used:
- GPIO 14 (Pin 8)  - TXD (Transmit) - Connect to Arduino RX1
- GPIO 15 (Pin 10) - RXD (Receive)  - Connect to Arduino TX1

Camera:
- Raspberry Pi Camera Module v2/v3 or compatible
- Uses rpicam-vid for high-performance streaming

Endpoints:
- GET  /                  - Web interface with camera view
- GET  /video_feed        - Camera stream (MJPEG) - legacy continuous stream
- GET  /get_frame         - Get single frame on-demand (ACK-based)
- GET  /single_image      - Single frame capture (legacy)
- POST /send              - Send command to Arduino
- GET  /read              - Read data from Arduino
- GET  /status            - Server & hardware status
- POST /close             - Close serial connection
"""

from flask import Flask, request, jsonify, Response, render_template_string
import serial
import logging
from datetime import datetime
import json
import io
import time
import subprocess
import threading

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)

# ============================================
# SERIAL COMMUNICATION SETUP
# ============================================

SERIAL_PORT = '/dev/serial0'  # GPIO 14 (TX) and GPIO 15 (RX)
BAUD_RATE = 9600
TIMEOUT = 1

# Initialize serial connection
try:
    ser = serial.Serial(
        port=SERIAL_PORT,
        baudrate=BAUD_RATE,
        timeout=TIMEOUT,
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        bytesize=serial.EIGHTBITS
    )
    logger.info(f"✓ Serial port {SERIAL_PORT} initialized successfully")
    logger.info(f"✓ Using GPIO 14 (TXD) and GPIO 15 (RXD) for UART communication")
except serial.SerialException as e:
    logger.error(f"✗ Failed to open serial port: {e}")
    ser = None

# ============================================
# CAMERA STREAMING SETUP
# ============================================

class CameraStreamer:
    def __init__(self, width=320, height=240, fps=30):
        self.width = width
        self.height = height
        self.fps = fps
        self.running = False
        self.current_frame = None
        self.lock = threading.Lock()
        self.rpicam_process = None
        self.ffmpeg_process = None
        
    def start_streaming(self):
        """Start the camera streaming using rpicam-vid"""
        self.running = True
        self.stream_thread = threading.Thread(target=self._stream_loop, daemon=True)
        self.stream_thread.start()
        logger.info("✓ Camera streaming thread started")
    
    def stop_streaming(self):
        """Stop the camera streaming"""
        self.running = False
        if self.ffmpeg_process:
            self.ffmpeg_process.terminate()
        if self.rpicam_process:
            self.rpicam_process.terminate()
        logger.info("✓ Camera streaming stopped")
    
    def _stream_loop(self):
        """Main streaming loop using rpicam-vid + ffmpeg for high FPS"""
        logger.info("Starting high-speed H.264 to MJPEG streaming...")
        try:
            # Use rpicam-vid to output H.264 and pipe to FFmpeg for MJPEG conversion
            rpicam_cmd = [
                'rpicam-vid',
                '--width', str(self.width),
                '--height', str(self.height),
                '--framerate', str(self.fps),
                '--timeout', '0',        # Run indefinitely
                '--codec', 'h264',       # H.264 codec
                '--output', '-',         # Output to stdout
                '--nopreview',           # No preview window
                '--inline',              # Include headers
                '--profile', 'baseline', # Fast encoding profile
                '--level', '4.2'         # Compatibility level
            ]
            
            ffmpeg_cmd = [
                'ffmpeg',
                '-i', '-',               # Input from stdin
                '-f', 'mjpeg',           # Output format MJPEG
                '-q:v', '8',             # Quality (2-31, lower=better)
                '-r', str(self.fps),     # Output framerate
                '-'                      # Output to stdout
            ]
            
            logger.info(f"Camera: rpicam-vid {self.width}x{self.height} @ {self.fps} FPS")
            
            # Start rpicam-vid process
            self.rpicam_process = subprocess.Popen(rpicam_cmd,
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=0)
            
            # Start ffmpeg process
            self.ffmpeg_process = subprocess.Popen(ffmpeg_cmd,
                stdin=self.rpicam_process.stdout,
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=0)
            
            # Close rpicam stdout in parent to avoid deadlock
            self.rpicam_process.stdout.close()
            
            logger.info("✓ Camera and FFmpeg processes started")
            
            # Read the MJPEG stream from FFmpeg
            buffer = b''
            frame_count = 0
            last_time = time.time()
            
            while self.running and self.ffmpeg_process.poll() is None:
                chunk = self.ffmpeg_process.stdout.read(8192)
                if not chunk:
                    break
                    
                buffer += chunk
                
                # Look for complete JPEG frames
                while True:
                    start_idx = buffer.find(b'\xff\xd8')
                    if start_idx == -1:
                        break
                        
                    end_idx = buffer.find(b'\xff\xd9', start_idx + 2)
                    if end_idx == -1:
                        break
                        
                    # Extract complete JPEG frame
                    frame = buffer[start_idx:end_idx + 2]
                    
                    # Update current frame
                    with self.lock:
                        self.current_frame = frame
                    
                    frame_count += 1
                    
                    # Print FPS every 5 seconds (less verbose)
                    current_time = time.time()
                    if current_time - last_time >= 5.0:
                        fps_actual = frame_count / 5.0
                        logger.info(f"Camera: {fps_actual:.1f} FPS, frame: {len(frame)} bytes")
                        frame_count = 0
                        last_time = current_time
                    
                    # Remove processed data
                    buffer = buffer[end_idx + 2:]
                        
        except Exception as e:
            logger.error(f"Camera streaming error: {e}")
        finally:
            # Clean up processes
            if self.ffmpeg_process:
                self.ffmpeg_process.terminate()
            if self.rpicam_process:
                self.rpicam_process.terminate()
            logger.info("Camera streaming stopped")
    
    def get_frame(self):
        """Get the current frame"""
        with self.lock:
            return self.current_frame

# Global camera streamer instance
camera = CameraStreamer(width=640, height=480, fps=30)  # Increased resolution for better quality

# ============================================
# HTML TEMPLATE (Web Interface)
# ============================================

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Vacuum Bot Control Center</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 20px;
            min-height: 100vh;
        }
        h1 {
            color: white;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
            margin-bottom: 10px;
        }
        .subtitle {
            color: rgba(255,255,255,0.9);
            font-size: 14px;
            margin-bottom: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
        }
        .camera-section {
            margin-bottom: 30px;
        }
        img {
            max-width: 100%;
            height: auto;
            border: 3px solid #667eea;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        .info-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .info-card h3 {
            margin-top: 0;
            font-size: 16px;
            opacity: 0.9;
        }
        .info-card p {
            margin: 5px 0;
            font-size: 14px;
        }
        .status-indicator {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: #00ff00;
            margin-right: 5px;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        .footer {
            margin-top: 20px;
            color: white;
            font-size: 12px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
        }
    </style>
</head>
<body>
    <h1>🤖 Vacuum Bot Control Center</h1>
    <p class="subtitle">Real-time Camera Feed & Arduino Control</p>
    
    <div class="container">
        <div class="camera-section">
            <h2><span class="status-indicator"></span>Live Camera Feed</h2>
            <img src="/video_feed" alt="Camera Stream">
        </div>
        
        <div class="info-grid">
            <div class="info-card">
                <h3>📹 Camera Info</h3>
                <p>Resolution: 640x480</p>
                <p>Frame Rate: 30 FPS</p>
                <p>Format: MJPEG</p>
            </div>
            
            <div class="info-card">
                <h3>🔌 Serial Connection</h3>
                <p>Port: /dev/serial0</p>
                <p>Baud Rate: 9600</p>
                <p>GPIO: 14 (TX), 15 (RX)</p>
            </div>
            
            <div class="info-card">
                <h3>🎮 API Endpoints</h3>
                <p>POST /send - Send command</p>
                <p>GET /read - Read data</p>
                <p>GET /status - System status</p>
            </div>
        </div>
    </div>
    
    <div class="footer">
        <p>Raspberry Pi Unified Server | Camera Stream + Serial Communication</p>
    </div>
</body>
</html>
"""

# ============================================
# CAMERA STREAM ROUTES
# ============================================

def generate_frames():
    """Generator function that yields camera frames as MJPEG"""
    last_frame = None
    while True:
        frame = camera.get_frame()
        if frame and frame != last_frame:
            last_frame = frame
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        else:
            time.sleep(0.01)

@app.route('/')
def index():
    """Home page with embedded video stream and system info"""
    return render_template_string(HTML_TEMPLATE)

@app.route('/video_feed')
def video_feed():
    """Route that returns the video stream"""
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/stream')
def stream():
    """Alternative endpoint for the video stream"""
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/single_image')
def single_image():
    """Route that returns a single image"""
    frame = camera.get_frame()
    if frame:
        return Response(frame, mimetype='image/jpeg')
    else:
        return jsonify({'status': 'error', 'message': 'No image available'}), 404

@app.route('/get_frame')
def get_frame():
    """
    On-demand frame delivery (ACK-based)
    Returns latest frame immediately - client requests next frame when ready
    This prevents frame buffering and reduces latency
    """
    frame = camera.get_frame()
    if frame:
        return Response(frame, mimetype='image/jpeg')
    else:
        return jsonify({'status': 'error', 'message': 'No frame available'}), 404

# ============================================
# SERIAL COMMUNICATION ROUTES
# ============================================

@app.route('/send', methods=['POST'])
def send_data():
    """
    Endpoint to receive data and forward to Arduino via serial
    Expects JSON: {"data": "string_to_send"}
    Example: {"data": "f,1000}"}
    """
    if ser is None or not ser.is_open:
        return jsonify({
            'status': 'error',
            'message': 'Serial port not available'
        }), 503
    
    try:
        # Get JSON data from request
        json_data = request.get_json()
        
        if not json_data or 'data' not in json_data:
            return jsonify({
                'status': 'error',
                'message': 'Missing "data" field in request'
            }), 400
        
        data_to_send = str(json_data['data'])
        
        # Send data via serial (add newline for Arduino to recognize end of command)
        ser.write((data_to_send + '\n').encode('utf-8'))
        ser.flush()
        
        logger.info(f"→ Arduino: {data_to_send}")
        print(f"[SERIAL] → Arduino: {data_to_send}")  # Console output
        
        return jsonify({
            'status': 'success',
            'message': 'Data sent successfully',
            'data_sent': data_to_send,
            'timestamp': datetime.now().isoformat()
        }), 200
        
    except Exception as e:
        logger.error(f"Error sending data: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@app.route('/read', methods=['GET'])
def read_data():
    """
    Endpoint to read data from Arduino via serial
    Returns any available data in the serial buffer
    """
    if ser is None or not ser.is_open:
        return jsonify({
            'status': 'error',
            'message': 'Serial port not available'
        }), 503
    
    try:
        # Check if data is available
        if ser.in_waiting > 0:
            # Read available data
            received_data = ser.readline().decode('utf-8').strip()
            logger.info(f"← Arduino: {received_data}")
            
            return jsonify({
                'status': 'success',
                'data': received_data,
                'timestamp': datetime.now().isoformat()
            }), 200
        else:
            return jsonify({
                'status': 'success',
                'message': 'No data available',
                'data': None
            }), 200
            
    except Exception as e:
        logger.error(f"Error reading data: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@app.route('/status', methods=['GET'])
def status():
    """Check server, camera, and serial connection status"""
    serial_status = 'connected' if (ser is not None and ser.is_open) else 'disconnected'
    camera_status = 'streaming' if camera.running else 'stopped'
    
    return jsonify({
        'status': 'online',
        'camera': {
            'status': camera_status,
            'resolution': f"{camera.width}x{camera.height}",
            'fps': camera.fps
        },
        'serial': {
            'status': serial_status,
            'port': SERIAL_PORT,
            'baudrate': BAUD_RATE
        },
        'gpio_pins': {
            'TX': 'GPIO 14 (Physical Pin 8)',
            'RX': 'GPIO 15 (Physical Pin 10)'
        },
        'endpoints': {
            'camera': ['/video_feed', '/stream', '/single_image'],
            'serial': ['/send', '/read', '/close'],
            'info': ['/', '/status']
        },
        'timestamp': datetime.now().isoformat()
    }), 200


@app.route('/close', methods=['POST'])
def close_connection():
    """Close serial connection"""
    global ser
    try:
        if ser is not None and ser.is_open:
            ser.close()
            logger.info("Serial connection closed")
            return jsonify({
                'status': 'success',
                'message': 'Serial connection closed'
            }), 200
        else:
            return jsonify({
                'status': 'info',
                'message': 'Serial connection already closed'
            }), 200
    except Exception as e:
        logger.error(f"Error closing connection: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


# ============================================
# CLEANUP & MAIN
# ============================================

def cleanup():
    """Cleanup function to close resources on shutdown"""
    global ser
    
    # Stop camera
    if camera.running:
        camera.stop_streaming()
    
    # Close serial
    if ser is not None and ser.is_open:
        ser.close()
        logger.info("Serial connection closed during cleanup")


if __name__ == '__main__':
    import atexit
    atexit.register(cleanup)
    
    # Print startup banner
    print("\n" + "=" * 70)
    print("🤖  VACUUM BOT - UNIFIED RASPBERRY PI SERVER")
    print("=" * 70)
    print("\n📹 Camera Streaming:")
    print("   - Resolution: 640x480 @ 30 FPS")
    print("   - Using rpicam-vid + FFmpeg pipeline")
    
    print("\n🔌 Serial Communication:")
    print("   - Port: /dev/serial0 (GPIO 14 TX, GPIO 15 RX)")
    print("   - Baud: 9600")
    print("   - Connected to Arduino Mega")
    
    # Test camera availability
    try:
        result = subprocess.run(['rpicam-vid', '--help'], 
                              capture_output=True, timeout=5)
        if result.returncode != 0:
            logger.error("rpicam-vid command not found!")
            print("\n⚠️  WARNING: Camera may not work without rpicam-vid")
        else:
            logger.info("✓ rpicam-vid available")
    except Exception as e:
        logger.error(f"Cannot run rpicam-vid: {e}")
        print("\n⚠️  WARNING: Camera streaming may not work")
    
    # Start camera streaming
    try:
        camera.start_streaming()
    except Exception as e:
        logger.error(f"Failed to start camera: {e}")
    
    print("\n🌐 Server URLs:")
    print("   - Web Interface:  http://<raspberry-pi-ip>:5000/")
    print("   - Camera Stream:  http://<raspberry-pi-ip>:5000/video_feed")
    print("   - System Status:  http://<raspberry-pi-ip>:5000/status")
    print("   - Send Command:   POST http://<raspberry-pi-ip>:5000/send")
    print("   - Read Data:      GET http://<raspberry-pi-ip>:5000/read")
    
    print("\n" + "=" * 70)
    print("Server starting... Press Ctrl+C to stop")
    print("=" * 70 + "\n")
    
    try:
        # Run Flask server
        app.run(host='0.0.0.0', port=5000, threaded=True, debug=False)
    except KeyboardInterrupt:
        print("\n\n🛑 Shutting down server...")
        cleanup()
        print("✓ Cleanup complete. Goodbye!")
