#!/usr/bin/env python3
"""
Simple Camera Stream Server for Raspberry Pi 4
Uses rpicam-jpeg command to capture images and stream over HTTP
"""

import io
import time
import subprocess
import threading
from flask import Flask, Response, render_template_string

app = Flask(__name__)

# HTML template for the web interface
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Raspberry Pi Camera Stream</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #333;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        img {
            max-width: 100%;
            height: auto;
            border: 2px solid #333;
            border-radius: 5px;
        }
        .info {
            margin-top: 20px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Raspberry Pi Camera Stream</h1>
        <img src="/video_feed" alt="Camera Stream">
                <div class="info">
            <p>Live camera feed from Raspberry Pi 4</p>
            <p>High-speed streaming: 320x240 @ 30 FPS</p>
        </div>
    </div>
</body>
</html>
"""

class CameraStreamer:
    def __init__(self, width=640, height=480, fps=30):
        self.width = width
        self.height = height
        self.fps = fps
        self.running = False
        self.current_frame = None
        self.lock = threading.Lock()
        self.rpicam_process = None
        self.ffmpeg_process = None
        
    def start_streaming(self):
        """Start the camera streaming using rpicam-vid"""
        self.running = True
        self.stream_thread = threading.Thread(target=self._stream_loop, daemon=True)
        self.stream_thread.start()
    
    def stop_streaming(self):
        """Stop the camera streaming"""
        self.running = False
        if hasattr(self, 'ffmpeg_process') and self.ffmpeg_process:
            self.ffmpeg_process.terminate()
        if hasattr(self, 'rpicam_process') and self.rpicam_process:
            self.rpicam_process.terminate()
    
    def _stream_loop(self):
        """Main streaming loop using rpicam-vid + ffmpeg for high FPS"""
        print("Starting high-speed H.264 to MJPEG streaming...")
        try:
            # Use rpicam-vid to output H.264 and pipe to FFmpeg for MJPEG conversion
            rpicam_cmd = [
                'rpicam-vid',
                '--width', str(self.width),
                '--height', str(self.height),
                '--framerate', str(self.fps),
                '--timeout', '0',        # Run indefinitely
                '--codec', 'h264',       # H.264 codec
                '--output', '-',         # Output to stdout
                '--nopreview',           # No preview window
                '--inline',              # Include headers
                '--profile', 'baseline', # Fast encoding profile
                '--level', '4.2'         # Compatibility level
            ]
            
            ffmpeg_cmd = [
                'ffmpeg',
                '-i', '-',               # Input from stdin
                '-f', 'mjpeg',           # Output format MJPEG
                '-q:v', '8',             # Quality (2-31, lower=better)
                '-r', str(self.fps),     # Output framerate
                '-'                      # Output to stdout
            ]
            
            print(f"Camera: {' '.join(rpicam_cmd)}")
            print(f"FFmpeg: {' '.join(ffmpeg_cmd)}")
            
            # Start rpicam-vid process
            self.rpicam_process = subprocess.Popen(rpicam_cmd,
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=0)
            
            # Start ffmpeg process
            self.ffmpeg_process = subprocess.Popen(ffmpeg_cmd,
                stdin=self.rpicam_process.stdout,
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=0)
            
            # Close rpicam stdout in parent to avoid deadlock
            self.rpicam_process.stdout.close()
            
            print("Camera and FFmpeg processes started, parsing MJPEG stream...")
            
            # Read the MJPEG stream from FFmpeg
            buffer = b''
            frame_count = 0
            last_time = time.time()
            
            while self.running and self.ffmpeg_process.poll() is None:
                chunk = self.ffmpeg_process.stdout.read(8192)
                if not chunk:
                    break
                    
                buffer += chunk
                
                # Look for complete JPEG frames
                while True:
                    start_idx = buffer.find(b'\xff\xd8')
                    if start_idx == -1:
                        break
                        
                    end_idx = buffer.find(b'\xff\xd9', start_idx + 2)
                    if end_idx == -1:
                        break
                        
                    # Extract complete JPEG frame
                    frame = buffer[start_idx:end_idx + 2]
                    
                    # Update current frame
                    with self.lock:
                        self.current_frame = frame
                    
                    frame_count += 1
                    
                    # Print FPS every second
                    current_time = time.time()
                    if current_time - last_time >= 1.0:
                        print(f"Streaming at {frame_count} FPS, frame size: {len(frame)} bytes")
                        frame_count = 0
                        last_time = current_time
                    
                    # Remove processed data
                    buffer = buffer[end_idx + 2:]
                        
        except Exception as e:
            print(f"Camera streaming error: {e}")
        finally:
            # Clean up processes
            if hasattr(self, 'ffmpeg_process') and self.ffmpeg_process:
                self.ffmpeg_process.terminate()
            if hasattr(self, 'rpicam_process') and self.rpicam_process:
                self.rpicam_process.terminate()
            print("Camera streaming stopped")
    
    def get_frame(self):
        """Get the current frame"""
        with self.lock:
            return self.current_frame

# Global camera streamer instance (high FPS, lower quality)
camera = CameraStreamer(width=320, height=240, fps=30)

def generate_frames():
    """Generator function that yields camera frames as JPEG"""
    last_frame = None
    while True:
        frame = camera.get_frame()
        if frame and frame != last_frame:  # Only send if frame changed
            last_frame = frame
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        else:
            # Very short sleep to avoid busy waiting
            time.sleep(0.01)

@app.route('/')
def index():
    """Home page with embedded video stream"""
    return render_template_string(HTML_TEMPLATE)

@app.route('/video_feed')
def video_feed():
    """Route that returns the video stream"""
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/stream')
def stream():
    """Alternative endpoint for the video stream"""
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/single_image')
def single_image():
    """Route that returns a single image"""
    frame = camera.get_frame()
    if frame:
        return Response(frame, mimetype='image/jpeg')
    else:
        return "No image available", 404

if __name__ == '__main__':
    print("Starting Raspberry Pi Camera Stream Server...")
    print("Using rpicam-vid for continuous video streaming")
    print("")
    
    # Test if rpicam-vid is available
    try:
        result = subprocess.run(['rpicam-vid', '--help'], 
                              capture_output=True, timeout=5)
        if result.returncode != 0:
            print("ERROR: rpicam-vid command not found!")
            print("Please ensure you have the latest Raspberry Pi OS with camera support.")
            exit(1)
    except Exception as e:
        print(f"ERROR: Cannot run rpicam-vid: {e}")
        exit(1)
    
    # Start the camera streamer
    camera.start_streaming()
    
    print("Camera streaming started!")
    print("Access the stream at:")
    print("  - http://<raspberry-pi-ip>:8000/")
    print("  - http://<raspberry-pi-ip>:8000/video_feed (direct stream)")
    print("  - http://<raspberry-pi-ip>:8000/stream (direct stream)")
    print("  - http://<raspberry-pi-ip>:8000/single_image (single photo)")
    print("")
    
    try:
        # Run the Flask app on all network interfaces
        app.run(host='0.0.0.0', port=8000, threaded=True, debug=False)
    except KeyboardInterrupt:
        print("\nShutting down...")
        camera.stop_streaming()
