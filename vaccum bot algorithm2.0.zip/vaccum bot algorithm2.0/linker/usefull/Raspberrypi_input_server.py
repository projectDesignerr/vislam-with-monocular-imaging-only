#!/usr/bin/env python3
"""
Raspberry Pi HTTP Server for Serial Communication with Arduino Mega
====================================================================
This server receives HTTP POST requests with string data and forwards 
them to Arduino Mega via UART serial communication.

GPIO Pins Used:
- GPIO 14 (Pin 8)  - TXD (Transmit) - Connect to Arduino RX
- GPIO 15 (Pin 10) - RXD (Receive)  - Connect to Arduino TX

Hardware Connection:
- Raspberry Pi GPIO 14 (TXD) -> Arduino Mega RX1 (Pin 19)
- Raspberry Pi GPIO 15 (RXD) -> Arduino Mega TX1 (Pin 18)
- Raspberry Pi GND -> Arduino Mega GND (Common Ground)

Note: Raspberry Pi uses 3.3V logic, Arduino Mega uses 5V logic.
Consider using a logic level converter for safe communication.
"""

from flask import Flask, request, jsonify
import serial
import logging
from datetime import datetime
import json

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)

# Serial port configuration
# /dev/serial0 is the primary UART on Raspberry Pi (GPIO 14 & 15)
# Alternative: /dev/ttyAMA0 or /dev/ttyS0 depending on RPi model
SERIAL_PORT = '/dev/serial0'  # GPIO 14 (TX) and GPIO 15 (RX)
BAUD_RATE = 9600
TIMEOUT = 1

# Initialize serial connection
try:
    ser = serial.Serial(
        port=SERIAL_PORT,
        baudrate=BAUD_RATE,
        timeout=TIMEOUT,
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        bytesize=serial.EIGHTBITS
    )
    logger.info(f"Serial port {SERIAL_PORT} initialized successfully")
    logger.info(f"Using GPIO 14 (TXD) and GPIO 15 (RXD) for UART communication")
except serial.SerialException as e:
    logger.error(f"Failed to open serial port: {e}")
    ser = None


@app.route('/', methods=['GET'])
def home():
    """Home endpoint - provides API information"""
    return jsonify({
        'status': 'running',
        'message': 'Raspberry Pi Serial Communication Server',
        'gpio_pins': {
            'TX': 'GPIO 14 (Pin 8)',
            'RX': 'GPIO 15 (Pin 10)'
        },
        'endpoints': {
            '/send': 'POST - Send data to Arduino',
            '/status': 'GET - Check server status',
            '/read': 'GET - Read data from Arduino'
        },
        'serial_config': {
            'port': SERIAL_PORT,
            'baudrate': BAUD_RATE
        }
    }), 200


@app.route('/send', methods=['POST'])
def send_data():
    """
    Endpoint to receive data and forward to Arduino via serial
    Expects JSON: {"data": "string_to_send"}
    """
    if ser is None or not ser.is_open:
        return jsonify({
            'status': 'error',
            'message': 'Serial port not available'
        }), 503
    
    try:
        # Get JSON data from request
        json_data = request.get_json()
        
        if not json_data or 'data' not in json_data:
            return jsonify({
                'status': 'error',
                'message': 'Missing "data" field in request'
            }), 400
        
        data_to_send = str(json_data['data'])
        
        # Send data via serial (add newline for Arduino to recognize end of command)
        ser.write((data_to_send + '\n').encode('utf-8'))
        ser.flush()
        
        logger.info(f"Sent to Arduino: {data_to_send}")
        
        return jsonify({
            'status': 'success',
            'message': 'Data sent successfully',
            'data_sent': data_to_send,
            'timestamp': datetime.now().isoformat()
        }), 200
        
    except Exception as e:
        logger.error(f"Error sending data: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@app.route('/read', methods=['GET'])
def read_data():
    """
    Endpoint to read data from Arduino via serial
    Returns any available data in the serial buffer
    """
    if ser is None or not ser.is_open:
        return jsonify({
            'status': 'error',
            'message': 'Serial port not available'
        }), 503
    
    try:
        # Check if data is available
        if ser.in_waiting > 0:
            # Read available data
            received_data = ser.readline().decode('utf-8').strip()
            logger.info(f"Received from Arduino: {received_data}")
            
            return jsonify({
                'status': 'success',
                'data': received_data,
                'timestamp': datetime.now().isoformat()
            }), 200
        else:
            return jsonify({
                'status': 'success',
                'message': 'No data available',
                'data': None
            }), 200
            
    except Exception as e:
        logger.error(f"Error reading data: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@app.route('/status', methods=['GET'])
def status():
    """Check server and serial connection status"""
    serial_status = 'connected' if (ser is not None and ser.is_open) else 'disconnected'
    
    return jsonify({
        'status': 'online',
        'serial_connection': serial_status,
        'serial_port': SERIAL_PORT,
        'baudrate': BAUD_RATE,
        'gpio_pins': {
            'TX': 'GPIO 14 (Physical Pin 8)',
            'RX': 'GPIO 15 (Physical Pin 10)'
        },
        'timestamp': datetime.now().isoformat()
    }), 200


@app.route('/close', methods=['POST'])
def close_connection():
    """Close serial connection"""
    global ser
    try:
        if ser is not None and ser.is_open:
            ser.close()
            logger.info("Serial connection closed")
            return jsonify({
                'status': 'success',
                'message': 'Serial connection closed'
            }), 200
        else:
            return jsonify({
                'status': 'info',
                'message': 'Serial connection already closed'
            }), 200
    except Exception as e:
        logger.error(f"Error closing connection: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


def cleanup():
    """Cleanup function to close serial connection on shutdown"""
    global ser
    if ser is not None and ser.is_open:
        ser.close()
        logger.info("Serial connection closed during cleanup")


if __name__ == '__main__':
    try:
        # Register cleanup function
        import atexit
        atexit.register(cleanup)
        
        logger.info("=" * 60)
        logger.info("Starting Raspberry Pi HTTP Server")
        logger.info("=" * 60)
        logger.info("GPIO Configuration:")
        logger.info("  TX: GPIO 14 (Physical Pin 8)  -> Arduino RX1")
        logger.info("  RX: GPIO 15 (Physical Pin 10) -> Arduino TX1")
        logger.info("=" * 60)
        logger.info("Server starting on http://0.0.0.0:5000")
        logger.info("=" * 60)
        
        # Run Flask server
        # host='0.0.0.0' makes it accessible from other devices on the network
        app.run(host='0.0.0.0', port=5000, debug=False)
        
    except KeyboardInterrupt:
        logger.info("\nShutting down server...")
        cleanup()
    except Exception as e:
        logger.error(f"Server error: {e}")
        cleanup()
