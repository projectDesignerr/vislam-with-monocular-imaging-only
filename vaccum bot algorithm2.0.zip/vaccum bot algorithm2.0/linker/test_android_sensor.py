#!/usr/bin/env python3
"""
Test Android Sensor Server - Get Heading/Orientation
=====================================================
Connects to Sensor Server app on Android phone via WebSocket
to retrieve heading/orientation data for robot navigation

Sensor Server App: https://play.google.com/store/apps/details?id=de.lorenz_fenster.sensorstreamserver

Connection: ws://192.168.1.100:8080
Access pattern: android.sensor.<sensor_name>
"""

import asyncio
import websockets
import json
import math

# Configuration
ANDROID_IP = "192.168.1.100"  # Change to your Android phone IP
WEBSOCKET_PORT = 8080
WEBSOCKET_URL = f"ws://{ANDROID_IP}:{WEBSOCKET_PORT}/sensor/connect?type=android.sensor.orientation"

# Alternative sensors you can try:
# android.sensor.orientation - Azimuth, Pitch, Roll
# android.sensor.rotation_vector - Rotation vector (more accurate)
# android.sensor.magnetic_field - Magnetometer
# android.sensor.accelerometer - Accelerometer
# android.sensor.gyroscope - Gyroscope

async def test_orientation_sensor():
    """Test connection to Android orientation sensor"""
    print("=" * 60)
    print("Android Sensor Server - Heading Test")
    print("=" * 60)
    print(f"Connecting to: {WEBSOCKET_URL}")
    print()
    
    try:
        async with websockets.connect(WEBSOCKET_URL) as websocket:
            print("✓ Connected to Android Sensor Server!")
            print("Reading orientation data (Ctrl+C to stop)...")
            print("-" * 60)
            
            # Receive sensor data
            async for message in websocket:
                try:
                    # Parse JSON data
                    data = json.loads(message)
                    
                    # Orientation sensor provides: azimuth, pitch, roll
                    if 'values' in data:
                        values = data['values']
                        
                        if len(values) >= 3:
                            azimuth = values[0]  # Heading (0-360°)
                            pitch = values[1]    # Tilt forward/back
                            roll = values[2]     # Tilt left/right
                            
                            # Display every frame for real-time updates
                            print(f"Heading: {azimuth:6.1f}° | Pitch: {pitch:6.1f}° | Roll: {roll:6.1f}°", end='\r')
                    
                    elif 'type' in data:
                        print(f"Sensor type: {data['type']}")
                    
                except json.JSONDecodeError:
                    print(f"Invalid JSON: {message}")
                except Exception as e:
                    print(f"Error parsing data: {e}")
    
    except websockets.exceptions.WebSocketException as e:
        print(f"✗ WebSocket error: {e}")
        print("\nTroubleshooting:")
        print("1. Make sure Sensor Server app is running on Android")
        print("2. Check the IP address matches your phone's IP")
        print("3. Ensure phone and PC are on the same WiFi network")
        print("4. Check firewall settings")
    
    except Exception as e:
        print(f"✗ Connection error: {e}")

async def test_rotation_vector_sensor():
    """Test rotation vector sensor (more accurate for heading)"""
    url = f"ws://{ANDROID_IP}:{WEBSOCKET_PORT}/sensor/connect?type=android.sensor.rotation_vector"
    
    print("=" * 60)
    print("Android Sensor Server - Rotation Vector Test")
    print("=" * 60)
    print(f"Connecting to: {url}")
    print()
    
    try:
        async with websockets.connect(url) as websocket:
            print("✓ Connected to Android Sensor Server!")
            print("Reading rotation vector data (Ctrl+C to stop)...")
            print("-" * 60)
            
            async for message in websocket:
                try:
                    data = json.loads(message)
                    
                    if 'values' in data:
                        values = data['values']
                        
                        if len(values) >= 4:
                            # Rotation vector: x, y, z, scalar
                            x = values[0]
                            y = values[1]
                            z = values[2]
                            w = values[3] if len(values) > 3 else 0
                            
                            # Convert quaternion to heading (azimuth)
                            # Heading = atan2(2*(w*z + x*y), 1 - 2*(y^2 + z^2))
                            heading = math.atan2(2*(w*z + x*y), 1 - 2*(y**2 + z**2))
                            heading_deg = math.degrees(heading)
                            
                            # Normalize to 0-360
                            if heading_deg < 0:
                                heading_deg += 360
                            
                            # Display every frame for real-time updates1
                            print(f"Heading: {heading_deg:6.1f}° | Quaternion: ({x:.3f}, {y:.3f}, {z:.3f}, {w:.3f})", end='\r')
                
                except json.JSONDecodeError:
                    print(f"Invalid JSON: {message}")
                except Exception as e:
                    print(f"Error: {e}")
    
    except Exception as e:
        print(f"✗ Error: {e}")

async def list_available_sensors():
    """List all available sensors from Android device"""
    url = f"ws://{ANDROID_IP}:{WEBSOCKET_PORT}/sensor/connect"
    
    print("=" * 60)
    print("Listing Available Sensors")
    print("=" * 60)
    
    try:
        async with websockets.connect(url) as websocket:
            print("✓ Connected!")
            print("Waiting for sensor list...")
            
            # Wait for initial message
            message = await websocket.recv()
            data = json.loads(message)
            print(json.dumps(data, indent=2))
    
    except Exception as e:
        print(f"✗ Error: {e}")

def main():
    """Main entry point"""
    print()
    print("Select test mode:")
    print("  1 - Test Orientation Sensor (Azimuth/Heading)")
    print("  2 - Test Rotation Vector Sensor (More accurate)")
    print("  3 - List Available Sensors")
    print()
    
    choice = input("Choice (1/2/3): ").strip()
    
    if choice == '1':
        asyncio.run(test_orientation_sensor())
    elif choice == '2':
        asyncio.run(test_rotation_vector_sensor())
    elif choice == '3':
        asyncio.run(list_available_sensors())
    else:
        print("Invalid choice")

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nStopped by user")
