import requests

response = requests.post(
    'http://192.168.1.8:5000/send',
    json={'data': 'r,500}'}
)
print(response.json())