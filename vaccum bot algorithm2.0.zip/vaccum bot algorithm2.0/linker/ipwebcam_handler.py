"""
IP Webcam Rotation Vector Handler for Robot Heading
Uses HTTP polling instead of WebSocket for better reliability
"""

import requests
import time
import math
from threading import Thread, Lock


class IPWebcamHandler:
    """Handler for IP Webcam rotation vector sensor data via HTTP polling"""
    
    def __init__(self, ipwebcam_ip="192.168.1.100", ipwebcam_port=8181):
        """
        Initialize IP Webcam handler
        
        Args:
            ipwebcam_ip (str): IP address of phone running IP Webcam
            ipwebcam_port (int): Port number (default 8181)
        """
        self.ipwebcam_ip = ipwebcam_ip
        self.ipwebcam_port = ipwebcam_port
        self.base_url = f"http://{ipwebcam_ip}:{ipwebcam_port}/sensors.json"
        
        # State variables
        self._heading = 0.0
        self._heading_lock = Lock()
        self._is_connected = False
        self._running = False
        self._thread = None
        
        # Tare/calibration offset (set current heading as North)
        self._tare_offset = 0.0
        self._is_tared = False
        
        # Smoothing buffer
        self._heading_buffer = []
        self._buffer_size = 10
        
        # Timestamp tracking
        self._last_timestamp = int(time.time() * 1000)
        
        print(f"[IPWEBCAM] Initialized for {ipwebcam_ip}:{ipwebcam_port}")
    
    def _quaternion_to_euler(self, x, y, z, w):
        """
        Convert quaternion to Euler angles (yaw/heading)
        Returns heading in degrees (0-360)
        Inverted to match robot coordinate system (left turn = negative heading)
        """
        # Yaw (heading)
        siny_cosp = 2 * (w * z + x * y)
        cosy_cosp = 1 - 2 * (y * y + z * z)
        yaw = math.atan2(siny_cosp, cosy_cosp)
        
        # Convert to degrees
        heading = math.degrees(yaw)
        
        # Invert the heading (mirror horizontally)
        # Physical left turn should decrease heading (counterclockwise)
        heading = -heading
        
        # Normalize to 0-360
        if heading < 0:
            heading += 360
        
        return heading
    
    def _poll_sensor_data(self):
        """Background thread to continuously poll IP Webcam sensor data"""
        consecutive_errors = 0
        max_consecutive_errors = 10
        
        print("[IPWEBCAM] Starting sensor polling thread...")
        
        while self._running:
            try:
                # Request only new data since last timestamp
                url = f"{self.base_url}?from={self._last_timestamp}&sense=rot_vector"
                
                response = requests.get(url, timeout=2)
                
                if response.status_code == 200:
                    data = response.json()
                    
                    # Parse IP Webcam format: {"rot_vector": {"data": [[timestamp, [x, y, z, w, accuracy]], ...]}}
                    if isinstance(data, dict) and "rot_vector" in data:
                        rot_data = data["rot_vector"]
                        
                        if isinstance(rot_data, dict) and "data" in rot_data:
                            readings = rot_data["data"]
                            
                            if readings and len(readings) > 0:
                                # Process all new readings
                                for reading in readings:
                                    if len(reading) >= 2:
                                        timestamp_ms = reading[0]
                                        values = reading[1]  # [x, y, z, w, accuracy]
                                        
                                        if len(values) >= 4:
                                            x, y, z, w = values[0], values[1], values[2], values[3]
                                            
                                            # Convert quaternion to heading
                                            raw_heading = self._quaternion_to_euler(x, y, z, w)
                                            
                                            # Apply tare offset
                                            heading = (raw_heading - self._tare_offset) % 360
                                            
                                            # Update heading with lock
                                            with self._heading_lock:
                                                self._heading = heading
                                                
                                                # Add to smoothing buffer
                                                self._heading_buffer.append(heading)
                                                if len(self._heading_buffer) > self._buffer_size:
                                                    self._heading_buffer.pop(0)
                                            
                                            # Update timestamp
                                            self._last_timestamp = timestamp_ms
                                
                                # Mark as connected after successful data
                                if not self._is_connected:
                                    self._is_connected = True
                                    print("[IPWEBCAM] ✓ Connected and receiving data")
                                
                                consecutive_errors = 0
                    
                else:
                    consecutive_errors += 1
                    if consecutive_errors == 1:
                        print(f"[IPWEBCAM] HTTP {response.status_code}")
                
                # Poll at 10 Hz
                time.sleep(0.1)
                
            except requests.exceptions.Timeout:
                consecutive_errors += 1
                if consecutive_errors == 1:
                    print("[IPWEBCAM] Request timeout")
                time.sleep(0.5)
                
            except requests.exceptions.ConnectionError:
                consecutive_errors += 1
                if consecutive_errors == 1:
                    print("[IPWEBCAM] Connection error - retrying...")
                self._is_connected = False
                time.sleep(1.0)
                
            except Exception as e:
                consecutive_errors += 1
                if consecutive_errors == 1:
                    print(f"[IPWEBCAM] Error: {e}")
                time.sleep(0.5)
            
            # If too many errors, mark as disconnected
            if consecutive_errors >= max_consecutive_errors:
                if self._is_connected:
                    self._is_connected = False
                    print("[IPWEBCAM] ✗ Disconnected due to errors")
                consecutive_errors = max_consecutive_errors  # Cap to prevent overflow
        
        print("[IPWEBCAM] Polling thread stopped")
    
    def start(self):
        """Start polling IP Webcam sensor data"""
        if self._running:
            print("[IPWEBCAM] Already running")
            return
        
        # Test connection first
        print(f"[IPWEBCAM] Testing connection to {self.ipwebcam_ip}:{self.ipwebcam_port}...")
        try:
            response = requests.get(f"{self.base_url}?sense=rot_vector", timeout=5)
            if response.status_code != 200:
                print(f"[IPWEBCAM] ✗ Connection test failed: HTTP {response.status_code}")
                return False
            
            data = response.json()
            if "rot_vector" not in data:
                print("[IPWEBCAM] ✗ rot_vector sensor not available")
                return False
            
            print("[IPWEBCAM] ✓ Connection test successful")
            
        except Exception as e:
            print(f"[IPWEBCAM] ✗ Connection test failed: {e}")
            return False
        
        # Start background thread
        self._running = True
        self._thread = Thread(target=self._poll_sensor_data, daemon=True)
        self._thread.start()
        
        return True
    
    def stop(self):
        """Stop polling sensor data"""
        if not self._running:
            return
        
        print("[IPWEBCAM] Stopping...")
        self._running = False
        
        if self._thread:
            self._thread.join(timeout=2.0)
        
        self._is_connected = False
        print("[IPWEBCAM] Stopped")
    
    def get_heading(self, smoothed=True):
        """
        Get current heading in degrees (0-360)
        
        Args:
            smoothed (bool): If True, return averaged heading from buffer
        
        Returns:
            float: Heading in degrees (0-360), or None if no data
        """
        with self._heading_lock:
            if not self._heading_buffer:
                return None
            
            if smoothed and len(self._heading_buffer) > 1:
                # Calculate circular mean for heading
                # Convert to radians, average, convert back
                sin_sum = sum(math.sin(math.radians(h)) for h in self._heading_buffer)
                cos_sum = sum(math.cos(math.radians(h)) for h in self._heading_buffer)
                
                avg_heading = math.degrees(math.atan2(sin_sum, cos_sum))
                if avg_heading < 0:
                    avg_heading += 360
                
                return avg_heading
            else:
                return self._heading
    
    def is_connected(self):
        """Check if connected to IP Webcam"""
        return self._is_connected
    
    def tare_heading(self):
        """Set current heading as North (0°) - calibration/tare function"""
        with self._heading_lock:
            if not self._heading_buffer:
                print("[IPWEBCAM] Cannot tare - no heading data available")
                return False
            
            # Get current raw heading (before tare offset)
            current_heading = self._heading + self._tare_offset
            
            # Set this as the new offset
            self._tare_offset = current_heading % 360
            self._is_tared = True
            
            print(f"[IPWEBCAM] ✓ Tared: Current direction set as North (0°)")
            print(f"[IPWEBCAM]   Offset applied: {self._tare_offset:.1f}°")
            return True
    
    def __del__(self):
        """Cleanup on deletion"""
        self.stop()


# Test function
def test_ipwebcam_handler():
    """Test the IP Webcam handler"""
    print("=" * 70)
    print("IP WEBCAM HANDLER TEST")
    print("=" * 70)
    print()
    
    # Create handler
    handler = IPWebcamHandler(ipwebcam_ip="192.168.1.100", ipwebcam_port=8181)
    
    # Start polling
    if not handler.start():
        print("Failed to start handler")
        return
    
    # Wait for connection
    print("\nWaiting for data...")
    time.sleep(2)
    
    # Monitor heading
    print("\nLive heading (Press Ctrl+C to stop):")
    print("-" * 70)
    
    try:
        frame_count = 0
        while True:
            heading = handler.get_heading(smoothed=True)
            connected = handler.is_connected()
            
            if heading is not None:
                status = "✓ Connected" if connected else "✗ Disconnected"
                print(f"\rHeading: {heading:6.2f}° | {status} | Frame: {frame_count}", 
                      end="", flush=True)
                frame_count += 1
            else:
                print("\rWaiting for data...", end="", flush=True)
            
            time.sleep(0.1)
    
    except KeyboardInterrupt:
        print("\n")
        print("-" * 70)
        print("Test stopped")
    
    finally:
        handler.stop()
        print("=" * 70)


if __name__ == "__main__":
    test_ipwebcam_handler()
