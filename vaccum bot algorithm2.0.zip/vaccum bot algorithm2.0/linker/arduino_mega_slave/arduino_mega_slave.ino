#include <AFMotor.h>

// Initialize DC motors on Motor Shield
AF_DCMotor m1(1);  // Motor 1
AF_DCMotor m2(4);  // Motor 2

// Motor speed setting
uint8_t speed = 255;  // Speed range: 0-255

// Command parsing variables for Serial (USB)
String commandBuffer = "";
bool commandComplete = false;

// Command parsing variables for Serial1 (Raspberry Pi)
String commandBuffer1 = "";
bool commandComplete1 = false;

void setup() {
  // Initialize Serial for USB communication (can send commands from PC)
  Serial.begin(9600);
  
  // Initialize Serial1 for Raspberry Pi communication (GPIO)
  Serial1.begin(9600);
  
  // Set motor speeds
  m1.setSpeed(speed);
  m2.setSpeed(speed);
  
  // Stop motors initially
  m1.run(RELEASE);
  m2.run(RELEASE);
  
  Serial.println("Arduino Mega Motor Controller Ready");
  Serial.println("Listening on both Serial (USB) and Serial1 (Raspberry Pi)");
  Serial.println("Command format: command,duration}");
  Serial.println("Example: f,1000}  (forward for 1000ms)");
}

void loop() {
  // Check if data is available on Serial (USB)
  while (Serial.available() > 0) {
    char inChar = (char)Serial.read();
    
    // Check for command terminator
    if (inChar == '}') {
      commandComplete = true;
      break;
    } else {
      commandBuffer += inChar;
    }
  }
  
  // Check if data is available on Serial1 (Raspberry Pi)
  while (Serial1.available() > 0) {
    char inChar = (char)Serial1.read();
    
    // Check for command terminator
    if (inChar == '}') {
      commandComplete1 = true;
      break;
    } else {
      commandBuffer1 += inChar;
    }
  }
  
  // Process command from Serial (USB) when complete
  if (commandComplete) {
    Serial.print("[USB] ");
    processCommand(commandBuffer);
    commandBuffer = "";
    commandComplete = false;
  }
  
  // Process command from Serial1 (Raspberry Pi) when complete
  if (commandComplete1) {
    Serial.print("[Pi] ");
    processCommand(commandBuffer1);
    commandBuffer1 = "";
    commandComplete1 = false;
  }
}

void processCommand(String cmd) {
  // Parse command format: "command,time"
  int commaIndex = cmd.indexOf(',');
  
  if (commaIndex == -1) {
    Serial.println("Error: Invalid command format");
    return;
  }
  
  String command = cmd.substring(0, commaIndex);
  String timeStr = cmd.substring(commaIndex + 1);
  int duration = timeStr.toInt();
  
  // Debug output
  Serial.print("Command: ");
  Serial.print(command);
  Serial.print(" | Duration: ");
  Serial.print(duration);
  Serial.println("ms");
  
  // Execute motor command
  if (command == "f") {
    // Forward
    m1.run(FORWARD);
    m2.run(FORWARD);
    Serial.println("Moving FORWARD");
  } 
  else if (command == "b") {
    // Backward
    m1.run(BACKWARD);
    m2.run(BACKWARD);
    Serial.println("Moving BACKWARD");
  } 
  else if (command == "l") {
    // Left (motor 1 backward, motor 2 forward)
    m1.run(BACKWARD);
    m2.run(FORWARD);
    Serial.println("Turning LEFT");
  } 
  else if (command == "r") {
    // Right (motor 1 forward, motor 2 backward)
    m1.run(FORWARD);
    m2.run(BACKWARD);
    Serial.println("Turning RIGHT");
  } 
  else if (command == "s") {
    // Stop
    m1.run(RELEASE);
    m2.run(RELEASE);
    Serial.println("STOPPED");
    return;  // No delay needed for stop
  }
  else {
    Serial.println("Error: Unknown command");
    return;
  }
  
  // Run motors for specified duration
  delay(duration);
  
  // Stop motors after duration
  m1.run(RELEASE);
  m2.run(RELEASE);
  
  Serial.println("Movement complete, motors stopped");
}
