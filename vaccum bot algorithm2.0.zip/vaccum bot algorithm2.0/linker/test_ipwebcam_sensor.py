"""
Test script for IP Webcam rotation vector sensor data
URL: http://IP:8181/sensors.json?sense=rot_vector
"""

import requests
import json
import time
import math

def quaternion_to_euler(x, y, z, w):
    """
    Convert quaternion to Euler angles (roll, pitch, yaw/heading)
    Returns heading in degrees (0-360)
    """
    # Yaw (heading)
    siny_cosp = 2 * (w * z + x * y)
    cosy_cosp = 1 - 2 * (y * y + z * z)
    yaw = math.atan2(siny_cosp, cosy_cosp)
    
    # Convert to degrees and normalize to 0-360
    heading = math.degrees(yaw)
    if heading < 0:
        heading += 360
    
    return heading

def test_ipwebcam_rotation_vector(ipwebcam_ip, ipwebcam_port):
    """Test IP Webcam rotation vector sensor for heading extraction"""
    
    print("=" * 70)
    print("IP WEBCAM ROTATION VECTOR SENSOR TEST")
    print("=" * 70)
    print(f"Target: http://{ipwebcam_ip}:{ipwebcam_port}")
    print()
    
    # Base URL without timestamp
    base_url = f"http://{ipwebcam_ip}:{ipwebcam_port}/sensors.json"
    
    print("Testing sensor endpoint...")
    print()
    
    # First request to see data format
    try:
        # Get current timestamp in milliseconds
        timestamp = int(time.time() * 1000)
        url = f"{base_url}?sense=rot_vector"
        
        print(f"Request URL: {url}")
        print()
        
        response = requests.get(url, timeout=5)
        
        if response.status_code == 200:
            print("✓ Connection successful!")
            print()
            print("Raw response:")
            print("-" * 70)
            print(response.text[:500])  # Show first 500 chars
            print("-" * 70)
            print()
            
            # Try to parse JSON
            try:
                data = response.json()
                print("Parsed JSON structure:")
                print(json.dumps(data, indent=2)[:1000])  # Show first 1000 chars
                print()
            except json.JSONDecodeError as e:
                print(f"JSON parse error: {e}")
                print("Response might not be JSON format")
                return
            
        else:
            print(f"✗ HTTP Error {response.status_code}")
            print("Check:")
            print("  1. IP Webcam app is running")
            print("  2. Server is started")
            print("  3. IP address and port are correct")
            return
            
    except requests.exceptions.ConnectionError:
        print("✗ Connection failed")
        print("Check network and IP address")
        return
    except requests.exceptions.Timeout:
        print("✗ Request timeout")
        return
    except Exception as e:
        print(f"✗ Error: {e}")
        return
    
    # Live monitoring
    print("=" * 70)
    print("LIVE HEADING MONITORING (Press Ctrl+C to stop)")
    print("=" * 70)
    print()
    
    last_timestamp = int(time.time() * 1000)
    
    try:
        while True:
            try:
                # Use timestamp to get only new data
                current_timestamp = int(time.time() * 1000)
                url = f"{base_url}?from={last_timestamp}&sense=rot_vector"
                
                response = requests.get(url, timeout=2)
                
                if response.status_code == 200:
                    data = response.json()
                    
                    # IP Webcam format: {"rot_vector": {"data": [[timestamp, [x, y, z, w, accuracy]], ...]}}
                    
                    if isinstance(data, dict) and "rot_vector" in data:
                        rot_data = data["rot_vector"]
                        
                        if isinstance(rot_data, dict) and "data" in rot_data:
                            readings = rot_data["data"]
                            if readings and len(readings) > 0:
                                # Get the latest reading
                                latest = readings[-1]
                                
                                if len(latest) >= 2:
                                    timestamp_ms = latest[0]
                                    values = latest[1]  # [x, y, z, w, accuracy]
                                    
                                    if len(values) >= 4:
                                        x, y, z, w = values[0], values[1], values[2], values[3]
                                        
                                        # Convert quaternion to heading
                                        heading = quaternion_to_euler(x, y, z, w)
                                        
                                        print(f"\rHeading: {heading:6.2f}° | Quat: [{x:.3f}, {y:.3f}, {z:.3f}, {w:.3f}] | Time: {timestamp_ms}", 
                                              end="", flush=True)
                                        
                                        last_timestamp = timestamp_ms
                                    else:
                                        print(f"\rInvalid values array: {values}", end="", flush=True)
                                else:
                                    print(f"\rUnexpected data format: {latest}", end="", flush=True)
                            else:
                                # No new data since last request
                                pass
                        else:
                            print(f"\rUnknown rot_vector format", end="", flush=True)
                    else:
                        print(f"\rNo rot_vector in response", end="", flush=True)
                
                else:
                    print(f"\rHTTP {response.status_code}", end="", flush=True)
                
                time.sleep(0.1)  # 10 Hz
                
            except requests.exceptions.Timeout:
                print("\rTimeout...", end="", flush=True)
                time.sleep(0.5)
            except Exception as e:
                print(f"\rError: {str(e)[:50]}", end="", flush=True)
                time.sleep(0.5)
    
    except KeyboardInterrupt:
        print("\n")
        print("=" * 70)
        print("Test completed")
        print("=" * 70)

def main():
    # Default configuration
    default_ip = "192.168.1.100"
    default_port = 8181
    
    print()
    print("IP WEBCAM ROTATION VECTOR SENSOR TEST")
    print()
    print("Make sure:")
    print("  1. IP Webcam app is running on Android")
    print("  2. Server is started")
    print("  3. Sensors are enabled in app settings")
    print()
    
    # Allow custom IP/port
    custom_ip = input(f"Phone IP [{default_ip}]: ").strip()
    ipwebcam_ip = custom_ip if custom_ip else default_ip
    
    custom_port = input(f"Port [{default_port}]: ").strip()
    ipwebcam_port = int(custom_port) if custom_port else default_port
    
    print()
    test_ipwebcam_rotation_vector(ipwebcam_ip, ipwebcam_port)

if __name__ == "__main__":
    main()
