#include <AFMotor.h>

// Motor setup — 4 DC motors
AF_DCMotor motor1(1);
AF_DCMotor motor4(4);

// Variables for Serial 1 input
String inputString1 = "";
bool inputComplete1 = false;

// Variables for Serial 2 input
String inputString2 = "";
bool inputComplete2 = false;

void setup() {
  Serial.begin(9600);   // Serial 1
  Serial2.begin(9600);  // Serial 2

  // Set motor speeds (0-255)
  motor1.setSpeed(225);
  motor4.setSpeed(225);

  Serial.println("Serial 1 ready. Send command: direction,time}");
  Serial.println("Example: f,1000} for forward 1000ms");
  
  Serial2.println("Serial 2 ready. Send command: direction,time}");
  Serial2.println("Example: f,1000} for forward 1000ms");
}

void loop() {
  // Read from both serial ports
  readSerialInput(Serial, inputString1, inputComplete1);
  readSerialInput(Serial2, inputString2, inputComplete2);

  // Process Serial 1 commands
  if (inputComplete1) {
    processCommand(Serial, inputString1);
    inputComplete1 = false;
    inputString1 = "";
  }

  // Process Serial 2 commands
  if (inputComplete2) {
    processCommand(Serial2, inputString2);
    inputComplete2 = false;
    inputString2 = "";
  }
}

// Read serial input from any serial port
void readSerialInput(HardwareSerial &serialPort, String &inputStr, bool &complete) {
  while (serialPort.available()) {
    char inChar = (char)serialPort.read();
    if (inChar >= 32 && inChar <= 126) {
      inputStr += inChar;
      if (inChar == '}') {
        complete = true;
      }
    }
  }
}

// Process command from specific serial port
void processCommand(HardwareSerial &serialPort, String inputStr) {
  inputStr.trim();

  // Validate command ends with '}'
  if (!inputStr.endsWith("}")) {
    serialPort.println("Invalid command. Missing '}' at the end.");
    return;
  }

  // Remove trailing '}'
  inputStr.remove(inputStr.length() - 1);

  // Parse command and time
  int commaIndex = inputStr.indexOf(',');
  
  if (commaIndex == -1) {
    // No comma found - old format (no time parameter)
    if (inputStr.length() > 0) {
      char dir = tolower(inputStr.charAt(0));
      executeCommand(serialPort, dir, 0);  // 0 means continuous
    }
  } else {
    // New format with time parameter
    String dirStr = inputStr.substring(0, commaIndex);
    String timeStr = inputStr.substring(commaIndex + 1);
    
    if (dirStr.length() > 0 && timeStr.length() > 0) {
      char dir = tolower(dirStr.charAt(0));
      long duration = timeStr.toInt();
      
      if (duration < 0) {
        serialPort.println("Invalid time value. Must be >= 0.");
      } else {
        executeCommand(serialPort, dir, duration);
      }
    } else {
      serialPort.println("Invalid command format. Use: direction,time}");
    }
  }
}

// Execute motor command with optional duration
void executeCommand(HardwareSerial &serialPort, char dir, long duration) {
  switch (dir) {
    case 'f':  // forward
      motor1.run(FORWARD);
      motor4.run(FORWARD);
      if (duration > 0) {
        serialPort.print("Moving Forward for ");
        serialPort.print(duration);
        serialPort.println(" ms");
        delay(duration);
        stopMotors(serialPort);
      } else {
        serialPort.println("Moving Forward (continuous)");
      }
      break;
      
    case 'b':  // backward
      motor1.run(BACKWARD);
      motor4.run(BACKWARD);
      if (duration > 0) {
        serialPort.print("Moving Backward for ");
        serialPort.print(duration);
        serialPort.println(" ms");
        delay(duration);
        stopMotors(serialPort);
      } else {
        serialPort.println("Moving Backward (continuous)");
      }
      break;
      
    case 'l':  // left turn
      motor1.run(BACKWARD);
      motor4.run(FORWARD);
      if (duration > 0) {
        serialPort.print("Turning Left for ");
        serialPort.print(duration);
        serialPort.println(" ms");
        delay(duration);
        stopMotors(serialPort);
      } else {
        serialPort.println("Turning Left (continuous)");
      }
      break;
      
    case 'r':  // right turn
      motor1.run(FORWARD);
      motor4.run(BACKWARD);
      if (duration > 0) {
        serialPort.print("Turning Right for ");
        serialPort.print(duration);
        serialPort.println(" ms");
        delay(duration);
        stopMotors(serialPort);
      } else {
        serialPort.println("Turning Right (continuous)");
      }
      break;
      
    case 's':  // stop
      stopMotors(serialPort);
      break;
      
    default:
      serialPort.println("Invalid direction. Use f, b, l, r, s.");
      break;
  }
}

// Stop all motors
void stopMotors(HardwareSerial &serialPort) {
  motor1.run(RELEASE);
  motor4.run(RELEASE);
  serialPort.println("Motors stopped");
}