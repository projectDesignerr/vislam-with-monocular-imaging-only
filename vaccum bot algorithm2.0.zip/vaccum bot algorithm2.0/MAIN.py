"""
MAIN.py
Main orchestrator for the Autonomous Navigation System
Handles initialization and coordination of all modules
"""

import cv2
import sys

from InputHandler import InputHandler
from DepthEstimationHandler import DepthEstimationHandler
from OdometryHandler import OdometryHandler
from WallFollowerHandler import WallFollowerHandler
from Hard_Linker import HardLinker

# Import IP Webcam handler for rotation vector sensor
try:
    from linker.ipwebcam_handler import IPWebcamHandler
    IPWEBCAM_AVAILABLE = True
except Exception as e:
    print(f"[WARNING] IPWebcam module not available: {e}")
    print("[WARNING] Install requests: pip install requests")
    IPWEBCAM_AVAILABLE = False
    IPWebcamHandler = None


class AutonomousNavigationSystem:
    def __init__(self, use_raspberry_pi_camera=True, raspberry_pi_ip="127.0.0.1", 
                 use_imu=True, android_ip="192.168.1.100", android_port=8181):
        """
        Initialize the autonomous navigation system and all modules
        
        Args:
            use_raspberry_pi_camera (bool): If True, use Raspberry Pi camera stream (default: True)
            raspberry_pi_ip (str): IP address of Raspberry Pi (default: 127.0.0.1 for localhost)
            use_imu (bool): If True, use Android IPWebcam for heading instead of keyboard (default: True)
            android_ip (str): IP address of Android phone with IP Webcam (default: 192.168.1.100)
            android_port (int): Port number for IP Webcam (default: 8181)
        """
        print("[MAIN] Initializing Autonomous Navigation System...")
        print(f"[MAIN] Camera source: {'Raspberry Pi' if use_raspberry_pi_camera else 'Local Webcam'}")
        if use_raspberry_pi_camera:
            print(f"[MAIN] Raspberry Pi IP: {raspberry_pi_ip}")
        print(f"[MAIN] IMU heading: {'IP Webcam Rotation Vector' if use_imu else 'Keyboard Control'}")
        if use_imu:
            print(f"[MAIN] IP Webcam: {android_ip}:{android_port}")
        
        # Initialize modules
        self.input_handler = InputHandler(
            width=640,  # Increased from 320 for better quality
            height=480,  # Increased from 240 for better quality
            use_raspberry_pi=use_raspberry_pi_camera,
            raspberry_pi_ip=raspberry_pi_ip if use_raspberry_pi_camera else None
        )
        self.depth_handler = DepthEstimationHandler(model_type="depth-anything")
        self.odometry_handler = OdometryHandler(grid_size=20, cell_size=20, use_keyboard=True)
        self.wall_follower = WallFollowerHandler()  # Wall following exploration
        self.hard_linker = HardLinker(
            raspberry_pi_ip=raspberry_pi_ip,
            odometry_handler=None  # Will be set after odometry initializes
        )  # Hardware communication
        
        # IP Webcam Handler for rotation vector sensor-based heading
        self.use_imu = use_imu
        self.imu_handler = None
        if use_imu:
            if not IPWEBCAM_AVAILABLE or IPWebcamHandler is None:
                print("[MAIN] ✗ ERROR: IPWebcam module not available!")
                print("[MAIN] Install required package: pip install requests")
                self.use_imu = False
            else:
                print("[MAIN] Initializing IP Webcam handler...")
                self.imu_handler = IPWebcamHandler(ipwebcam_ip=android_ip, ipwebcam_port=android_port)
        
        # System state
        self.is_running = False
        

        
        # Connect IP Webcam to odometry if enabled
        if self.use_imu and self.imu_handler:
            self.odometry_handler.imu_handler = self.imu_handler
            self.odometry_handler.use_imu = True
            print("[MAIN] ✓ IP Webcam handler connected to odometry")
            print("[MAIN] ✓ Odometry configured to use rotation vector heading")
        else:
            print("[MAIN] IP Webcam disabled - using keyboard for heading control")
        
        # Load depth model
        print("[MAIN] Loading depth estimation model...")
        if not self.depth_handler.load_model():
            print("[MAIN ERROR] Failed to load depth model!")
        
        # Initialize odometry display
        print("[MAIN] Initializing odometry display...")
        if not self.odometry_handler.initialize():
            print("[MAIN ERROR] Failed to initialize odometry!")
        
        # Connect odometry to hard linker for automatic position updates
        self.hard_linker.odometry_handler = self.odometry_handler
        print("[MAIN] Odometry connected to hardware linker")
        
        # Start IP Webcam connection if enabled
        if self.use_imu and self.imu_handler:
            print("[MAIN] Connecting to IP Webcam rotation vector sensor...")
            print(f"[MAIN] Target: http://{android_ip}:{android_port}/sensors.json")
            print("[MAIN] Make sure:")
            print("       1. IP Webcam app is running on Android")
            print("       2. Server is started in the app")
            print("       3. Phone and PC are on same WiFi network")
            print("       4. IP address and port are correct")
            print("[MAIN] Attempting connection...")
            
            try:
                if self.imu_handler.start():
                    print("[MAIN] ✓ IP Webcam connected successfully!")
                    import time
                    time.sleep(1.5)  # Wait for first data
                    heading = self.imu_handler.get_heading()
                    if heading is not None:
                        print(f"[MAIN] Raw heading before tare: {heading:.1f}°")
                        
                        # TARE: Set current heading as North (0°)
                        print("[MAIN] Taring IMU - setting current direction as North (0°)...")
                        if self.imu_handler.tare_heading():
                            time.sleep(0.5)  # Wait for tare to apply
                            new_heading = self.imu_handler.get_heading()
                            print(f"[MAIN] ✓ IMU tared! New heading: {new_heading:.1f}° (should be ~0°)")
                        else:
                            print("[MAIN] ✗ Tare failed - using raw heading")
                    else:
                        print("[MAIN] Waiting for sensor data...")
                else:
                    print("[MAIN] ✗ IP Webcam connection failed (will use keyboard control)")
                    print("[MAIN] Check the troubleshooting steps above")
                    self.odometry_handler.use_imu = False
            except Exception as e:
                print(f"[MAIN] ✗ IP Webcam connection error: {e}")
                print("[MAIN] Falling back to keyboard control")
                self.odometry_handler.use_imu = False
        
        print("[MAIN] System initialized successfully!")
        
        # Test Raspberry Pi connection (optional)
        print("[MAIN] Testing Raspberry Pi connection...")
        if self.hard_linker.test_connection():
            print("[MAIN] Hardware link established!")
        else:
            print("[MAIN] WARNING: Raspberry Pi not connected (will run in simulation mode)")
    
    def start(self):
        """Start the main system loop"""
        print("[MAIN] Starting system...")
        
        # Initialize input handler
        if not self.input_handler.initialize():
            print("[MAIN ERROR] Failed to initialize camera!")
            return False
        
        self.is_running = True
        print("[MAIN] System running. Press 'q' to quit.")
        print("[MAIN] Available functions:")
        print("[MAIN]   - LIDAR visualization and obstacle mapping")
        print("[MAIN]   - Wall Follower: Click 'Explorer ON/OFF' button to start/stop")
        print("[MAIN]   - Save/Load: Save/load obstacle map in Odometry window")
        print("[MAIN]   - Manual robot control via keyboard (if enabled)")
        
        # Main execution loop
        try:
            while self.is_running:
                # Get frame from camera with mirror effect
                frame = self.input_handler.get_frame(mirror=True)
                
                if frame is None:
                    print("[MAIN ERROR] Failed to capture frame!")
                    break
                
                # Flip frame vertically (upside-down correction)
                frame = cv2.flip(frame, 0)  # 0 = vertical flip
                
                # Process frame through depth estimation with grid analysis
                depth_result = self.depth_handler.estimate_depth(frame, output_size=(900, 500))
                
                # Extract LIDAR data for odometry mapping
                lidar_data = None
                avoidance_state = None
                cell_states = None
                if depth_result is not None:
                    lidar_view = depth_result['lidar_view']
                    # Get corrected LIDAR array (first row, since all rows are same after voting)
                    lidar_data = lidar_view['corrected_array'][0]
                    cell_states = depth_result['cell_states']
                    
                    # Execute wall following if enabled
                    if self.wall_follower.exploration_enabled:
                        temp_odo = self.odometry_handler.get_odometry_data()
                        if temp_odo:
                            success, duration_ms = self.wall_follower.execute_wall_following(
                                temp_odo['angle'], 
                                lidar_data,
                                temp_odo,
                                self.hard_linker
                            )
                            
                            # Wait for robot to complete movement
                            if success and duration_ms > 0:
                                import time
                                wait_time = (duration_ms / 1000.0) + 0.2
                                time.sleep(wait_time)
                                
                                # Force-complete animation to prevent position jumping
                                if self.odometry_handler.is_animating:
                                    self.odometry_handler.robot_x = self.odometry_handler.target_x
                                    self.odometry_handler.robot_y = self.odometry_handler.target_y
                                    self.odometry_handler.is_animating = False
                
                # Get wall follower state for odometry visualization
                wall_follower_state = self.wall_follower.get_exploration_state()
                
                # Update odometry with LIDAR data and exploration state
                odometry_data = self.odometry_handler.update(
                    lidar_data=lidar_data,
                    exploration_state=wall_follower_state
                )
                
                # Handle explorer button (wall follower toggle)
                if odometry_data == 'toggle_randomizer':
                    self.wall_follower.toggle_exploration()
                    odometry_data = self.odometry_handler.get_odometry_data()
                
                if odometry_data is None:
                    print("\n[MAIN] Odometry window closed.")
                    break
                
                if depth_result is not None:
                    # Display the original camera feed (no upscaling to fit laptop)
                    self.input_handler.display_frame(frame, window_name="Camera Feed", 
                                                     sharpen=True, scale=1.0)
                    
                    # Display depth map with grid overlay (no scaling to fit laptop screen)
                    self.input_handler.display_frame(
                        depth_result['depth_colored'], 
                        window_name="Depth Analysis (10x10 Grid)",
                        sharpen=False,
                        scale=1.0
                    )
                    
                    # Print grid analysis statistics and odometry
                    analysis = depth_result['analysis']
                    cell_states = depth_result['cell_states']
                    lidar_view = depth_result['lidar_view']
                    
                    # Get obstacle cells for easy access
                    obstacle_cells = self.depth_handler.get_obstacle_cells(cell_states)
                    obstacle_count = len(obstacle_cells)
                    
                    # Format LIDAR view as T,F,T,... (using first row since all rows same after voting)
                    lidar_string = ",".join(["T" if cell else "F" 
                                            for cell in lidar_view['corrected_array'][0]])
                    
                    # Wall follower status
                    wall_state = self.wall_follower.get_exploration_state()
                    if wall_state['enabled']:
                        randomizer_status = f"WALL [{wall_state['state'][:6]}] {wall_state['distance_traveled']:.0f}/{wall_state['max_distance']:.0f}"
                    else:
                        randomizer_status = "OFF"
                    
                    # Manual mode only
                    auto_status = "MANUAL"
                    
                    # Direction display based on wall follower state
                    if wall_state['enabled']:
                        direction_display = f"→ {wall_state['state'].upper()}"
                    else:
                        direction_display = "→ MANUAL"
                    
                    print(f"[LIDAR] {lidar_string} | "
                          f"Pos: ({odometry_data['x']:.1f},{odometry_data['y']:.1f}) "
                          f"Angle: {odometry_data['angle']:.0f}° | "
                          f"Mapped: {odometry_data['mapped_cells']} | "
                          f"Explorer: {randomizer_status} | "
                          f"State: {direction_display}", end='\r')
                else:
                    # Fallback: just display camera feed
                    self.input_handler.display_frame(frame, window_name="Camera Feed")
                
                # Check for keyboard commands
                key = cv2.waitKey(1) & 0xFF
                
                # Check for exit command with 'q' or 'Q'
                if key == ord('q') or key == ord('Q'):
                    print("\n[MAIN] Exit command received.")
                    break
        
        except KeyboardInterrupt:
            print("\n[MAIN] Keyboard interrupt received.")
        
        finally:
            self.stop()
        
        return True
    

    def stop(self):
        """Stop the system and cleanup resources"""
        print("[MAIN] Shutting down system...")
        self.is_running = False
        
        # Cleanup modules
        self.input_handler.cleanup()
        self.odometry_handler.cleanup()
        
        # Stop IMU if running
        if self.imu_handler:
            self.imu_handler.stop()
        
        print("[MAIN] System shutdown complete.")


def main():
    """Entry point for the autonomous navigation system"""
    import argparse
    
    print("="*60)
    print("AUTONOMOUS NAVIGATION SYSTEM - Monocular Vision")
    print("="*60)
    
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Vacuum Bot Navigation System')
    parser.add_argument('--local-camera', action='store_true', 
                       help='Use local webcam instead of Raspberry Pi camera (default: Pi camera)')
    parser.add_argument('--pi-ip', type=str, default='192.168.1.8',
                       help='Raspberry Pi IP address (default: 192.168.1.8)')
    parser.add_argument('--no-imu', action='store_false', dest='use_imu',
                       help='Disable IP Webcam rotation sensor (use keyboard control instead)')
    parser.add_argument('--use-imu', action='store_true', dest='use_imu', default=True,
                       help='Use IP Webcam rotation vector for heading (default: enabled)')
    parser.add_argument('--android-ip', type=str, default='192.168.1.100',
                       help='Android phone IP address for IP Webcam (default: 192.168.1.100)')
    parser.add_argument('--android-port', type=int, default=8181,
                       help='IP Webcam port number (default: 8181)')
    
    args = parser.parse_args()
    
    # Determine camera source (default is Pi camera, unless --local-camera flag is used)
    use_pi_camera = not args.local_camera
    
    # Print configuration
    print(f"\n[CONFIG] Camera Source: {'Raspberry Pi Stream' if use_pi_camera else 'Local Webcam'}")
    if use_pi_camera:
        print(f"[CONFIG] Raspberry Pi IP: {args.pi_ip}")
    print(f"[CONFIG] Heading Source: {'IP Webcam Rotation Vector' if args.use_imu else 'Keyboard Control'}")
    if args.use_imu:
        print(f"[CONFIG] IP Webcam: {args.android_ip}:{args.android_port}")
    print()
    
    # Create and start the system
    nav_system = AutonomousNavigationSystem(
        use_raspberry_pi_camera=use_pi_camera,
        raspberry_pi_ip=args.pi_ip,
        use_imu=args.use_imu,
        android_ip=args.android_ip,
        android_port=args.android_port
    )
    nav_system.start()
    
    print("[MAIN] Program terminated.")


if __name__ == "__main__":
    main()
