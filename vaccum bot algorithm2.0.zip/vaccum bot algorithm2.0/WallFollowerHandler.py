"""
WallFollowerHandler.py
Wall following algorithm for systematic room coverage
Keeps wall on LEFT side and follows it around the perimeter
"""

import time


class WallFollowerHandler:
    def __init__(self):
        """Initialize wall follower with LEARNING pattern-based alignment"""
        
        # States
        self.STATE_IDLE = "idle"
        self.STATE_INITIAL_ALIGNMENT = "initial_alignment"  # First-time wall detection
        self.STATE_MOVING_FORWARD = "moving_forward"
        self.STATE_TURNING_RIGHT = "turning_right"
        self.STATE_TURNING_LEFT = "turning_left"
        self.STATE_FINDING_WALL = "finding_wall"  # Lost wall, searching
        
        self.current_state = self.STATE_IDLE
        self.exploration_enabled = False
        
        # Movement tracking
        self.total_distance_traveled = 0.0  # Grid units
        self.max_exploration_distance = 40.0  # Stop after 40 grid units (~400cm)
        self.step_distance = 0.35  # Grid units per forward step (~3.5cm)
        
        # State timing
        self.state_start_time = 0.0
        self.forward_step_duration = 0.15  # seconds per forward step (150ms)
        self.alignment_tolerance = 5.0  # Accept ±5° as aligned
        
        # IMU-based turning (NO duration assumptions!)
        self.target_heading = None  # Target heading for current turn
        self.turn_start_heading = None  # Heading when turn started
        self.last_turn_time = 0.0  # Last turn command timestamp
        self.turn_pulse_duration = 100  # Small turn pulse (100ms) - no large turns!
        self.turn_step_cooldown = 0.5  # Wait 500ms between pulses for IMU to stabilize
        
        # LEARNING: Pattern recognition for wall alignment
        self.learned_pattern = None  # What "aligned with wall" looks like
        self.last_lidar_data = None  # Store last LIDAR reading
        self.pattern_history = []  # Track patterns over time
        self.wall_detected_first = False  # Flag for initial wall detection
        
        # Wall following parameters
        self.consecutive_no_wall = 0  # Track how long wall has been lost
        self.max_no_wall_count = 3  # Start searching after 3 frames without wall
        
        # Starting position tracking (for loop detection)
        self.start_x = None
        self.start_y = None
        self.returned_to_start = False
        
        # Last command tracking
        self.last_command_time = 0.0
        self.command_cooldown = 0.2  # Minimum 200ms between commands
        
        print("[WALL_FOLLOWER] Initialized - LEARNING pattern-based wall following")
    
    def toggle_exploration(self):
        """Toggle wall following exploration on/off"""
        self.exploration_enabled = not self.exploration_enabled
        
        if self.exploration_enabled:
            self.current_state = self.STATE_INITIAL_ALIGNMENT  # Start with alignment phase
            self.total_distance_traveled = 0.0
            self.consecutive_no_wall = 0
            self.returned_to_start = False
            self.wall_detected_first = False
            self.learned_pattern = None
            self.pattern_history = []
            print("[WALL_FOLLOWER] ✓ Exploration ENABLED - Learning wall pattern...")
        else:
            self.current_state = self.STATE_IDLE
            print("[WALL_FOLLOWER] ✗ Exploration DISABLED")
    
    def reset_exploration(self):
        """Reset exploration state"""
        self.current_state = self.STATE_IDLE
        self.exploration_enabled = False
        self.total_distance_traveled = 0.0
        self.consecutive_no_wall = 0
        self.start_x = None
        self.start_y = None
        self.returned_to_start = False
        self.learned_pattern = None
        self.pattern_history = []
        self.wall_detected_first = False
        print("[WALL_FOLLOWER] Reset complete")
    
    def execute_wall_following(self, current_angle, lidar_data, odometry_data, hard_linker):
        """
        Execute one step of wall following algorithm
        
        Args:
            current_angle (float): Current robot heading in degrees
            lidar_data (list): 10 boolean values [T/F] from LIDAR
            odometry_data (dict): Current position {'x': float, 'y': float}
            hard_linker: Hardware communication object
        
        Returns:
            tuple: (success: bool, duration_ms: int)
        """
        if not self.exploration_enabled:
            return (False, 0)
        
        # Check if reached max distance
        if self.total_distance_traveled >= self.max_exploration_distance:
            print(f"[WALL_FOLLOWER] ✓ Completed! Traveled {self.total_distance_traveled:.1f} grid units")
            self.exploration_enabled = False
            return (False, 0)
        
        # Check cooldown between commands
        current_time = time.time()
        if current_time - self.last_command_time < self.command_cooldown:
            return (False, 0)
        
        # Store starting position on first movement
        if self.start_x is None and odometry_data:
            self.start_x = odometry_data['x']
            self.start_y = odometry_data['y']
            print(f"[WALL_FOLLOWER] Starting position: ({self.start_x:.1f}, {self.start_y:.1f})")
        
        # Check if returned to start (loop detection)
        if self.start_x is not None and odometry_data and self.total_distance_traveled > 10.0:
            distance_to_start = ((odometry_data['x'] - self.start_x)**2 + 
                                (odometry_data['y'] - self.start_y)**2)**0.5
            if distance_to_start < 2.0:  # Within 2 grid units of start
                if not self.returned_to_start:
                    self.returned_to_start = True
                    print(f"[WALL_FOLLOWER] ✓ Returned to start area - Perimeter complete!")
                    self.exploration_enabled = False
                    return (False, 0)
        
        # Parse LIDAR data
        if not lidar_data or len(lidar_data) != 10:
            print("[WALL_FOLLOWER] Invalid LIDAR data")
            return (False, 0)
        
        # Store LIDAR for pattern learning
        self.last_lidar_data = lidar_data
        
        # LEARNING PATTERN-BASED WALL FOLLOWING
        # Execute based on current state
        if self.current_state == self.STATE_INITIAL_ALIGNMENT:
            return self._execute_initial_alignment(lidar_data, hard_linker, current_time, current_angle)
        
        elif self.current_state == self.STATE_MOVING_FORWARD:
            return self._execute_forward_with_pattern(lidar_data, hard_linker, current_angle)
        
        elif self.current_state == self.STATE_TURNING_RIGHT:
            return self._execute_turn_right(None, hard_linker, current_time, current_angle)
        
        elif self.current_state == self.STATE_TURNING_LEFT:
            return self._execute_turn_left(None, hard_linker, current_time, current_angle)
        
        elif self.current_state == self.STATE_FINDING_WALL:
            return self._execute_find_wall(lidar_data, hard_linker, current_time, current_angle)
        
        return (False, 0)
    
    def _decide_action(self, left_wall, right_wall, front_obstacle):
        """
        Decide next action based on wall sensors
        
        LEFT WALL FOLLOWING LOGIC:
        - Priority 1: Avoid front obstacle (turn RIGHT)
        - Priority 2: Find lost left wall (turn LEFT)
        - Priority 3: Follow left wall (move FORWARD)
        
        Args:
            left_wall (bool): True if wall detected on left
            right_wall (bool): True if wall detected on right
            front_obstacle (bool): True if obstacle ahead
        
        Returns:
            str: Action decision ('forward', 'turn_right', 'turn_left')
        """
        # Priority 1: Obstacle ahead - turn RIGHT to avoid
        if front_obstacle:
            self.consecutive_obstacles += 1
            print(f"[WALL_FOLLOWER] Obstacle ahead! Turn RIGHT (consecutive: {self.consecutive_obstacles})")
            return 'turn_right'
        
        # Priority 2: Lost left wall - turn LEFT to find it
        elif not left_wall and not front_obstacle:
            print("[WALL_FOLLOWER] Lost left wall - Turn LEFT to find it")
            self.consecutive_obstacles = 0  # Reset since moving freely
            return 'turn_left'
        
        # Priority 3: Wall on left, path clear ahead - move FORWARD
        elif left_wall and not front_obstacle:
            print("[WALL_FOLLOWER] Following left wall - Move FORWARD")
            self.consecutive_obstacles = 0
            return 'forward'
        
        # Edge case: Walls on both sides - move forward carefully
        elif left_wall and right_wall and not front_obstacle:
            print("[WALL_FOLLOWER] Corridor detected - Move FORWARD")
            self.consecutive_obstacles = 0
            return 'forward'
        
        # Default: Move forward
        else:
            self.consecutive_obstacles = 0
            return 'forward'
    
    def _execute_forward(self, decision, hard_linker, current_angle):
        """Execute forward movement"""
        if decision == 'turn_right':
            # Transition to turning right
            self.current_state = self.STATE_TURNING_RIGHT
            self.state_start_time = time.time()
            # Set target heading: current + 90° (turn right)
            self.turn_start_heading = current_angle
            self.target_heading = (current_angle + 90) % 360
            print(f"[WALL_FOLLOWER] Turn RIGHT: {current_angle:.0f}° → {self.target_heading:.0f}°")
            return self._execute_turn_right(decision, hard_linker, self.state_start_time, current_angle)
        
        elif decision == 'turn_left':
            # Transition to turning left
            self.current_state = self.STATE_TURNING_LEFT
            self.state_start_time = time.time()
            # Set target heading: current - 90° (turn left)
            self.turn_start_heading = current_angle
            self.target_heading = (current_angle - 90) % 360
            print(f"[WALL_FOLLOWER] Turn LEFT: {current_angle:.0f}° → {self.target_heading:.0f}°")
            return self._execute_turn_left(decision, hard_linker, self.state_start_time, current_angle)
        
        elif decision == 'forward':
            # Move forward one step
            print(f"[WALL_FOLLOWER] → FORWARD (traveled: {self.total_distance_traveled:.1f}/{self.max_exploration_distance:.1f})")
            success, duration = hard_linker.execute_movement('forward')  # Move forward
            
            if success:
                self.total_distance_traveled += self.step_distance
                self.last_command_time = time.time()
                return (True, duration)
            
            return (False, 0)
        
        return (False, 0)
    
    def _execute_turn_right(self, decision, hard_linker, current_time, current_angle):
        """Execute 90° right turn using ONLY IMU feedback - short pulses until aligned"""
        # Calculate heading difference (positive = need more right turn)
        heading_diff = self._calculate_heading_difference(current_angle, self.target_heading)
        
        # Check if aligned (within tolerance)
        if abs(heading_diff) <= self.alignment_tolerance:
            # Turn complete - transition back to forward
            self.current_state = self.STATE_MOVING_FORWARD
            actual_turned = self._calculate_heading_difference(self.turn_start_heading, current_angle)
            print(f"[WALL_FOLLOWER] ✓ RIGHT turn complete! Started: {self.turn_start_heading:.1f}° → Current: {current_angle:.1f}° (Turned: {actual_turned:.1f}°)")
            self.target_heading = None
            return (False, 0)
        
        # Check timeout (safety - don't turn forever)
        elapsed = current_time - self.state_start_time
        if elapsed > 5.0:  # 5 second timeout
            actual_turned = self._calculate_heading_difference(self.turn_start_heading, current_angle)
            print(f"[WALL_FOLLOWER] ⚠ Turn timeout - Turned: {actual_turned:.1f}° (wanted 90°) - accepting current heading")
            self.current_state = self.STATE_MOVING_FORWARD
            self.target_heading = None
            return (False, 0)
        
        # Check cooldown between turn pulses (wait for IMU to settle)
        if (current_time - self.last_turn_time) < self.turn_step_cooldown:
            return (False, 0)  # Wait before next pulse
        
        # Determine if we need to turn (check if we're going in right direction)
        # Positive heading_diff means target is clockwise from current - turn right
        if heading_diff > 0:
            # CRITICAL: Verify turn makes sense with LIDAR prediction
            if not self._verify_turn_right():
                print(f"[WALL_FOLLOWER] ⚠ RIGHT turn verification FAILED - LIDAR predicts wrong direction!")
                # Accept current heading or try opposite direction
                self.current_state = self.STATE_MOVING_FORWARD
                self.target_heading = None
                return (False, 0)
            
            # Execute SHORT turn pulse - duration doesn't matter, IMU will tell us when to stop!
            print(f"[WALL_FOLLOWER] ↻ RIGHT pulse ({self.turn_pulse_duration}ms) - Current: {current_angle:.1f}° | Target: {self.target_heading:.1f}° | Need: {heading_diff:.1f}° more")
            # Send command via Hard_Linker (it will use its own duration)
            success, _ = hard_linker.execute_movement('right')
            self.last_turn_time = time.time()
            self.last_command_time = time.time()
            return (True, self.turn_pulse_duration)
        else:
            # Overshot! Stop and accept
            print(f"[WALL_FOLLOWER] ✓ RIGHT turn overshot slightly - close enough!")
            self.current_state = self.STATE_MOVING_FORWARD
            self.target_heading = None
            return (False, 0)
    
    def _execute_turn_left(self, decision, hard_linker, current_time, current_angle):
        """Execute 90° left turn using ONLY IMU feedback - short pulses until aligned"""
        # Calculate heading difference (negative = need more left turn)
        heading_diff = self._calculate_heading_difference(current_angle, self.target_heading)
        
        # Check if aligned (within tolerance)
        if abs(heading_diff) <= self.alignment_tolerance:
            # Turn complete - transition back to forward
            self.current_state = self.STATE_MOVING_FORWARD
            actual_turned = self._calculate_heading_difference(self.turn_start_heading, current_angle)
            print(f"[WALL_FOLLOWER] ✓ LEFT turn complete! Started: {self.turn_start_heading:.1f}° → Current: {current_angle:.1f}° (Turned: {actual_turned:.1f}°)")
            self.target_heading = None
            return (False, 0)
        
        # Check timeout (safety - don't turn forever)
        elapsed = current_time - self.state_start_time
        if elapsed > 5.0:  # 5 second timeout
            actual_turned = self._calculate_heading_difference(self.turn_start_heading, current_angle)
            print(f"[WALL_FOLLOWER] ⚠ Turn timeout - Turned: {actual_turned:.1f}° (wanted -90°) - accepting current heading")
            self.current_state = self.STATE_MOVING_FORWARD
            self.target_heading = None
            return (False, 0)
        
        # Check cooldown between turn pulses (wait for IMU to settle)
        if (current_time - self.last_turn_time) < self.turn_step_cooldown:
            return (False, 0)  # Wait before next pulse
        
        # Determine if we need to turn (check if we're going in right direction)
        # Negative heading_diff means target is counterclockwise from current - turn left
        if heading_diff < 0:
            # CRITICAL: Verify turn makes sense with LIDAR prediction
            if not self._verify_turn_left():
                print(f"[WALL_FOLLOWER] ⚠ LEFT turn verification FAILED - LIDAR predicts wrong direction!")
                # Accept current heading or try opposite direction
                self.current_state = self.STATE_MOVING_FORWARD
                self.target_heading = None
                return (False, 0)
            
            # Execute SHORT turn pulse - duration doesn't matter, IMU will tell us when to stop!
            print(f"[WALL_FOLLOWER] ↺ LEFT pulse ({self.turn_pulse_duration}ms) - Current: {current_angle:.1f}° | Target: {self.target_heading:.1f}° | Need: {abs(heading_diff):.1f}° more")
            # Send command via Hard_Linker (it will use its own duration)
            success, _ = hard_linker.execute_movement('left')
            self.last_turn_time = time.time()
            self.last_command_time = time.time()
            return (True, self.turn_pulse_duration)
        else:
            # Overshot! Stop and accept
            print(f"[WALL_FOLLOWER] ✓ LEFT turn overshot slightly - close enough!")
            self.current_state = self.STATE_MOVING_FORWARD
            self.target_heading = None
            return (False, 0)
    
    def _execute_alignment(self, decision, hard_linker):
        """Execute small alignment adjustments"""
        # Small corrections to maintain distance from wall
        # (Future enhancement - for now just return to forward)
        self.current_state = self.STATE_MOVING_FORWARD
        return (False, 0)
    
    def _calculate_heading_difference(self, current, target):
        """Calculate shortest angular difference from current to target heading
        
        Returns positive for clockwise (right turn), negative for counterclockwise (left turn)
        """
        diff = target - current
        
        # Normalize to -180 to +180 range
        while diff > 180:
            diff -= 360
        while diff < -180:
            diff += 360
        
        return diff
    
    def _verify_turn_left(self):
        """CRITICAL: Verify left turn makes sense based on LIDAR prediction
        
        Example: [F,F,T,T,T,T,T,F,F,F]
        Left turn should shift obstacles right → [F,F,F,T,T,T,T,T,F,F]
        If obstacles already on left (columns 0-2), left turn is correct
        """
        if not self.last_lidar_data:
            return True  # No data, allow turn
        
        # Count obstacles in left, center, right zones
        left_zone = sum(self.last_lidar_data[0:3])    # Columns 0-2
        center_zone = sum(self.last_lidar_data[3:7])  # Columns 3-6
        right_zone = sum(self.last_lidar_data[7:10])  # Columns 7-9
        
        # Left turn prediction logic:
        # If obstacles are in center/right, turning left should move them right (good)
        # If obstacles already on far left, turning left might be wrong
        
        # Allow left turn if:
        # 1. Center has obstacles (normal avoidance)
        # 2. Right has obstacles but left doesn't (wall following)
        # 3. Balanced obstacles (trust the algorithm)
        
        if center_zone > 0:  # Center obstacle - left turn makes sense
            return True
        
        if right_zone > 0 and left_zone == 0:  # Right obstacle, left clear - good
            return True
        
        if left_zone > 0 and center_zone == 0 and right_zone == 0:  # Only left obstacle - suspicious
            print(f"[VERIFY] LEFT turn suspicious - obstacles only on left: {self.last_lidar_data}")
            return False  # Might be turning wrong way
        
        return True  # Default allow
    
    def _verify_turn_right(self):
        """CRITICAL: Verify right turn makes sense based on LIDAR prediction
        
        Example: [F,F,F,T,T,T,T,T,F,F]
        Right turn should shift obstacles left → [F,T,T,T,T,T,F,F,F,F]
        If obstacles already on right (columns 7-9), right turn is correct
        """
        if not self.last_lidar_data:
            return True  # No data, allow turn
        
        # Count obstacles in left, center, right zones
        left_zone = sum(self.last_lidar_data[0:3])    # Columns 0-2
        center_zone = sum(self.last_lidar_data[3:7])  # Columns 3-6
        right_zone = sum(self.last_lidar_data[7:10])  # Columns 7-9
        
        # Right turn prediction logic:
        # If obstacles are in center/left, turning right should move them left (good)
        # If obstacles already on far right, turning right might be wrong
        
        # Allow right turn if:
        # 1. Center has obstacles (normal avoidance)
        # 2. Left has obstacles but right doesn't (wall following)
        # 3. Balanced obstacles (trust the algorithm)
        
        if center_zone > 0:  # Center obstacle - right turn makes sense
            return True
        
        if left_zone > 0 and right_zone == 0:  # Left obstacle, right clear - good
            return True
        
        if right_zone > 0 and center_zone == 0 and left_zone == 0:  # Only right obstacle - suspicious
            print(f"[VERIFY] RIGHT turn suspicious - obstacles only on right: {self.last_lidar_data}")
            return False  # Might be turning wrong way
        
        return True  # Default allow
    
    def _execute_initial_alignment(self, lidar_data, hard_linker, current_time, current_angle):
        """INITIAL ALIGNMENT: Detect wall and learn the pattern
        
        Example: First sees [f,f,t,t,t,t,f,f,f,f]
        Goal: Turn LEFT until pattern becomes [f,f,f,f,f,t,t,f,f,f] (wall on right edge)
        """
        # Check if we see any wall (any T in LIDAR)
        has_wall = any(lidar_data)
        
        if not has_wall:
            print("[WALL_FOLLOWER] No wall detected yet - moving forward to find wall...")
            success, duration = hard_linker.execute_movement('forward')
            if success:
                self.last_command_time = time.time()
                return (True, duration)
            return (False, 0)
        
        # Wall detected! Learn the pattern
        if not self.wall_detected_first:
            self.wall_detected_first = True
            print(f"[WALL_FOLLOWER] ✓ Wall DETECTED! Pattern: {self._format_pattern(lidar_data)}")
        
        # STRICT: Check if EXACTLY 2 columns on RIGHT edge have wall
        # Perfect alignment: [f,f,f,f,f,f,f,f,t,t] - columns 8-9 (rightmost 2)
        # Accept: Columns 7-8 or 8-9 (exactly 2 adjacent columns on right)
        
        # Count consecutive T's from the right
        right_wall_count = 0
        for i in range(9, -1, -1):  # Check from right to left (9→0)
            if lidar_data[i]:
                right_wall_count += 1
            else:
                break  # Stop at first F
        
        # Check center is clear
        center_clear = not any(lidar_data[3:6])  # Columns 3-5 must be clear
        
        # STRICT: Must have EXACTLY 2 columns with wall on right edge
        if right_wall_count == 2 and center_clear:
            # PERFECT! Exactly 2 columns on right edge, center clear
            self.learned_pattern = lidar_data[:]  # Store this as good pattern
            print(f"[WALL_FOLLOWER] ✓ ALIGNED! Exactly 2 columns on right: {self._format_pattern(self.learned_pattern)}")
            self.current_state = self.STATE_MOVING_FORWARD
            return (False, 0)
        
        # Too many columns = too close
        if right_wall_count > 2:
            print(f"[WALL_FOLLOWER] ⚠ Wall too close ({right_wall_count} columns) - need LEFT turn for better alignment")
        # Too few columns = wall too far or not detected
        elif right_wall_count < 2 and right_wall_count > 0:
            print(f"[WALL_FOLLOWER] ⚠ Wall too far ({right_wall_count} column) - need LEFT turn to get closer")
        
        # Need to align - turn LEFT to move wall to right
        print(f"[WALL_FOLLOWER] Aligning LEFT... Pattern: {self._format_pattern(lidar_data)}")
        success, duration = hard_linker.execute_movement('left')
        if success:
            self.last_command_time = time.time()
            import time as time_module
            time_module.sleep(0.5)  # Wait for turn to complete
            return (True, duration)
        
        return (False, 0)
    
    def _execute_forward_with_pattern(self, lidar_data, hard_linker, current_angle):
        """FORWARD MOVEMENT: Maintain learned pattern or adapt
        
        CRITICAL: Check robot WIDTH not just camera center!
        Camera is in middle but robot has corners that can hit obstacles.
        
        Checks:
        1. Pattern matches learned pattern → move forward
        2. No wall detected (all F) → search for wall (turn RIGHT)
        3. ANY obstacle in path width (columns 1-8) → turn RIGHT to avoid
        """
        # Check if wall lost (all clear)
        has_wall = any(lidar_data)
        
        if not has_wall:
            self.consecutive_no_wall += 1
            print(f"[WALL_FOLLOWER] ⚠ Wall LOST! ({self.consecutive_no_wall}/{self.max_no_wall_count}) Pattern: {self._format_pattern(lidar_data)}")
            
            if self.consecutive_no_wall >= self.max_no_wall_count:
                # Lost wall for too long - start searching
                print("[WALL_FOLLOWER] → Entering FIND_WALL state...")
                self.current_state = self.STATE_FINDING_WALL
                return (False, 0)
            
            # Still try to move forward
            success, duration = hard_linker.execute_movement('forward')
            if success:
                self.total_distance_traveled += self.step_distance
                self.last_command_time = time.time()
                return (True, duration)
            return (False, 0)
        
        # Wall detected - reset counter
        self.consecutive_no_wall = 0
        
        # CRITICAL: Check ENTIRE robot width for obstacles (not just camera center!)
        # Robot width spans columns 1-8 (leaving 0 and 9 for wall following)
        # This prevents corners from hitting obstacles
        path_blocked = any(lidar_data[1:9])  # Columns 1-8 (robot width with safety margin)
        
        # But allow columns 7-8 if they're part of the wall we're following
        # (Don't turn away from wall we're intentionally following)
        left_corner_blocked = any(lidar_data[1:3])   # LEFT corner: columns 1-2
        center_blocked = any(lidar_data[3:7])        # CENTER path: columns 3-6
        right_corner_blocked = lidar_data[7] or lidar_data[8]  # RIGHT corner: columns 7-8
        
        # Determine if obstacle is the wall we're following or a new obstacle
        if right_corner_blocked and not center_blocked and not left_corner_blocked:
            # Only right corner blocked - this is our wall, it's OK!
            pass  # Continue forward
        elif center_blocked or left_corner_blocked:
            # Center or left corner blocked - REAL obstacle ahead!
            corner_info = []
            if left_corner_blocked:
                corner_info.append("LEFT corner")
            if center_blocked:
                corner_info.append("CENTER")
            if right_corner_blocked:
                corner_info.append("RIGHT corner")
            
            print(f"[WALL_FOLLOWER] ⚠ CORNERS would hit! Blocked: {', '.join(corner_info)} | Pattern: {self._format_pattern(lidar_data)}")
            print(f"[WALL_FOLLOWER] → Turning RIGHT to avoid...")
            
            self.current_state = self.STATE_TURNING_RIGHT
            self.state_start_time = time.time()
            self.turn_start_heading = current_angle
            self.target_heading = (current_angle + 90) % 360
            return (False, 0)
        
        # Path clear for entire robot width - move forward!
        print(f"[WALL_FOLLOWER] → FORWARD (Corners safe, wall on right) Pattern: {self._format_pattern(lidar_data)} | Traveled: {self.total_distance_traveled:.1f}/{self.max_exploration_distance:.1f}")
        success, duration = hard_linker.execute_movement('forward')
        
        if success:
            self.total_distance_traveled += self.step_distance
            self.last_command_time = time.time()
            return (True, duration)
        
        return (False, 0)
    
    def _execute_find_wall(self, lidar_data, hard_linker, current_time, current_angle):
        """FIND WALL: Turn RIGHT until wall is detected again"""
        has_wall = any(lidar_data)
        
        if has_wall:
            # Wall found! Return to forward movement
            print(f"[WALL_FOLLOWER] ✓ Wall FOUND again! Pattern: {self._format_pattern(lidar_data)}")
            self.current_state = self.STATE_INITIAL_ALIGNMENT  # Re-align with new wall
            self.consecutive_no_wall = 0
            return (False, 0)
        
        # Keep turning RIGHT to find wall
        print(f"[WALL_FOLLOWER] ↻ Searching for wall (turning RIGHT)... Pattern: {self._format_pattern(lidar_data)}")
        success, duration = hard_linker.execute_movement('right')
        if success:
            self.last_command_time = time.time()
            import time as time_module
            time_module.sleep(0.3)  # Small delay between search turns
            return (True, duration)
        
        return (False, 0)
    
    def _format_pattern(self, lidar_data):
        """Format LIDAR pattern for display"""
        return ",".join(["T" if cell else "F" for cell in lidar_data])
    
    def get_exploration_state(self):
        """Get current exploration state for visualization"""
        return {
            'enabled': self.exploration_enabled,
            'randomizer_enabled': self.exploration_enabled,  # For button display compatibility
            'state': self.current_state,
            'distance_traveled': self.total_distance_traveled,
            'max_distance': self.max_exploration_distance,
            'consecutive_no_wall': self.consecutive_no_wall,
            'returned_to_start': self.returned_to_start,
            'learned_pattern': self._format_pattern(self.learned_pattern) if self.learned_pattern else "None"
        }
