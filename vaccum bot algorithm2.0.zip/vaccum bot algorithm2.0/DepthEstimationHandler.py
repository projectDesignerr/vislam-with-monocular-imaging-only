"""
DepthEstimationHandler.py
Handles monocular depth estimation for the autonomous navigation system
Uses Depth Anything model for depth estimation with grid-based analysis
"""

import cv2
import numpy as np
import torch
from PIL import Image
from transformers import pipeline


class DepthEstimationHandler:
    def __init__(self, model_type="depth-anything"):
        """
        Initialize the Depth Estimation Handler
        
        Args:
            model_type (str): Type of depth estimation model to use (default: "depth-anything")
        """
        self.model_type = model_type
        self.depth_pipe = None
        self.is_initialized = False
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Grid configuration
        self.grid_rows = 10
        self.grid_cols = 10
        
        # Cell naming (rows: a-j, cols: 1-10)
        self.row_labels = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
        
        # Color thresholds for depth analysis (HSV)
        self.lower_yellow = (10, 50, 50)   # Close objects
        self.upper_yellow = (50, 255, 255)
        self.lower_blue = (110, 50, 50)    # Far objects
        self.upper_blue = (140, 255, 255)
        
        # Distance-based filtering (prevents false positives from distant objects)
        # INVERTED LOGIC: max_detection_distance = top X% of depth values (closest objects)
        self.max_detection_distance = 0.5  # Only detect obstacles in top 50% depth values (very close)
        self.min_obstacle_ratio = 0.35  # Require 35% of cell to be obstacle (more strict)
        
        # Multi-frame confirmation (reduce false positives)
        self.obstacle_history = {}  # {(row, col): confidence_count}
        self.confirmation_frames = 2  # Require obstacle in 2 consecutive frames
        
        print(f"[DEPTH HANDLER] Initialized with model type: {model_type}")
        print(f"[DEPTH HANDLER] Using device: {self.device}")
        print(f"[DEPTH HANDLER] Max detection range: {int(self.max_detection_distance * 100)}% depth")
        print(f"[DEPTH HANDLER] Confirmation frames: {self.confirmation_frames}")
    
    def load_model(self):
        """
        Load the depth estimation model
        
        Returns:
            bool: True if successful, False otherwise
        """
        print(f"[DEPTH HANDLER] Loading Depth Anything model...")
        
        # Try CUDA first
        try:
            print("[DEPTH HANDLER] Attempting to load on CUDA...")
            self.depth_pipe = pipeline(
                task="depth-estimation", 
                model="LiheYoung/depth-anything-base-hf",
                device=0
            )
            
            self.device = torch.device('cuda')
            self.is_initialized = True
            print("[DEPTH HANDLER] ✓ Model loaded successfully on CUDA!")
            return True
        
        except RuntimeError as e:
            if "out of memory" in str(e).lower():
                print(f"[DEPTH HANDLER] CUDA out of memory, falling back to CPU...")
                
                # Clear CUDA cache
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                
                # Try CPU
                try:
                    self.depth_pipe = pipeline(
                        task="depth-estimation", 
                        model="LiheYoung/depth-anything-base-hf",
                        device=-1  # CPU
                    )
                    
                    self.device = torch.device('cpu')
                    self.is_initialized = True
                    print("[DEPTH HANDLER] ✓ Model loaded successfully on CPU!")
                    print("[DEPTH HANDLER] Note: Processing will be slower on CPU")
                    return True
                
                except Exception as cpu_error:
                    print(f"[DEPTH HANDLER ERROR] Failed to load on CPU: {cpu_error}")
                    return False
            else:
                print(f"[DEPTH HANDLER ERROR] Failed to load model: {e}")
                return False
        
        except Exception as e:
            print(f"[DEPTH HANDLER ERROR] Failed to load model: {e}")
            return False
    
    def estimate_depth(self, frame, output_size=(640, 360)):
        """
        Estimate depth map from input frame with grid analysis
        
        Args:
            frame (numpy.ndarray): Input BGR frame from camera
            output_size (tuple): Output size (width, height) for visualization
                               (default: 640x360, reduced from 900x500 to fit laptop screens)
        
        Returns:
            dict: Contains depth_colored, grid_data, and analysis results
        """
        if not self.is_initialized:
            print("[DEPTH HANDLER WARNING] Model not loaded!")
            return None
        
        try:
            # Convert BGR to RGB for the model
            pil_image = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            
            # Run depth estimation
            result = self.depth_pipe(pil_image)
            depth = np.array(result["depth"])
            
            # Normalize and colorize depth map
            depth_vis = cv2.normalize(depth, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
            depth_colored = cv2.applyColorMap(depth_vis, cv2.COLORMAP_PLASMA)
            
            # Resize both depth and colored map to output size
            output_width, output_height = output_size
            depth_resized = cv2.resize(depth, (output_width, output_height))
            depth_colored = cv2.resize(depth_colored, (output_width, output_height))
            
            # Analyze grid with distance-based filtering
            grid_data = self._analyze_grid(depth_colored, depth_resized, output_width, output_height)
            
            # Draw grid on depth map with cell labels
            depth_with_grid = self._draw_grid(depth_colored, grid_data, output_width, output_height)
            
            # Create easy-access cell state dictionary (excluding purple/pink state)
            cell_states = self._create_cell_state_dict(grid_data['red'], grid_data['green'])
            
            # Generate LIDAR view with priority-based voting
            lidar_view = self._generate_lidar_view(grid_data['red'])
            
            return {
                'depth_colored': depth_with_grid,
                'grid_red': grid_data['red'],
                'grid_green': grid_data['green'],
                'grid_pink': grid_data['pink'],
                'analysis': grid_data['analysis'],
                'cell_states': cell_states,  # Easy data sharing structure
                'lidar_view': lidar_view     # Priority-based LIDAR view
            }
            
        except Exception as e:
            print(f"[DEPTH HANDLER ERROR] Depth estimation failed: {e}")
            return None

    
    def _analyze_grid(self, depth_colored, depth_raw, output_width, output_height):
        """
        Analyze depth map using grid-based approach with distance filtering
        
        Args:
            depth_colored (numpy.ndarray): Colored depth map (for visualization)
            depth_raw (numpy.ndarray): Raw depth values (for accurate distance measurement)
            output_width (int): Width of depth map
            output_height (int): Height of depth map
        
        Returns:
            dict: Grid analysis results
        """
        cell_h = output_height // self.grid_rows
        cell_w = output_width // self.grid_cols
        
        # Calculate depth percentiles for adaptive thresholding
        depth_min = np.min(depth_raw)
        depth_max = np.max(depth_raw)
        depth_range = depth_max - depth_min
        
        # CRITICAL FIX: Depth Anything outputs INVERSE depth (lower = farther, higher = closer)
        # So we need to INVERT the logic: higher values = closer objects = obstacles
        # Obstacle threshold: objects in HIGHEST X% of depth range (closest to robot)
        obstacle_threshold = depth_max - (depth_range * self.max_detection_distance)
        
        # Initialize grids
        grid_red = [[False] * self.grid_cols for _ in range(self.grid_rows)]
        grid_green = [[False] * self.grid_cols for _ in range(self.grid_rows)]
        grid_pink = [[False] * self.grid_cols for _ in range(self.grid_rows)]
        
        # Track new obstacle detections for confidence building
        new_obstacle_history = {}
        
        # Analyze each cell
        for r in range(self.grid_rows):
            for c in range(self.grid_cols):
                x1, y1 = c * cell_w, r * cell_h
                x2, y2 = x1 + cell_w, y1 + cell_h
                
                # Extract depth values for this cell
                cell_depth = depth_raw[y1:y2, x1:x2]
                cell_pixels = cell_depth.size
                
                # INVERTED: Count pixels ABOVE obstacle threshold (close objects have high values)
                obstacle_pixels = np.sum(cell_depth >= obstacle_threshold)
                obstacle_ratio = obstacle_pixels / cell_pixels
                
                # INVERTED: Count pixels in far range (low values = far away)
                far_threshold = depth_min + (depth_range * 0.15)
                far_pixels = np.sum(cell_depth <= far_threshold)
                far_ratio = far_pixels / cell_pixels
                
                # Temporary obstacle detection (before confirmation)
                is_obstacle_temp = obstacle_ratio > self.min_obstacle_ratio
                
                # Multi-frame confirmation for obstacles
                cell_key = (r, c)
                if is_obstacle_temp:
                    # Increment confidence
                    confidence = self.obstacle_history.get(cell_key, 0) + 1
                    new_obstacle_history[cell_key] = confidence
                    
                    # Only mark as RED if confirmed across multiple frames
                    if confidence >= self.confirmation_frames:
                        grid_red[r][c] = True
                    else:
                        # Still confirming - mark as PINK (caution)
                        grid_pink[r][c] = True
                else:
                    # Clear confidence if no obstacle detected
                    new_obstacle_history[cell_key] = 0
                    
                    # Classify as GREEN or PINK based on distance
                    if far_ratio > 0.3:  # Far/safe (GREEN)
                        grid_green[r][c] = True
                    else:  # Medium distance (PINK)
                        grid_pink[r][c] = True
        
        # Update obstacle history
        self.obstacle_history = new_obstacle_history
        
        # Calculate statistics for decision making
        analysis = self._calculate_grid_statistics(grid_red, grid_green, grid_pink)
        
        return {
            'red': grid_red,
            'green': grid_green,
            'pink': grid_pink,
            'analysis': analysis
        }
    
    def _draw_grid(self, depth_colored, grid_data, output_width, output_height):
        """
        Draw grid overlay on depth map with color coding and cell labels
        
        Args:
            depth_colored (numpy.ndarray): Colored depth map
            grid_data (dict): Grid analysis data
            output_width (int): Width of output
            output_height (int): Height of output
        
        Returns:
            numpy.ndarray: Depth map with grid overlay
        """
        result = depth_colored.copy()
        cell_h = output_height // self.grid_rows
        cell_w = output_width // self.grid_cols
        
        for r in range(self.grid_rows):
            for c in range(self.grid_cols):
                x1, y1 = c * cell_w, r * cell_h
                x2, y2 = x1 + cell_w, y1 + cell_h
                
                # Color based on grid state
                if grid_data['red'][r][c]:
                    color = (0, 0, 255)  # Red - obstacle
                elif grid_data['green'][r][c]:
                    color = (0, 255, 0)  # Green - safe
                else:
                    color = (180, 105, 255)  # Pink - caution
                
                cv2.rectangle(result, (x1, y1), (x2, y2), color, 2)
                
                # Add cell label (e.g., a1, b3, etc.)
                cell_name = f"{self.row_labels[r]}{c+1}"
                label_x = x1 + 5
                label_y = y1 + 15
                
                # Draw label with background for readability
                cv2.putText(result, cell_name, (label_x, label_y), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 1)
        
        return result
    
    def _calculate_grid_statistics(self, grid_red, grid_green, grid_pink):
        """
        Calculate statistics from grid for decision making
        
        Args:
            grid_red (list): Red grid cells (obstacles)
            grid_green (list): Green grid cells (safe)
            grid_pink (list): Pink grid cells (caution)
        
        Returns:
            dict: Statistics for navigation decisions
        """
        # Count pink cells in top 8 rows (clear path indicator)
        top_pink_count = sum(grid_pink[r][c] for r in range(0, 8) 
                            for c in range(self.grid_cols))
        
        # Count red cells on left side (left obstacle)
        left_red_count = sum(grid_red[r][c] for r in range(0, 8) 
                            for c in range(0, 5))
        
        # Count red cells on right side (right obstacle)
        right_red_count = sum(grid_red[r][c] for r in range(0, 8) 
                             for c in range(6, 10))
        
        # Count total green cells (safe to move forward)
        green_count = sum(grid_green[r][c] for r in range(self.grid_rows) 
                         for c in range(self.grid_cols))
        
        return {
            'top_pink_count': top_pink_count,
            'left_red_count': left_red_count,
            'right_red_count': right_red_count,
            'green_count': green_count
        }
    
    def _create_cell_state_dict(self, grid_red, grid_green):
        """
        Create easy-access dictionary for cell states (obstacle detection)
        Excludes purple/pink state, only returns True for obstacles (red) or safe (green)
        
        Args:
            grid_red (list): Red grid cells (obstacles)
            grid_green (list): Green grid cells (safe)
        
        Returns:
            dict: Cell states in format {'a1': True/False, 'b3': True/False, ...}
                  True = Obstacle detected (RED)
                  False = Safe/Clear (GREEN or PINK)
        """
        cell_states = {}
        
        for r in range(self.grid_rows):
            for c in range(self.grid_cols):
                cell_name = f"{self.row_labels[r]}{c+1}"
                
                # True if obstacle detected (RED), False otherwise
                cell_states[cell_name] = grid_red[r][c]
        
        return cell_states
    
    def get_obstacle_cells(self, cell_states):
        """
        Get list of cells with obstacles detected
        
        Args:
            cell_states (dict): Cell states dictionary
        
        Returns:
            list: List of cell names where obstacles are detected
        """
        return [cell for cell, has_obstacle in cell_states.items() if has_obstacle]
    
    def get_safe_cells(self, cell_states):
        """
        Get list of safe cells (no obstacles)
        
        Args:
            cell_states (dict): Cell states dictionary
        
        Returns:
            list: List of cell names that are safe
        """
        return [cell for cell, has_obstacle in cell_states.items() if not has_obstacle]
    
    def _generate_lidar_view(self, grid_red):
        """
        Generate LIDAR view using priority-based voting algorithm
        
        Process:
        1. Extract rows c-g (indices 2-6) and columns 1-10 (excluding h-i as floor)
        2. Create 5x10 data array (T/F for obstacles)
        3. Apply priority voting: T=2, F=1
        4. Column-wise voting from row c→d→e→f→g
        5. Majority priority wins per column
        
        Args:
            grid_red (list): Red grid cells (obstacles)
        
        Returns:
            dict: LIDAR view with raw data and corrected data
        """
        # Extract rows c-g (indices 2-6) and all columns (0-9 for columns 1-10)
        # Rows h-i (7-8) are excluded as they represent floor
        row_start = 2  # Row 'c'
        row_end = 7    # Row 'g' (exclusive end, so 2-6 inclusive)
        
        # Create raw 5x10 data array (rows c-g, columns 1-10)
        raw_data = []
        for r in range(row_start, row_end):
            row_data = []
            for c in range(self.grid_cols):
                row_data.append(grid_red[r][c])  # True/False
            raw_data.append(row_data)
        
        # Apply priority-based voting per column
        corrected_data = self._apply_priority_voting(raw_data)
        
        # Convert to human-readable format
        lidar_view = {
            'raw_array': raw_data,           # Original 5x10 array
            'corrected_array': corrected_data,  # After priority voting
            'raw_string': self._format_lidar_string(raw_data),
            'corrected_string': self._format_lidar_string(corrected_data),
            'rows': ['c', 'd', 'e', 'f', 'g'],
            'columns': list(range(1, 11))
        }
        
        return lidar_view
    
    def _apply_priority_voting(self, data_array):
        """
        Apply priority-based voting algorithm column-wise
        
        Priority: T (obstacle) = 2, F (clear) = 1
        Vote from top to bottom (row c → g)
        Majority priority wins
        
        Args:
            data_array (list): 5x10 array of True/False
        
        Returns:
            list: Corrected 5x10 array after voting
        """
        num_rows = len(data_array)
        num_cols = len(data_array[0])
        
        corrected = []
        
        # Process each row
        for r in range(num_rows):
            corrected_row = []
            
            # Process each column
            for c in range(num_cols):
                # Collect all values in this column
                column_values = [data_array[row][c] for row in range(num_rows)]
                
                # Calculate priority scores
                true_count = sum(1 for v in column_values if v)
                false_count = sum(1 for v in column_values if not v)
                
                # Priority: T=2, F=1
                true_priority = true_count * 2
                false_priority = false_count * 1
                
                # Winner by priority
                if true_priority > false_priority:
                    corrected_row.append(True)
                else:
                    corrected_row.append(False)
            
            corrected.append(corrected_row)
        
        return corrected
    
    def _format_lidar_string(self, data_array):
        """
        Format data array as readable string
        
        Args:
            data_array (list): 7x10 array
        
        Returns:
            str: Formatted string representation
        """
        rows = ['c', 'd', 'e', 'f', 'g', 'h', 'i']
        lines = []
        
        # Header with column numbers
        header = "    " + " ".join([f"{i:2d}" for i in range(1, 11)])
        lines.append(header)
        lines.append("    " + "-" * 30)
        
        # Each row
        for idx, row_data in enumerate(data_array):
            row_label = rows[idx]
            row_str = " ".join(["T" if cell else "F" for cell in row_data])
            lines.append(f" {row_label}  {row_str}")
        
        return "\n".join(lines)
    
    def get_depth_statistics(self, depth_map):
        """
        Calculate statistics from depth map
        
        Args:
            depth_map (numpy.ndarray): Depth map to analyze
        
        Returns:
            dict: Dictionary containing depth statistics
        """
        if depth_map is None or depth_map.size == 0:
            return None
        
        stats = {
            'min_depth': np.min(depth_map),
            'max_depth': np.max(depth_map),
            'mean_depth': np.mean(depth_map),
            'median_depth': np.median(depth_map),
            'std_depth': np.std(depth_map)
        }
        
        return stats
    
    def _classify_cell_distance(self, depth_patch, depth_min, depth_max):
        """
        Classify a cell's distance based on actual depth values with improved thresholding
        
        Args:
            depth_patch: numpy array of depth values for this cell
            depth_min: minimum depth in scene (closest)
            depth_max: maximum depth in scene (farthest)
        
        Returns:
            tuple: (is_obstacle, confidence, mean_depth)
        """
        if depth_patch.size == 0:
            return False, 0.0, 0.0
        
        # Calculate mean depth for this cell
        mean_depth = np.mean(depth_patch)
        
        # Normalize to 0-1 range
        depth_range = depth_max - depth_min
        if depth_range < 1e-6:  # Avoid division by zero
            return False, 0.0, mean_depth
        
        # IMPORTANT: Check if depth is inverted (some models output inverse depth)
        # If mean_depth is closer to depth_min, it means object is CLOSE
        # If mean_depth is closer to depth_max, it means object is FAR
        
        normalized_depth = (mean_depth - depth_min) / depth_range
        
        # **FIX: Invert if model outputs inverse depth**
        # Depth Anything outputs: lower values = farther, higher values = closer
        # So we need to INVERT: 1.0 - normalized_depth
        normalized_depth = 1.0 - normalized_depth
        
        # Now: 0.0 = far, 1.0 = close
        
        # Adaptive threshold: only closest 40% of depth range are obstacles
        # This prevents far walls/objects from being marked as obstacles
        obstacle_threshold = 0.40  # Reduced from 0.7 to be more conservative
        
        # Calculate variance for confidence (low variance = uniform depth = higher confidence)
        variance = np.var(depth_patch)
        max_variance = 0.1  # Normalize variance
        confidence = 1.0 - min(variance / max_variance, 1.0)
        
        # Cell is obstacle if: normalized_depth > threshold (close to robot)
        is_obstacle = normalized_depth > obstacle_threshold
        
        return is_obstacle, confidence, mean_depth
