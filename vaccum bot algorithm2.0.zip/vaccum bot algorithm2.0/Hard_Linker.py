"""
Hard_Linker.py
Bridges the gap between Python decision modules and Raspberry Pi/Arduino hardware
Converts obstacle avoidance decisions into motor commands with adaptive speed control
"""

import requests
import time
from collections import deque


class HardLinker:
    def __init__(self, raspberry_pi_ip="127.0.0.1", port=5000, odometry_handler=None):
        """
        Initialize the Hardware Linker
        
        Args:
            raspberry_pi_ip (str): IP address of Raspberry Pi (default: 127.0.0.1 for localhost)
            port (int): HTTP server port (default: 5000 - unified server)
            odometry_handler: Reference to OdometryHandler for position updates
        """
        self.raspberry_pi_ip = raspberry_pi_ip
        self.port = port
        self.base_url = f"http://{raspberry_pi_ip}:{port}"
        self.odometry_handler = odometry_handler  # Store reference to odometry
        
        # Movement duration settings (milliseconds) based on environment
        # At 0.35 cm/ms (35 cm/s), these durations produce:
        # 200ms = 7cm, 150ms = 5.25cm, 100ms = 3.5cm
        self.DURATION_MAX_SPEED = 200      # Clear path - 7cm per move
        self.DURATION_MEDIUM_SPEED = 150   # Some obstacles - 5.25cm per move
        self.DURATION_SLOW_SPEED = 100     # Many obstacles - 3.5cm per move
        self.DURATION_TURN = 100            # Turn duration (100ms for small incremental turns)
        
        # Command history for debugging
        self.command_history = deque(maxlen=50)
        
        # Connection status
        self.is_connected = False
        self.last_command_time = 0
        self.min_command_interval = 0.1  # Minimum 100ms between commands
        
        print(f"[HARD LINKER] Initialized")
        print(f"[HARD LINKER] Target: {self.base_url}")
        print(f"[HARD LINKER] Speed profiles:")
        print(f"[HARD LINKER]   - Clear path: {self.DURATION_MAX_SPEED}ms")
        print(f"[HARD LINKER]   - Caution: {self.DURATION_MEDIUM_SPEED}ms")
        print(f"[HARD LINKER]   - Obstacles nearby: {self.DURATION_SLOW_SPEED}ms")
    
    def test_connection(self):
        """
        Test connection to Raspberry Pi server
        
        Returns:
            bool: True if connected, False otherwise
        """
        try:
            response = requests.get(f"{self.base_url}/status", timeout=2)
            if response.status_code == 200:
                self.is_connected = True
                print("[HARD LINKER] ✓ Connection successful!")
                return True
            else:
                self.is_connected = False
                print(f"[HARD LINKER] ✗ Connection failed: Status {response.status_code}")
                return False
        except requests.exceptions.RequestException as e:
            self.is_connected = False
            print(f"[HARD LINKER] ✗ Connection failed: {e}")
            return False
    
    def analyze_environment(self, cell_states, lidar_data):
        """
        Analyze environment density to determine movement speed
        Uses cell states and LIDAR data to assess obstacle proximity
        
        Args:
            cell_states (dict): Cell states from DepthEstimationHandler
            lidar_data (list): LIDAR array [T,F,T,...] (10 values)
        
        Returns:
            str: Speed profile ('fast', 'medium', 'slow')
        """
        if not cell_states or not lidar_data:
            return 'medium'  # Default to caution
        
        # Count obstacles in critical forward zones (rows d-g, center columns 3-8)
        critical_cells = [
            'd3', 'd4', 'd5', 'd6', 'd7', 'd8',
            'e3', 'e4', 'e5', 'e6', 'e7', 'e8',
            'f3', 'f4', 'f5', 'f6', 'f7', 'f8',
            'g3', 'g4', 'g5', 'g6', 'g7', 'g8'
        ]
        
        obstacle_count = sum(1 for cell in critical_cells 
                           if cell_states.get(cell, False))
        
        # Count LIDAR obstacles in center zones (3,4,5)
        lidar_center_obstacles = sum(1 for i in [3, 4, 5] if lidar_data[i])
        
        # Count total obstacles in forward view (rows c-g only, h-i excluded as floor)
        forward_cells = [f"{row}{col}" for row in ['c','d','e','f','g'] 
                        for col in range(1, 11)]
        total_obstacles = sum(1 for cell in forward_cells 
                            if cell_states.get(cell, False))
        
        # Decision logic
        if lidar_center_obstacles >= 2:
            # Center path has obstacles - move slowly
            speed_profile = 'slow'
        elif obstacle_count >= 8:
            # Many obstacles in critical zone - move slowly
            speed_profile = 'slow'
        elif total_obstacles >= 20:
            # Dense environment - move cautiously
            speed_profile = 'medium'
        elif total_obstacles <= 5:
            # Clear path - move fast
            speed_profile = 'fast'
        else:
            # Moderate obstacles - medium speed
            speed_profile = 'medium'
        
        return speed_profile
    
    def get_movement_duration(self, speed_profile):
        """
        Get movement duration based on speed profile
        
        Args:
            speed_profile (str): 'fast', 'medium', or 'slow'
        
        Returns:
            int: Duration in milliseconds
        """
        if speed_profile == 'fast':
            return self.DURATION_MAX_SPEED
        elif speed_profile == 'slow':
            return self.DURATION_SLOW_SPEED
        else:
            return self.DURATION_MEDIUM_SPEED
    
    def send_command(self, command_string):
        """
        Send command string to Raspberry Pi via HTTP POST
        
        Args:
            command_string (str): Command in format "direction,duration}"
        
        Returns:
            bool: True if successful, False otherwise
        """
        # Rate limiting - prevent command spam
        current_time = time.time()
        if current_time - self.last_command_time < self.min_command_interval:
            print(f"[HARD LINKER] ⏸ Rate limited (too soon)")
            return False
        
        print(f"[HARD LINKER] 📤 Attempting to send: {command_string}")
        try:
            response = requests.post(
                f"{self.base_url}/send",
                json={'data': command_string},
                timeout=1
            )
            
            if response.status_code == 200:
                self.last_command_time = current_time
                self.command_history.append({
                    'time': time.strftime('%H:%M:%S'),
                    'command': command_string,
                    'status': 'success'
                })
                print(f"[HARD LINKER] ✓ Sent: {command_string}")
                
                # Update odometry if handler is connected
                if self.odometry_handler:
                    # Parse command: "f,1000}" -> command='f', duration=1000
                    parts = command_string.rstrip('}').split(',')
                    if len(parts) == 2:
                        cmd = parts[0]
                        duration = int(parts[1])
                        self.odometry_handler.update_from_command(cmd, duration)
                
                return True
            else:
                print(f"[HARD LINKER] ✗ Failed: Status {response.status_code}")
                return False
        
        except requests.exceptions.RequestException as e:
            print(f"[HARD LINKER] ✗ Error: {e}")
            self.command_history.append({
                'time': time.strftime('%H:%M:%S'),
                'command': command_string,
                'status': 'failed'
            })
            return False
    
    def execute_movement(self, direction, cell_states=None, lidar_data=None):
        """
        Execute movement command with adaptive speed control
        
        Args:
            direction (str): 'forward', 'left', 'right', 'backward', 'stop'
            cell_states (dict): Optional cell states for speed adaptation
            lidar_data (list): Optional LIDAR data for speed adaptation
        
        Returns:
            tuple: (success: bool, duration: int) - True if command sent, duration in ms
        """
        # Map direction to Arduino command
        command_map = {
            'forward': 'f',
            'backward': 'b',
            'left': 'l',
            'right': 'r',
            'stop': 's'
        }
        
        if direction not in command_map:
            print(f"[HARD LINKER] ✗ Invalid direction: {direction}")
            return (False, 0)
        
        arduino_cmd = command_map[direction]
        
        # Determine duration based on direction and environment
        if direction == 'stop':
            # Stop command doesn't need duration
            duration = 0
        elif direction in ['left', 'right']:
            # Turns always use fixed duration
            duration = self.DURATION_TURN
        else:
            # Forward/backward - use adaptive speed
            if cell_states and lidar_data:
                speed_profile = self.analyze_environment(cell_states, lidar_data)
                duration = self.get_movement_duration(speed_profile)
                print(f"[HARD LINKER] Environment: {speed_profile.upper()} → {duration}ms")
            else:
                # No environment data - use medium speed
                duration = self.DURATION_MEDIUM_SPEED
        
        # Format command string
        command_string = f"{arduino_cmd},{duration}" + "}"
        
        # Send command
        success = self.send_command(command_string)
        return (success, duration)
    
    def execute_avoidance(self, avoidance_state, cell_states=None, lidar_data=None):
        """
        Execute avoidance maneuver based on ObstacleAvoidanceHandler output
        
        Args:
            avoidance_state (dict): State from ObstacleAvoidanceHandler.update()
            cell_states (dict): Optional cell states for speed adaptation
            lidar_data (list): Optional LIDAR data for speed adaptation
        
        Returns:
            tuple: (success: bool, duration: int) - True if command sent, duration in ms
        """
        if not avoidance_state:
            return (False, 0)
        
        direction = avoidance_state.get('direction', 'forward')
        
        return self.execute_movement(direction, cell_states, lidar_data)
    
    def emergency_stop(self):
        """
        Send emergency stop command immediately
        
        Returns:
            bool: True if stop command sent
        """
        print("[HARD LINKER] !!! EMERGENCY STOP !!!")
        return self.send_command("s,0}")
    
    def get_command_history(self, count=10):
        """
        Get recent command history
        
        Args:
            count (int): Number of recent commands to return
        
        Returns:
            list: List of recent commands
        """
        return list(self.command_history)[-count:]
    
    def set_raspberry_pi_ip(self, new_ip):
        """
        Update Raspberry Pi IP address
        
        Args:
            new_ip (str): New IP address
        """
        self.raspberry_pi_ip = new_ip
        self.base_url = f"http://{new_ip}:{self.port}"
        self.is_connected = False
        print(f"[HARD LINKER] Updated target: {self.base_url}")
        print(f"[HARD LINKER] Please run test_connection() to verify")
    
    def get_status(self):
        """
        Get current linker status
        
        Returns:
            dict: Status information
        """
        return {
            'connected': self.is_connected,
            'target_url': self.base_url,
            'commands_sent': len(self.command_history),
            'last_command_time': time.strftime('%H:%M:%S', 
                                              time.localtime(self.last_command_time))
        }


# ============================================
# STANDALONE TESTING
# ============================================

if __name__ == "__main__":
    print("="*60)
    print("HARD LINKER - Standalone Test")
    print("="*60)
    
    # Create linker instance
    linker = HardLinker(raspberry_pi_ip="192.168.1.100")
    
    # Test connection
    print("\n[TEST] Testing connection to Raspberry Pi...")
    if linker.test_connection():
        print("[TEST] ✓ Connection successful!")
        
        # Test commands
        print("\n[TEST] Sending test commands...")
        
        # Test forward movement with different speeds
        print("\n--- Test 1: Forward (Fast) ---")
        linker.execute_movement('forward', cell_states={'d4': False, 'd5': False}, 
                               lidar_data=[False]*10)
        time.sleep(1.2)
        
        print("\n--- Test 2: Forward (Slow) ---")
        # Simulate obstacle-rich environment
        obstacle_cells = {f"{row}{col}": True 
                         for row in ['d','e','f'] for col in [3,4,5,6,7]}
        linker.execute_movement('forward', cell_states=obstacle_cells, 
                               lidar_data=[True]*10)
        time.sleep(0.5)
        
        print("\n--- Test 3: Turn Left ---")
        linker.execute_movement('left')
        time.sleep(1.0)
        
        print("\n--- Test 4: Turn Right ---")
        linker.execute_movement('right')
        time.sleep(1.0)
        
        print("\n--- Test 5: Stop ---")
        linker.execute_movement('stop')
        
        # Show command history
        print("\n[TEST] Command History:")
        for cmd in linker.get_command_history():
            print(f"  {cmd['time']} - {cmd['command']} ({cmd['status']})")
        
        # Show status
        print("\n[TEST] Linker Status:")
        status = linker.get_status()
        for key, value in status.items():
            print(f"  {key}: {value}")
    
    else:
        print("[TEST] ✗ Connection failed!")
        print("[TEST] Make sure Raspberry Pi server is running")
        print("[TEST] Update IP address in code if needed")
    
    print("\n" + "="*60)
    print("Test complete!")
    print("="*60)
