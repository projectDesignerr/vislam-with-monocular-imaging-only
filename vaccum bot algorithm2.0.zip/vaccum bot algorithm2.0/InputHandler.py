"""
InputHandler.py
Handles sophisticated input/output operations for the autonomous navigation system
Manages webcam capture, frame processing, and display
Supports both local webcam and remote Raspberry Pi camera stream
"""

import cv2
import numpy as np
import requests
from io import BytesIO


class InputHandler:
    def __init__(self, width=320, height=240, camera_id=0, use_raspberry_pi=False, raspberry_pi_ip=None):
        """
        Initialize the Input Handler
        
        Args:
            width (int): Frame width (default: 320)
            height (int): Frame height (default: 240)
            camera_id (int): Camera device ID (default: 0 for laptop webcam)
            use_raspberry_pi (bool): If True, use Raspberry Pi camera stream instead of local webcam
            raspberry_pi_ip (str): IP address of Raspberry Pi (required if use_raspberry_pi=True)
        """
        self.width = width
        self.height = height
        self.camera_id = camera_id
        self.use_raspberry_pi = use_raspberry_pi
        self.raspberry_pi_ip = raspberry_pi_ip
        self.camera = None
        self.stream = None  # Not used anymore for Pi camera, kept for compatibility
        self.frame_url = None  # URL for on-demand frame fetching
        self.is_initialized = False
        
        if self.use_raspberry_pi:
            if not self.raspberry_pi_ip:
                raise ValueError("raspberry_pi_ip must be provided when use_raspberry_pi=True")
            self.stream_url = f"http://{self.raspberry_pi_ip}:5000/video_feed"  # Legacy continuous stream
            self.frame_url = f"http://{self.raspberry_pi_ip}:5000/get_frame"  # On-demand frame fetch
            print(f"[INPUT HANDLER] Configured for Raspberry Pi on-demand frame fetching")
            print(f"[INPUT HANDLER] Frame URL: {self.frame_url}")
        else:
            print(f"[INPUT HANDLER] Configured for local camera {camera_id} at {width}x{height}")
    
    def initialize(self):
        """
        Initialize the camera capture (local or remote)
        
        Returns:
            bool: True if successful, False otherwise
        """
        if self.use_raspberry_pi:
            return self._initialize_pi_stream()
        else:
            return self._initialize_local_camera()
    
    def _initialize_local_camera(self):
        """
        Initialize local webcam capture
        
        Returns:
            bool: True if successful, False otherwise
        """
        print(f"[INPUT HANDLER] Initializing local camera {self.camera_id}...")
        
        try:
            self.camera = cv2.VideoCapture(self.camera_id)
            
            if not self.camera.isOpened():
                print("[INPUT HANDLER ERROR] Could not open camera!")
                return False
            
            # Set camera properties
            self.camera.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
            self.camera.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
            
            # Verify resolution
            actual_width = int(self.camera.get(cv2.CAP_PROP_FRAME_WIDTH))
            actual_height = int(self.camera.get(cv2.CAP_PROP_FRAME_HEIGHT))
            print(f"[INPUT HANDLER] Local camera opened at {actual_width}x{actual_height}")
            
            self.is_initialized = True
            return True
        
        except Exception as e:
            print(f"[INPUT HANDLER ERROR] Exception during initialization: {e}")
            return False
    
    def _initialize_pi_stream(self):
        """
        Initialize Raspberry Pi camera stream (ACK-based on-demand fetching)
        
        Returns:
            bool: True if successful, False otherwise
        """
        print(f"[INPUT HANDLER] Connecting to Raspberry Pi camera stream...")
        print(f"[INPUT HANDLER] Using on-demand frame fetching (ACK-based) for low latency")
        
        try:
            # Test connection by trying to get a single frame
            test_url = f"http://{self.raspberry_pi_ip}:5000/get_frame"
            response = requests.get(test_url, timeout=5)
            
            if response.status_code != 200:
                print(f"[INPUT HANDLER ERROR] Cannot connect to Pi camera: HTTP {response.status_code}")
                return False
            
            # Store the frame fetch URL
            self.frame_url = test_url
            
            print(f"[INPUT HANDLER] ✓ Connected to Raspberry Pi camera (on-demand mode)")
            print(f"[INPUT HANDLER] Frame URL: {self.frame_url}")
            self.is_initialized = True
            return True
        
        except requests.exceptions.RequestException as e:
            print(f"[INPUT HANDLER ERROR] Connection error: {e}")
            print("[INPUT HANDLER] Make sure Raspberry Pi server is running!")
            return False
        except Exception as e:
            print(f"[INPUT HANDLER ERROR] Exception during Pi stream initialization: {e}")
            return False
    
    def get_frame(self, mirror=False):
        """
        Capture a frame from the camera (local or remote)
        
        Args:
            mirror (bool): If True, horizontally flip the frame
        
        Returns:
            numpy.ndarray: The captured frame, or None if capture failed
        """
        if not self.is_initialized:
            print("[INPUT HANDLER ERROR] Camera not initialized!")
            return None
        
        # Get frame from appropriate source
        if self.use_raspberry_pi:
            frame = self._get_pi_frame()
        else:
            frame = self._get_local_frame()
        
        if frame is None:
            return None
        
        # Ensure frame is at the correct resolution
        if frame.shape[1] != self.width or frame.shape[0] != self.height:
            frame = cv2.resize(frame, (self.width, self.height))
        
        # Apply mirror effect if requested
        if mirror:
            frame = cv2.flip(frame, 1)  # 1 = horizontal flip
        
        return frame
    
    def _get_local_frame(self):
        """
        Get frame from local webcam
        
        Returns:
            numpy.ndarray: The captured frame, or None if capture failed
        """
        if self.camera is None:
            return None
        
        ret, frame = self.camera.read()
        
        if not ret:
            print("[INPUT HANDLER ERROR] Failed to read local camera frame!")
            return None
        
        return frame
    
    def _get_pi_frame(self):
        """
        Get frame from Raspberry Pi using on-demand ACK-based fetching
        Fetches one frame per request, preventing buffering and latency
        
        Returns:
            numpy.ndarray: The captured frame, or None if capture failed
        """
        try:
            # Request a single frame (ACK - frame is only sent when we request it)
            response = requests.get(self.frame_url, timeout=10)  # Increased timeout to 10 seconds
            
            if response.status_code != 200:
                print(f"[INPUT HANDLER ERROR] Failed to get frame: HTTP {response.status_code}")
                return None
            
            # Decode JPEG image from response
            img_array = np.frombuffer(response.content, dtype=np.uint8)
            frame = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
            
            if frame is None:
                print("[INPUT HANDLER ERROR] Failed to decode frame")
                return None
            
            return frame
            
        except requests.exceptions.Timeout:
            print("[INPUT HANDLER WARNING] Frame request timeout")
            return None
        except requests.exceptions.RequestException as e:
            print(f"[INPUT HANDLER ERROR] Request error: {e}")
            return None
        except Exception as e:
            print(f"[INPUT HANDLER ERROR] Error getting Pi frame: {e}")
            return None
    
    def display_frame(self, frame, window_name="Display", sharpen=True, scale=2.0):
        """
        Display a frame in a window with optional sharpening and upscaling
        
        Args:
            frame (numpy.ndarray): The frame to display
            window_name (str): Name of the display window
            sharpen (bool): Apply sharpening filter to reduce blur (default: True)
            scale (float): Upscale factor for display (default: 2.0 for 2x size)
        """
        if frame is None:
            print("[INPUT HANDLER ERROR] Cannot display None frame!")
            return
        
        display_frame = frame.copy()
        
        # Apply sharpening to reduce blur (especially helpful for motion blur)
        if sharpen and window_name == "Camera Feed":
            # Create sharpening kernel
            kernel = np.array([[-1, -1, -1],
                              [-1,  9, -1],
                              [-1, -1, -1]])
            display_frame = cv2.filter2D(display_frame, -1, kernel)
        
        # Upscale for better visibility (uses INTER_CUBIC for quality)
        if scale > 1.0:
            new_width = int(display_frame.shape[1] * scale)
            new_height = int(display_frame.shape[0] * scale)
            display_frame = cv2.resize(display_frame, (new_width, new_height), 
                                      interpolation=cv2.INTER_CUBIC)
        
        cv2.imshow(window_name, display_frame)
    
    def check_exit(self, wait_time=1):
        """
        Check if exit command has been issued (q key pressed)
        
        Args:
            wait_time (int): Time to wait for key press in milliseconds
        
        Returns:
            bool: True if exit requested, False otherwise
        """
        key = cv2.waitKey(wait_time) & 0xFF
        return key == ord('q')
    
    def preprocess_frame(self, frame):
        """
        Preprocess frame for depth estimation or other modules
        
        Args:
            frame (numpy.ndarray): Input frame
        
        Returns:
            numpy.ndarray: Preprocessed frame
        """
        # Placeholder for preprocessing operations
        # Can include normalization, color conversion, etc.
        return frame
    
    def cleanup(self):
        """Release camera and close all windows"""
        print("[INPUT HANDLER] Cleaning up resources...")
        
        if self.camera is not None:
            self.camera.release()
            self.camera = None
        
        if self.stream is not None:
            self.stream.release()
            self.stream = None
        
        cv2.destroyAllWindows()
        self.is_initialized = False
        
        print("[INPUT HANDLER] Cleanup complete.")
    
    def get_camera_info(self):
        """
        Get current camera properties
        
        Returns:
            dict: Dictionary containing camera properties
        """
        if not self.is_initialized:
            return None
        
        if self.use_raspberry_pi:
            info = {
                'source': 'raspberry_pi',
                'stream_url': self.stream_url,
                'width': self.width,
                'height': self.height,
                'fps': 30  # Pi camera default
            }
        else:
            info = {
                'source': 'local_webcam',
                'width': int(self.camera.get(cv2.CAP_PROP_FRAME_WIDTH)),
                'height': int(self.camera.get(cv2.CAP_PROP_FRAME_HEIGHT)),
                'fps': int(self.camera.get(cv2.CAP_PROP_FPS)),
                'backend': self.camera.getBackendName()
            }
        
        return info
    
    def switch_to_raspberry_pi(self, raspberry_pi_ip):
        """
        Switch from local camera to Raspberry Pi camera stream
        
        Args:
            raspberry_pi_ip (str): IP address of Raspberry Pi
        
        Returns:
            bool: True if switch successful
        """
        print(f"[INPUT HANDLER] Switching to Raspberry Pi camera at {raspberry_pi_ip}")
        
        # Cleanup current camera
        if self.camera is not None:
            self.camera.release()
            self.camera = None
        
        # Update settings
        self.use_raspberry_pi = True
        self.raspberry_pi_ip = raspberry_pi_ip
        self.stream_url = f"http://{raspberry_pi_ip}:5000/video_feed"
        self.is_initialized = False
        
        # Initialize Pi stream
        return self._initialize_pi_stream()
    
    def switch_to_local_camera(self, camera_id=0):
        """
        Switch from Raspberry Pi stream to local camera
        
        Args:
            camera_id (int): Camera device ID
        
        Returns:
            bool: True if switch successful
        """
        print(f"[INPUT HANDLER] Switching to local camera {camera_id}")
        
        # Cleanup current stream
        if self.stream is not None:
            self.stream.release()
            self.stream = None
        
        # Update settings
        self.use_raspberry_pi = False
        self.camera_id = camera_id
        self.is_initialized = False
        
        # Initialize local camera
        return self._initialize_local_camera()
