"""
LIDAR_VIEW_TEST.py
Test and visualize the LIDAR view priority-based voting algorithm
"""

import cv2
from InputHandler import InputHandler
from DepthEstimationHandler import DepthEstimationHandler


def test_lidar_view():
    """Test the LIDAR view generation"""
    print("="*60)
    print("LIDAR VIEW - Priority-Based Voting Test")
    print("="*60)
    
    # Initialize handlers
    input_handler = InputHandler(width=320, height=240)
    depth_handler = DepthEstimationHandler(model_type="depth-anything")
    
    # Load depth model
    print("\n[TEST] Loading depth estimation model...")
    if not depth_handler.load_model():
        print("[ERROR] Failed to load depth model!")
        return
    
    # Initialize camera
    print("[TEST] Initializing camera...")
    if not input_handler.initialize():
        print("[ERROR] Failed to initialize camera!")
        return
    
    print("\n[TEST] Camera ready. Press 'q' to quit, 'p' to print LIDAR view\n")
    
    try:
        while True:
            # Get frame
            frame = input_handler.get_frame(mirror=True)
            if frame is None:
                break
            
            # Process depth
            depth_result = depth_handler.estimate_depth(frame, output_size=(900, 500))
            
            if depth_result is not None:
                lidar_view = depth_result['lidar_view']
                
                # Display depth map
                cv2.imshow("Depth Analysis", depth_result['depth_colored'])
                
                # Print LIDAR view on 'p' key
                key = cv2.waitKey(1) & 0xFF
                if key == ord('p'):
                    print("\n" + "="*60)
                    print("RAW LIDAR VIEW (rows c-i, columns 1-10):")
                    print("="*60)
                    print(lidar_view['raw_string'])
                    
                    print("\n" + "="*60)
                    print("CORRECTED LIDAR VIEW (after priority voting):")
                    print("="*60)
                    print(lidar_view['corrected_string'])
                    
                    # Show statistics
                    raw_obstacles = sum(sum(1 for cell in row if cell) 
                                       for row in lidar_view['raw_array'])
                    corrected_obstacles = sum(sum(1 for cell in row if cell) 
                                             for row in lidar_view['corrected_array'])
                    
                    print("\n" + "="*60)
                    print(f"Raw obstacles: {raw_obstacles}/70 cells")
                    print(f"Corrected obstacles: {corrected_obstacles}/70 cells")
                    print(f"Correction delta: {corrected_obstacles - raw_obstacles:+d}")
                    print("="*60 + "\n")
                
                elif key == ord('q'):
                    break
    
    except KeyboardInterrupt:
        print("\n[TEST] Interrupted")
    
    finally:
        input_handler.cleanup()
        print("[TEST] Test complete")


if __name__ == "__main__":
    test_lidar_view()
