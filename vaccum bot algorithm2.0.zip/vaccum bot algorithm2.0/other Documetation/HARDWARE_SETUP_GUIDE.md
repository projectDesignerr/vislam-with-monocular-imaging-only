# 🤖 Hardware Setup & Integration Guide

## System Architecture Complete! ✅

```
Camera → Python AI Brain → Hard_Linker → Raspberry Pi HTTP Server → Arduino Mega → Motors
```

---

## 📋 Component Checklist

### ✅ Software Components
- [x] **InputHandler.py** - Camera input
- [x] **DepthEstimationHandler.py** - Vision & obstacle detection
- [x] **ObstacleAvoidanceHandler.py** - Decision making
- [x] **PathExplorerHandler.py** - Path planning
- [x] **OdometryHandler.py** - Position tracking & mapping
- [x] **Hard_Linker.py** - Hardware communication ⭐ NEW!
- [x] **MAIN.py** - System orchestrator (updated with AUTO mode)
- [x] **Raspberrypi_input_server.py** - HTTP server for Pi
- [x] **arduino_mega_slave.ino** - Arduino motor controller

### 🔌 Hardware Components Needed
- [ ] Raspberry Pi (any model with GPIO)
- [ ] Arduino Mega 2560
- [ ] Motor Shield (AF Motor compatible)
- [ ] 2x DC Motors
- [ ] Webcam (USB or Pi Camera)
- [ ] Power supply for motors
- [ ] Jumper wires for serial connection

---

## 🔧 Hardware Wiring

### Raspberry Pi ↔ Arduino Connection
```
Raspberry Pi          Arduino Mega
-----------          ------------
GPIO 14 (TX) ------> Pin 19 (RX1)
GPIO 15 (RX) <------ Pin 18 (TX1)
GND          ------> GND
```

**⚠️ Important:** 
- Use logic level converter (3.3V ↔ 5V) for safe operation
- Common ground is REQUIRED

### Motors → Arduino Connection
- Motor 1 → Motor Shield Port M1
- Motor 2 → Motor Shield Port M4
- Power supply → Motor Shield power input

---

## 📦 Software Installation

### 1. Raspberry Pi Setup

```bash
# Install dependencies
sudo apt-get update
sudo apt-get install python3-pip

# Install Python packages
pip3 install flask pyserial

# Enable UART serial
sudo raspi-config
# Navigate to: Interface Options → Serial Port
# Login shell over serial: NO
# Serial port hardware enabled: YES

# Upload server code
# Copy Raspberrypi_input_server.py to Pi
scp Raspberrypi_input_server.py pi@192.168.1.100:~/

# Run server
sudo python3 Raspberrypi_input_server.py
```

### 2. Arduino Setup

```bash
# Install Arduino IDE
# Install AFMotor library (Adafruit Motor Shield)

# Upload arduino_mega_slave.ino to Arduino Mega
# Tools → Board → Arduino Mega 2560
# Tools → Port → Select correct COM port
# Click Upload
```

### 3. PC/Laptop Setup (Brain)

```bash
# Install Python dependencies
pip install opencv-python numpy torch transformers pillow pygame requests

# Configure Raspberry Pi IP in Hard_Linker.py
# Edit line 16: raspberry_pi_ip="192.168.1.100"  # Change to your Pi's IP
```

---

## 🚀 Running the System

### Step 1: Start Raspberry Pi Server
```bash
# On Raspberry Pi
sudo python3 Raspberrypi_input_server.py

# You should see:
# [INFO] Serial port /dev/serial0 initialized successfully
# [INFO] Using GPIO 14 (TXD) and GPIO 15 (RXD) for UART communication
# Server starting on http://0.0.0.0:5000
```

### Step 2: Power Arduino & Connect
```bash
# 1. Upload arduino_mega_slave.ino
# 2. Connect RX/TX wires to Raspberry Pi
# 3. Power on Arduino
# 4. Motors should be in RELEASE (stopped) state
```

### Step 3: Find Raspberry Pi IP Address
```bash
# On Raspberry Pi
hostname -I

# Output example: 192.168.1.100
# Update this IP in Hard_Linker.py
```

### Step 4: Run Main System
```bash
# On PC/Laptop
python MAIN.py

# System will:
# 1. Load depth estimation model
# 2. Initialize camera
# 3. Test connection to Raspberry Pi
# 4. Start vision & navigation loop
```

---

## 🎮 Controls

### Keyboard Commands (in OpenCV windows):
- **A** - Toggle AUTO mode (robot executes avoidance automatically)
- **E** - Emergency stop (stops motors immediately)
- **R** - Toggle path randomizer (exploration mode)
- **Q** - Quit program
- **WASD/Arrows** - Manual movement (keyboard odometry mode)

### Odometry Window Buttons:
- **Explorer ON/OFF** - Toggle path randomizer
- **Save** - Save obstacle map to JSON
- **Load** - Load obstacle map from JSON

---

## 🔍 Testing Hardware Connection

### Test 1: Raspberry Pi Server
```bash
# From PC, test HTTP server
curl http://192.168.1.100:5000/status

# Expected response:
# {"status":"online","serial_connection":"connected",...}
```

### Test 2: Send Test Command
```bash
# Test forward movement (500ms)
curl -X POST http://192.168.1.100:5000/send \
  -H "Content-Type: application/json" \
  -d '{"data": "f,500}"}'

# Motors should move forward for 500ms then stop
```

### Test 3: Python Hard_Linker
```bash
# Run standalone test
python Hard_Linker.py

# This will:
# 1. Test connection to Raspberry Pi
# 2. Send series of test commands
# 3. Display command history
```

---

## 🧠 How AUTO Mode Works

When **AUTO mode** is enabled (press 'A'):

1. **Vision System** captures camera frame
2. **Depth Estimation** analyzes obstacles (10x10 grid)
3. **LIDAR View** extracts forward-looking data
4. **Obstacle Avoidance** decides direction:
   - CENTER blocked → Turn randomly (left/right)
   - LEFT blocked → Turn RIGHT
   - RIGHT blocked → Turn LEFT
   - All clear → Move FORWARD
5. **Environment Analysis** adjusts speed:
   - Clear path → 1000ms (fast)
   - Some obstacles → 500ms (medium)
   - Dense obstacles → 300ms (slow)
6. **Hard_Linker** sends command to Raspberry Pi
7. **Raspberry Pi** forwards to Arduino via serial
8. **Arduino** executes motor command
9. **Loop continues** at ~30 FPS

---

## 📊 Command Format

### Python → Raspberry Pi (HTTP POST):
```json
{
  "data": "f,1000}"
}
```

### Raspberry Pi → Arduino (Serial UART):
```
f,1000}
```

### Arduino Command Structure:
- `f` - Forward
- `b` - Backward
- `l` - Left turn
- `r` - Right turn
- `s` - Stop
- `,` - Separator
- `1000` - Duration (milliseconds)
- `}` - End marker

---

## 🐛 Troubleshooting

### Issue: "Connection failed" to Raspberry Pi
**Solution:**
1. Check IP address in `Hard_Linker.py`
2. Verify Pi is on same network
3. Test with: `ping 192.168.1.100`
4. Check firewall settings

### Issue: Motors don't move
**Solution:**
1. Check Arduino serial monitor for received commands
2. Verify TX/RX wiring (TX→RX, RX→TX)
3. Check common ground connection
4. Verify motor shield power supply

### Issue: "Serial port not available"
**Solution:**
1. Check UART is enabled: `sudo raspi-config`
2. Verify permissions: `sudo usermod -a -G dialout pi`
3. Check port: `ls -l /dev/serial*`
4. Try alternative ports: `/dev/ttyAMA0` or `/dev/ttyS0`

### Issue: Depth model loading slow
**Solution:**
1. First run downloads model (~200MB)
2. Subsequent runs are faster
3. Consider using CUDA/GPU if available

---

## 🎯 Next Steps

### Phase 1: Testing (Current)
- [x] Verify all connections
- [x] Test individual commands
- [x] Test AUTO mode in controlled environment

### Phase 2: Calibration
- [ ] Adjust movement durations for your motors
- [ ] Calibrate turn angles (may need more/less time)
- [ ] Fine-tune speed profiles based on testing

### Phase 3: Enhancement
- [ ] Add battery monitoring
- [ ] Implement edge detection (to avoid falling)
- [ ] Add distance sensors for backup
- [ ] Implement map-based navigation

### Phase 4: Deployment
- [ ] Test in target environment
- [ ] Add error recovery mechanisms
- [ ] Implement logging system
- [ ] Create start/stop scripts

---

## 📝 Configuration Tips

### Adjust Movement Speed
Edit `Hard_Linker.py` lines 23-26:
```python
self.DURATION_MAX_SPEED = 1000      # Increase for faster movement
self.DURATION_MEDIUM_SPEED = 500    # Balance speed/safety
self.DURATION_SLOW_SPEED = 300      # Very cautious movement
self.DURATION_TURN = 800            # 90° turn duration
```

### Adjust Turn Sensitivity
Edit `ObstacleAvoidanceHandler.py` line 27:
```python
self.trigger_threshold = 2  # How many zones must detect obstacle
```

### Adjust Vision Grid
Edit `DepthEstimationHandler.py` lines 22-23:
```python
self.grid_rows = 10  # Vertical resolution
self.grid_cols = 10  # Horizontal resolution
```

---

## 🎊 System is Ready!

The gap has been filled! Your vacuum bot now has:
- ✅ Eyes (Camera + Depth Estimation)
- ✅ Brain (Obstacle Avoidance + Path Planning)
- ✅ Nervous System (Hard_Linker)
- ✅ Muscles (Motors via Arduino)

**Press 'A' and watch it come to life!** 🚀
