# 🚀 Unified Server - Quick Setup Guide

## What is This?

**One script that does EVERYTHING on Raspberry Pi:**
- ✅ Camera streaming (30 FPS, 320x240)
- ✅ Serial communication with Arduino
- ✅ HTTP API for commands
- ✅ Beautiful web interface

**File:** `unified_raspberry_pi_server.py`

---

## 📦 Installation on Raspberry Pi

```bash
# 1. Install dependencies
sudo apt-get update
sudo apt-get install python3-pip

# 2. Install Python packages
pip3 install flask pyserial

# 3. Enable UART serial
sudo raspi-config
# Navigate to: Interface Options → Serial Port
# - Login shell over serial: NO
# - Serial port hardware enabled: YES
# Reboot if needed

# 4. Copy the unified server to Raspberry Pi
scp unified_raspberry_pi_server.py pi@192.168.1.100:~/

# 5. Make it executable
chmod +x unified_raspberry_pi_server.py
```

---

## 🚀 Running the Server

### Method 1: Direct Run
```bash
sudo python3 unified_raspberry_pi_server.py
```

### Method 2: Run in Background
```bash
# Start in background
sudo nohup python3 unified_raspberry_pi_server.py > server.log 2>&1 &

# Check if running
ps aux | grep unified_raspberry

# Stop server
sudo pkill -f unified_raspberry_pi_server.py
```

### Method 3: Auto-start on Boot
```bash
# Create systemd service
sudo nano /etc/systemd/system/vacuumbot.service

# Paste this:
[Unit]
Description=Vacuum Bot Unified Server
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/home/pi
ExecStart=/usr/bin/python3 /home/pi/unified_raspberry_pi_server.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target

# Save and exit (Ctrl+X, Y, Enter)

# Enable and start service
sudo systemctl daemon-reload
sudo systemctl enable vacuumbot.service
sudo systemctl start vacuumbot.service

# Check status
sudo systemctl status vacuumbot.service

# View logs
sudo journalctl -u vacuumbot.service -f
```

---

## 🌐 Accessing the Server

### Web Interface (Beautiful GUI)
```
http://192.168.1.100:5000/
```
- Live camera feed
- System information
- Status indicators

### Camera Stream Only
```
http://192.168.1.100:5000/video_feed
```

### Single Image Capture
```
http://192.168.1.100:5000/single_image
```

### System Status (JSON)
```
http://192.168.1.100:5000/status
```

---

## 🎮 API Usage Examples

### 1. Send Command to Arduino
```bash
# Move forward for 1000ms
curl -X POST http://192.168.1.100:5000/send \
  -H "Content-Type: application/json" \
  -d '{"data": "f,1000}"}'

# Turn left for 800ms
curl -X POST http://192.168.1.100:5000/send \
  -H "Content-Type: application/json" \
  -d '{"data": "l,800}"}'

# Stop
curl -X POST http://192.168.1.100:5000/send \
  -H "Content-Type: application/json" \
  -d '{"data": "s,0}"}'
```

### 2. Read from Arduino
```bash
curl http://192.168.1.100:5000/read
```

### 3. Check Status
```bash
curl http://192.168.1.100:5000/status | python3 -m json.tool
```

---

## 🔧 Hardware Connections

### Raspberry Pi → Arduino
```
Raspberry Pi GPIO 14 (TX)  →  Arduino Mega Pin 19 (RX1)
Raspberry Pi GPIO 15 (RX)  →  Arduino Mega Pin 18 (TX1)
Raspberry Pi GND           →  Arduino Mega GND
```

### Camera
- Connect Raspberry Pi Camera Module v2/v3
- Or compatible CSI camera

---

## 🐛 Troubleshooting

### Camera Not Working
```bash
# Check if camera detected
vcgencmd get_camera

# Should show: supported=1 detected=1

# Test camera manually
rpicam-vid --help

# If not found, update system
sudo apt update
sudo apt full-upgrade
```

### Serial Port Issues
```bash
# Check available ports
ls -l /dev/serial*
ls -l /dev/ttyAMA*
ls -l /dev/ttyS*

# Try alternative ports in code
# Edit line 66: SERIAL_PORT = '/dev/ttyAMA0'  # or '/dev/ttyS0'

# Check permissions
sudo usermod -a -G dialout pi
```

### Can't Connect to Server
```bash
# Find Raspberry Pi IP
hostname -I

# Check if server running
ps aux | grep unified_raspberry

# Check firewall
sudo ufw status
sudo ufw allow 5000
```

### High CPU Usage
```bash
# Check CPU usage
top

# If too high, reduce camera FPS
# Edit line 234: camera = CameraStreamer(width=320, height=240, fps=15)
```

---

## 📊 Server Logs

### View Live Logs
```bash
# If running directly
# Logs appear in terminal

# If running as service
sudo journalctl -u vacuumbot.service -f

# If using nohup
tail -f server.log
```

### Log Messages
```
✓ Serial port initialized
✓ Camera streaming started
→ Arduino: f,1000}   (sent to Arduino)
← Arduino: OK        (received from Arduino)
Camera: 29.8 FPS     (camera performance)
```

---

## 🎯 Integration with PC/Laptop

### Update Hard_Linker.py
```python
# Change line if Raspberry Pi IP is different
linker = HardLinker(raspberry_pi_ip="192.168.1.100")
```

### Test Connection from PC
```python
import requests

# Test status
response = requests.get('http://192.168.1.100:5000/status')
print(response.json())

# Send command
response = requests.post(
    'http://192.168.1.100:5000/send',
    json={'data': 'f,1000}'}
)
print(response.json())
```

---

## 🔄 What Changed?

### Before (2 separate scripts):
1. `simple_camera_stream.py` - Port 8000 (camera only)
2. `Raspberrypi_input_server.py` - Port 5000 (serial only)

### After (1 unified script):
1. `unified_raspberry_pi_server.py` - Port 5000 (camera + serial)

### Benefits:
- ✅ Single process to manage
- ✅ Unified web interface
- ✅ Easier deployment
- ✅ Lower resource usage
- ✅ One port to configure

---

## 📝 Configuration Options

### Change Camera Resolution/FPS
Edit line 234:
```python
camera = CameraStreamer(width=640, height=480, fps=15)
```

### Change Server Port
Edit line 580:
```python
app.run(host='0.0.0.0', port=8000, threaded=True, debug=False)
```

### Change Serial Port
Edit line 66:
```python
SERIAL_PORT = '/dev/ttyAMA0'  # or '/dev/ttyS0'
```

### Change Baud Rate
Edit line 67:
```python
BAUD_RATE = 115200  # Faster communication
```

---

## ✅ Verification Checklist

- [ ] Raspberry Pi camera working: `rpicam-vid --help`
- [ ] Serial port enabled in raspi-config
- [ ] Dependencies installed: `flask`, `pyserial`
- [ ] Arduino connected to GPIO 14/15 + GND
- [ ] Server starts without errors
- [ ] Web interface accessible at port 5000
- [ ] Camera stream visible in browser
- [ ] Commands sent successfully to Arduino
- [ ] Motors respond to commands

---

## 🎊 Quick Test

```bash
# 1. Start server on Raspberry Pi
sudo python3 unified_raspberry_pi_server.py

# 2. Open browser on PC/laptop
http://192.168.1.100:5000/

# 3. You should see:
#    - Live camera feed
#    - System status cards
#    - Green pulsing indicator

# 4. Test command from PC
curl -X POST http://192.168.1.100:5000/send \
  -H "Content-Type: application/json" \
  -d '{"data": "f,500}"}'

# 5. Check Arduino Serial Monitor
# Should show: "Command: f | Duration: 500ms"
```

---

## 🚀 You're Ready!

The unified server combines camera streaming and motor control into one powerful system. Just run this **one script** on your Raspberry Pi and everything works! 🎉
