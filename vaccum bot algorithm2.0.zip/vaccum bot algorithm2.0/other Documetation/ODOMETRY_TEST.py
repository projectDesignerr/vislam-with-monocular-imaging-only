"""
ODOMETRY_TEST.py
Standalone test for the Odometry Handler module
"""

from OdometryHandler import OdometryHandler
import time


def test_odometry():
    """Test the odometry handler independently"""
    print("="*60)
    print("ODOMETRY HANDLER - Standalone Test")
    print("="*60)
    
    # Create odometry handler
    odometry = OdometryHandler(grid_size=20, cell_size=30, use_keyboard=True)
    
    # Initialize
    if not odometry.initialize():
        print("[ERROR] Failed to initialize odometry!")
        return
    
    print("\n[TEST] Odometry window opened")
    print("[TEST] Use WASD or Arrow keys to move the robot")
    print("[TEST] Close the window or press Ctrl+C to exit\n")
    
    # Main test loop
    try:
        running = True
        while running:
            # Update odometry
            data = odometry.update()
            
            if data is None:
                print("\n[TEST] Window closed")
                running = False
                break
            
            # Print odometry data every second
            time.sleep(0.033)  # ~30 FPS
    
    except KeyboardInterrupt:
        print("\n[TEST] Keyboard interrupt")
    
    finally:
        odometry.cleanup()
        print("[TEST] Test complete")


if __name__ == "__main__":
    test_odometry()
