"""
ODOMETRY_USAGE_GUIDE.md

# Odometry Handler - Usage Guide

## Overview
The OdometryHandler module provides visual odometry tracking with a 20x20 grid display.
It can operate in two modes: KEYBOARD (experimental/R&D) or SENSOR (external data).

## Features
- **20x20 Grid Display**: Visual representation of robot movement
- **Origin Marker**: Red dot at center (10, 10) marking starting position
- **Robot Position**: Green circle showing current robot location
- **Direction Indicator**: Yellow line showing robot heading
- **Trajectory Path**: Blue line showing movement history
- **Dual Input Modes**: Keyboard (testing) or Sensor (production)

## Grid System
- Grid Size: 20x20 cells
- Origin: Center at (10, 10) - marked with RED DOT
- Robot: GREEN CIRCLE with YELLOW direction indicator
- Trajectory: BLUE LINE showing path history

## Keyboard Controls (when use_keyboard=True)
- **W / UP Arrow**: Move forward
- **S / DOWN Arrow**: Move backward
- **A / LEFT Arrow**: Rotate left (counter-clockwise)
- **D / RIGHT Arrow**: Rotate right (clockwise)

## Usage in MAIN.py

```python
from OdometryHandler import OdometryHandler

# Initialize with keyboard control (R&D mode)
odometry = OdometryHandler(grid_size=20, cell_size=30, use_keyboard=True)
odometry.initialize()

# Main loop
while running:
    # Update and get odometry data
    odometry_data = odometry.update()
    
    if odometry_data is None:
        break  # Window closed
    
    # Access odometry data
    x = odometry_data['x']
    y = odometry_data['y']
    angle = odometry_data['angle']
    distance_from_origin = odometry_data['distance_from_origin']

# Cleanup
odometry.cleanup()
```

## Odometry Data Structure

```python
odometry_data = {
    'x': 10.5,                    # Current X position
    'y': 9.8,                     # Current Y position
    'angle': 45.0,                # Current heading (degrees)
    'origin_x': 10,               # Origin X
    'origin_y': 10,               # Origin Y
    'dx': 0.5,                    # Displacement from origin (X)
    'dy': -0.2,                   # Displacement from origin (Y)
    'distance_from_origin': 0.54, # Euclidean distance from origin
    'trajectory_length': 120      # Number of trajectory points
}
```

## Configuration Variables

### use_keyboard (bool)
- **True**: Use keyboard for input (experimental/R&D mode)
- **False**: Use external sensors (production mode)

```python
# Create with keyboard control
odometry = OdometryHandler(use_keyboard=True)

# Switch to sensor mode later
odometry.toggle_input_mode()
```

## External Sensor Mode (use_keyboard=False)

When `use_keyboard=False`, use external sensors for odometry:

```python
# Initialize in sensor mode
odometry = OdometryHandler(use_keyboard=False)
odometry.initialize()

# In your sensor processing loop
def process_sensor_data(left_encoder, right_encoder, imu_heading):
    # Calculate position from sensors
    x, y, angle = calculate_position(left_encoder, right_encoder, imu_heading)
    
    # Update odometry with sensor data
    odometry.set_external_odometry(x=x, y=y, angle=angle)
    
    # Update display
    odometry_data = odometry.update()
```

## Methods

### Core Methods
- `initialize()`: Initialize pygame window
- `update()`: Update odometry and render display (returns odometry_data)
- `cleanup()`: Close window and cleanup resources

### Movement Methods (Keyboard Mode)
- `_move_forward()`: Move forward
- `_move_backward()`: Move backward
- `_rotate_left()`: Rotate counter-clockwise
- `_rotate_right()`: Rotate clockwise

### Data Methods
- `get_odometry_data()`: Get current position and stats
- `reset_position()`: Reset robot to origin
- `set_external_odometry(x, y, angle)`: Set position from sensors
- `toggle_input_mode()`: Switch between keyboard and sensor modes

## Integration with Other Modules

### With Navigation Module
```python
# Get odometry data for navigation decisions
odometry_data = odometry.update()

if odometry_data['distance_from_origin'] > 15:
    print("[NAV] Robot too far from origin, returning home")
```

### With Depth Estimation
```python
# Combine depth and odometry for obstacle mapping
depth_result = depth_handler.estimate_depth(frame)
odometry_data = odometry.update()

# Map obstacles at current position
map_obstacles_at_position(
    depth_result['cell_states'],
    odometry_data['x'],
    odometry_data['y'],
    odometry_data['angle']
)
```

### With Path Planning
```python
# Use odometry for path tracking
odometry_data = odometry.update()
current_pos = (odometry_data['x'], odometry_data['y'])

# Check if on planned path
if is_on_path(current_pos, planned_path):
    continue_forward()
else:
    recalculate_path()
```

## Future Enhancements (Sensor Mode)

When implementing sensor-based odometry:

1. **Encoder Integration**
   - Left wheel encoder
   - Right wheel encoder
   - Calculate dead reckoning

2. **IMU Integration**
   - Gyroscope for heading
   - Accelerometer for movement
   - Magnetometer for absolute heading

3. **Sensor Fusion**
   - Combine encoder + IMU data
   - Kalman filter for accuracy
   - Drift correction

## Display Colors

- **Background**: Dark gray (30, 30, 30)
- **Grid Lines**: Gray (60, 60, 60)
- **Origin**: Red (255, 0, 0)
- **Robot**: Green (0, 255, 0)
- **Direction**: Yellow (255, 255, 0)
- **Trajectory**: Light blue (100, 100, 255)
- **Text**: White (255, 255, 255)

## Testing

Run standalone test:
```powershell
python ODOMETRY_TEST.py
```

Run full system:
```powershell
python MAIN.py
```

## Troubleshooting

**Issue**: Window doesn't open
- Check pygame installation: `pip install pygame`

**Issue**: Robot moves too fast/slow
- Adjust `move_step` parameter (default: 0.5)
- Adjust `rotation_step` parameter (default: 15)

**Issue**: Trajectory not showing
- Trajectory has max length of 1000 points
- Will automatically trim old points

**Issue**: Robot goes off grid
- Position is clamped to grid bounds (0 to grid_size-1)
- Reset position with `reset_position()`
"""
