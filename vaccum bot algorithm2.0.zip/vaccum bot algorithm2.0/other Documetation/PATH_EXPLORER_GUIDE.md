"""
PATH EXPLORER MODULE - Quick Guide

# Features Implemented

## 1. Map Save/Load (Odometry GUI)
**Controls:**
- Press **'S'** in odometry window → Save map to `obstacle_map.json`
- Press **'L'** in odometry window → Load map from `obstacle_map.json`

**What's Saved:**
- Obstacle map (all red/blue cells)
- Robot position
- Origin position
- Map size

**File Format:** JSON (human-readable)

---

## 2. Path Explorer - Random Destination Generation

### Algorithm
1. **Imaginary Semicircle**: 10cm radius (1.0 grid units) in front of robot
2. **Random Point**: Generated on semicircle (-90° to +90° from robot heading)
3. **Straight Line Path**: Green dotted line from robot to destination
4. **Obstacle Detection**: If red block appears on path → regenerate new destination
5. **Auto-Randomize**: Continues until randomizer disabled

### Controls
**Press 'R'** (in camera/depth window) → Toggle randomizer ON/OFF

### Visual Elements in Odometry Window
- 🟢 **Green dotted line** = Path to destination
- 🟢 **Green circle with white outline** = Destination point
- 🟥 **Red cells** = Obstacles (will block path)
- 🟦 **Blue cells** = Clear areas

### How It Works

**Step 1: Enable Randomizer**
```
Press 'R' → Randomizer ENABLED
System generates random point on semicircle ahead
```

**Step 2: Path Generation**
```
Random angle: -90° to +90° from robot heading
Point on semicircle: (x, y) at 10cm distance
Straight line drawn with waypoints every 0.5 units
Green dotted line appears
```

**Step 3: Obstacle Check**
```
Every frame checks if path crosses red cells
If obstacle detected → Path blocked!
If randomizer ON → Generate new destination automatically
```

**Step 4: Destination Reached**
```
When robot within 0.5 units of destination
Mark as reached
If randomizer ON → Generate new destination
If randomizer OFF → Stop
```

### Example Usage

**Manual Exploration:**
```
1. Run python MAIN.py
2. Move robot with WASD/Arrows
3. Press 'R' to enable randomizer
4. Green dotted line appears showing destination
5. If path blocked → new destination auto-generated
6. Press 'R' again to disable
```

**Map Building:**
```
1. Enable randomizer
2. Let it generate random destinations
3. Move manually toward green dotted line
4. Build up obstacle map (red/blue cells)
5. Press 'S' to save map
```

**Load Previous Session:**
```
1. Run python MAIN.py
2. Press 'L' in odometry window
3. Map loads (red/blue cells appear)
4. Press 'R' to start exploring
```

---

## Complete Controls Summary

### Main System
- **Q** = Quit (in camera/depth window)
- **R** = Toggle path randomizer ON/OFF

### Odometry Window
- **S** = Save obstacle map to JSON
- **L** = Load obstacle map from JSON
- **WASD/Arrows** = Manual robot control

### Keyboard Mode (Testing)
- **W/↑** = Move forward
- **S/↓** = Move backward
- **A/←** = Rotate left
- **D/→** = Rotate right

---

## Technical Details

### Semicircle Generation
```python
# Random angle on semicircle
random_angle_offset = random.uniform(-90, 90)
absolute_angle = robot_angle + random_angle_offset

# Calculate point
dest_x = robot_x + radius * sin(angle)
dest_y = robot_y - radius * cos(angle)
```

### Path Collision Detection
```python
# Check each waypoint
for point in path_points:
    grid_pos = round(point)
    if obstacle_map[grid_pos] == True:
        path_blocked = True
        regenerate_destination()
```

### Destination Reached Check
```python
distance = sqrt((robot_x - dest_x)² + (robot_y - dest_y)²)
if distance < 0.5:
    destination_reached = True
```

---

## Example Scenarios

### Scenario 1: Free Exploration
```
1. Enable randomizer (R)
2. Robot generates destination ahead
3. Path is clear (no red blocks)
4. Move toward destination manually
5. Reach destination → new one generates
```

### Scenario 2: Obstacle Avoidance
```
1. Enable randomizer (R)
2. Destination generated
3. Red block appears on green path
4. System detects collision
5. New destination auto-generated
6. Process repeats
```

### Scenario 3: Map Persistence
```
Session 1:
- Explore area
- Build obstacle map
- Press 'S' to save
- Exit

Session 2:
- Run MAIN.py
- Press 'L' to load
- Previous obstacles appear
- Continue exploring
```

---

## Future Enhancements

- [ ] Multiple destination candidates (choose best)
- [ ] Smooth paths (curves instead of straight lines)
- [ ] Priority zones (prefer unexplored areas)
- [ ] Coverage optimization
- [ ] Return-to-origin command
- [ ] Waypoint navigation (multiple destinations)
"""
