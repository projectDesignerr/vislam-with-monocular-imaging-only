# 🔌 Dual Serial Arduino - Testing Guide

## What Changed?

**Arduino Mega now accepts commands from BOTH serial ports:**

1. **Serial (USB)** - Direct PC connection via USB cable
2. **Serial1 (GPIO)** - Raspberry Pi connection via GPIO 14/15

---

## 🎯 Benefits

- ✅ Test motors directly from PC (USB) without Raspberry Pi
- ✅ Receive commands from Raspberry Pi (GPIO) during deployment
- ✅ Debug messages on USB while Pi sends commands
- ✅ No need to disconnect anything - both work simultaneously

---

## 🔧 Hardware Connections

### USB Connection (Serial):
```
Arduino Mega → PC via USB cable
```
- Used for: Direct testing, debugging
- Port: Serial (Serial Monitor on PC)

### Raspberry Pi Connection (Serial1):
```
Arduino Mega Pin 19 (RX1) ← Raspberry Pi GPIO 14 (TX)
Arduino Mega Pin 18 (TX1) → Raspberry Pi GPIO 15 (RX)
GND → GND
```
- Used for: Real robot operation
- Port: Serial1 (UART on pins 18/19)

---

## 🧪 Testing Methods

### Method 1: Test via USB (Direct PC Control)

```bash
# 1. Upload arduino_mega_slave.ino to Arduino
# 2. Open Serial Monitor (Tools → Serial Monitor)
# 3. Set baud rate to 9600
# 4. Set line ending to "No line ending" or "Newline"
# 5. Type commands:

f,1000}     # Forward for 1000ms
b,500}      # Backward for 500ms
l,800}      # Left turn for 800ms
r,800}      # Right turn for 800ms
s,0}        # Stop
```

**Output in Serial Monitor:**
```
Arduino Mega Motor Controller Ready
Listening on both Serial (USB) and Serial1 (Raspberry Pi)
[USB] Command: f | Duration: 1000ms
[USB] Moving FORWARD
[USB] Movement complete, motors stopped
```

---

### Method 2: Test via Raspberry Pi (Robot Control)

```bash
# On Raspberry Pi
curl -X POST http://localhost:5000/send \
  -H "Content-Type: application/json" \
  -d '{"data": "f,1000}"}'
```

**Output in Arduino Serial Monitor (via USB):**
```
[Pi] Command: f | Duration: 1000ms
[Pi] Moving FORWARD
[Pi] Movement complete, motors stopped
```

---

### Method 3: Simultaneous Testing

```bash
# Watch Serial Monitor while Pi sends commands
# You'll see:
# - [USB] for commands from PC
# - [Pi] for commands from Raspberry Pi
# - Both work at the same time!
```

---

## 📋 Command Format

### Format:
```
command,duration}
```

### Commands:
| Command | Action | Example |
|---------|--------|---------|
| `f,duration}` | Forward | `f,1000}` |
| `b,duration}` | Backward | `b,500}` |
| `l,duration}` | Left turn | `l,800}` |
| `r,duration}` | Right turn | `r,800}` |
| `s,0}` | Stop | `s,0}` |

### Important:
- ✅ Must end with `}`
- ✅ Format: `command,time}`
- ✅ No spaces
- ✅ Stop doesn't need duration but include `,0`

---

## 🔍 How It Works

### Code Flow:
```cpp
loop() {
    // Listen on Serial (USB)
    if (Serial.available()) {
        Read character → Build commandBuffer
        If '}' found → commandComplete = true
    }
    
    // Listen on Serial1 (Raspberry Pi)
    if (Serial1.available()) {
        Read character → Build commandBuffer1
        If '}' found → commandComplete1 = true
    }
    
    // Process USB command
    if (commandComplete) {
        Print "[USB]"
        Execute command
    }
    
    // Process Pi command
    if (commandComplete1) {
        Print "[Pi]"
        Execute command
    }
}
```

---

## 🧪 Test Sequence

### Full System Test:

```bash
# Step 1: Upload Arduino code
# Use Arduino IDE to upload arduino_mega_slave.ino

# Step 2: Open Serial Monitor (USB)
# Tools → Serial Monitor
# Baud: 9600

# Step 3: Test via USB
# Type in Serial Monitor:
f,500}
# Should see: [USB] Moving FORWARD

# Step 4: Start Pi server
ssh pi@192.168.1.100
sudo python3 unified_raspberry_pi_server.py

# Step 5: Test via Raspberry Pi
curl -X POST http://192.168.1.100:5000/send \
  -H "Content-Type: application/json" \
  -d '{"data": "f,500}"}'

# Step 6: Watch Serial Monitor
# Should see: [Pi] Moving FORWARD

# Step 7: Test both simultaneously
# - Type command in Serial Monitor
# - Send curl command from PC
# - Both work! USB shows [USB] and [Pi] tags
```

---

## 🎮 Arduino IDE Serial Monitor Commands

### Quick Test Commands:
```
f,1000}    ← Forward 1 second
l,800}     ← Turn left 0.8 seconds
r,800}     ← Turn right 0.8 seconds
b,500}     ← Backward 0.5 seconds
s,0}       ← Stop immediately
```

### Test Motor Balance:
```bash
# Send same command to both motors
f,2000}    # If robot curves, motors are unbalanced
l,1000}    # Adjust motor speeds in code if needed
r,1000}    # Compare left vs right turn times
```

---

## 🐛 Troubleshooting

### Issue: No response from USB commands

**Check:**
1. Serial Monitor open?
2. Correct COM port selected?
3. Baud rate = 9600?
4. Command ends with `}`?

**Solution:**
```bash
# In Serial Monitor, verify connection:
# Should see startup message:
# "Arduino Mega Motor Controller Ready"
```

---

### Issue: No response from Pi commands

**Check:**
1. Pi connected to pins 18/19?
2. Common ground connected?
3. Pi server running?
4. Correct serial port in Pi code?

**Solution:**
```bash
# Check Pi serial port
ls -l /dev/serial*

# Test with curl
curl -X POST http://192.168.1.100:5000/send \
  -H "Content-Type: application/json" \
  -d '{"data": "f,100}"}'
```

---

### Issue: Motors not moving

**Check:**
1. Motor shield powered?
2. Motor wires connected?
3. Motor shield jumper set?
4. Battery/power supply connected?

**Solution:**
```bash
# Test motor shield:
# - LED should light up when powered
# - Check voltage on power terminal
# - Verify motors connected to M1 and M4
```

---

## 📊 Output Examples

### Successful USB Command:
```
[USB] Command: f | Duration: 1000ms
[USB] Moving FORWARD
[USB] Movement complete, motors stopped
```

### Successful Pi Command:
```
[Pi] Command: l | Duration: 800ms
[Pi] Turning LEFT
[Pi] Movement complete, motors stopped
```

### Error (Invalid Format):
```
Error: Invalid command format
```

### Error (Unknown Command):
```
Error: Unknown command
```

---

## 💡 Pro Tips

### 1. Monitor While Deploying:
```bash
# Keep USB connected while testing Pi commands
# You can see exactly what Arduino receives from Pi
# Great for debugging!
```

### 2. Quick Motor Test:
```bash
# In Serial Monitor, rapid fire test:
f,500}
b,500}
l,500}
r,500}
s,0}
```

### 3. Calibration:
```bash
# Test turn timing:
l,1000}   # Should turn ~90 degrees
# Adjust DURATION_TURN in Hard_Linker.py accordingly
```

---

## ✅ Verification Checklist

- [ ] Arduino code uploaded successfully
- [ ] Serial Monitor shows startup message
- [ ] USB commands work (type `f,500}` → motors move)
- [ ] Raspberry Pi connected to pins 18/19 + GND
- [ ] Pi server running on port 5000
- [ ] Pi commands work (curl test → motors move)
- [ ] Serial Monitor shows `[USB]` and `[Pi]` tags correctly

---

## 🎊 Ready!

Your Arduino now accepts commands from:
- 💻 **PC via USB** - Direct testing and debugging
- 🤖 **Raspberry Pi via GPIO** - Real robot operation

**Both work simultaneously - test from either source!** 🚀
