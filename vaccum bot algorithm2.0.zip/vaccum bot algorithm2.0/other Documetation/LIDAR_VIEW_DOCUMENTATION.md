"""
LIDAR_VIEW_DOCUMENTATION.md

# LIDAR View - Priority-Based Voting Algorithm

## Overview
The LIDAR View is a refined obstacle detection output that uses priority-based voting to reduce noise and provide more reliable obstacle data for navigation.

## Input Data
- **Grid Size**: 10x10 cells (rows a-j, columns 1-10)
- **Extracted Region**: Rows c-i, Columns 1-10
- **Data Size**: 7x10 array (7 rows × 10 columns)

## Why Rows c-i?
Rows c-i represent the **critical forward-looking zone** for navigation:
- **Row a-b**: Top rows (far distance, less reliable)
- **Row c-i**: Mid-range zone (optimal for obstacle detection)
- **Row j**: Bottom row (very close, might be ground/too close)

## Algorithm Steps

### Step 1: Extract Raw Data
Extract rows **c, d, e, f, g, h, i** (indices 2-8) with all columns (1-10)

Example raw data:
```
     1  2  3  4  5  6  7  8  9 10
c    T  T  T  T  F  F  F  F  F  F
d    F  T  F  T  T  F  T  F  F  F
e    F  F  T  T  F  T  F  F  T  F
f    F  T  T  T  T  F  F  T  F  F
g    T  F  F  T  F  F  T  F  F  T
h    F  T  T  T  F  T  F  F  F  F
i    F  F  F  T  F  F  F  T  F  F
```

### Step 2: Assign Priorities
- **T (Obstacle detected)** = Priority 2
- **F (Clear/Safe)** = Priority 1

### Step 3: Column-wise Voting
For each column, count occurrences and calculate priority scores:

**Example - Column 1:**
```
Values: T, F, F, F, T, F, F
T count: 2 → Priority: 2 × 2 = 4
F count: 5 → Priority: 5 × 1 = 5
Winner: F (priority 5 > 4)
Result: F
```

**Example - Column 2:**
```
Values: T, T, F, T, F, T, F
T count: 4 → Priority: 4 × 2 = 8
F count: 3 → Priority: 3 × 1 = 3
Winner: T (priority 8 > 3)
Result: T
```

### Step 4: Generate Corrected Array
Apply voting to all columns, creating corrected 7×10 array where all cells in same column have the same value (the winner).

Corrected data (after voting):
```
     1  2  3  4  5  6  7  8  9 10
c    F  T  T  T  F  F  F  F  F  F
d    F  T  T  T  F  F  F  F  F  F
e    F  T  T  T  F  F  F  F  F  F
f    F  T  T  T  F  F  F  F  F  F
g    F  T  T  T  F  F  F  F  F  F
h    F  T  T  T  F  F  F  F  F  F
i    F  T  T  T  F  F  F  F  F  F
```

## Benefits

### 1. Noise Reduction
- Eliminates sporadic false detections
- Smooths out temporary glitches
- More stable readings

### 2. Column Consistency
- All cells in same column have same state
- Represents vertical obstacle zones
- Easier for navigation decisions

### 3. Priority Weighting
- Obstacles (T) have higher priority (2x weight)
- Conservative approach: prefers detecting obstacles
- Safer navigation

### 4. Simplified Navigation
Instead of analyzing 70 individual cells, analyze 10 vertical zones

## Data Structure

```python
lidar_view = {
    'raw_array': [[True, False, ...], ...],      # Original 7x10
    'corrected_array': [[True, True, ...], ...], # After voting 7x10
    'raw_string': "formatted text",               # Pretty print
    'corrected_string': "formatted text",         # Pretty print
    'rows': ['c', 'd', 'e', 'f', 'g', 'h', 'i'],
    'columns': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
}
```

## Usage in Navigation

### Example 1: Simple Obstacle Check
```python
lidar_view = depth_result['lidar_view']
corrected = lidar_view['corrected_array']

# Check if any column has obstacle
for col_idx in range(10):
    has_obstacle = corrected[0][col_idx]  # All rows same, check any
    if has_obstacle:
        print(f"Column {col_idx+1} has obstacle")
```

### Example 2: Find Clear Path
```python
# Find leftmost clear column
for col_idx in range(10):
    if not corrected[0][col_idx]:
        print(f"Clear path at column {col_idx+1}")
        break
```

### Example 3: Count Obstacle Zones
```python
obstacle_columns = sum(1 for col in range(10) if corrected[0][col])
clear_columns = 10 - obstacle_columns

if clear_columns >= 5:
    print("Wide path available")
elif clear_columns >= 3:
    print("Narrow path available")
else:
    print("Path blocked, need to turn")
```

## Comparison: Raw vs LIDAR View

### Raw Grid (10x10)
- 100 cells to analyze
- Noisy, inconsistent
- Hard to make decisions
- Individual cell variations

### LIDAR View (7x10 → 10 columns)
- 10 vertical zones
- Filtered, consistent
- Easy decision making
- Column-wise voting

## Testing

Run standalone test:
```powershell
python LIDAR_VIEW_TEST.py
```

Controls:
- Press **'p'** to print LIDAR view
- Press **'q'** to quit

Output shows:
1. Raw LIDAR view (original data)
2. Corrected LIDAR view (after voting)
3. Statistics (obstacle counts before/after)

## Mathematical Formula

For each column `c`:

```
T_count = number of True in column c
F_count = number of False in column c

T_priority = T_count × 2
F_priority = F_count × 1

if T_priority > F_priority:
    corrected[all_rows][c] = True
else:
    corrected[all_rows][c] = False
```

## Integration Example

```python
# In navigation module
depth_result = depth_handler.estimate_depth(frame)
lidar_view = depth_result['lidar_view']
corrected = lidar_view['corrected_array']

# Simple 10-zone obstacle detection
obstacles = [corrected[0][col] for col in range(10)]

# Left side (columns 1-3)
left_clear = not any(obstacles[0:3])

# Center (columns 4-7)
center_clear = not any(obstacles[3:7])

# Right side (columns 8-10)
right_clear = not any(obstacles[7:10])

# Navigation decision
if center_clear:
    move_forward()
elif left_clear:
    turn_left()
elif right_clear:
    turn_right()
else:
    turn_around()
```

## Future Enhancements

- [ ] Temporal filtering (average over multiple frames)
- [ ] Weighted by row (closer rows = higher priority)
- [ ] Adaptive thresholds based on environment
- [ ] Integration with path planning
- [ ] Visual overlay showing LIDAR zones
"""
