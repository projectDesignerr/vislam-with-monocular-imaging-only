# 🎥 Dual Camera Mode - Usage Guide

## What's New?

**InputHandler.py** now supports **TWO modes**:

1. 🖥️ **Local Webcam Mode** (Default)
   - Uses laptop/PC webcam
   - Perfect for development and testing

2. 🤖 **Raspberry Pi Camera Mode** (New!)
   - Streams from Raspberry Pi camera
   - Real robot deployment mode

---

## 🚀 How to Use

### Mode 1: Local Webcam (Development/Testing)

```bash
# Just run as before - uses local webcam
python MAIN.py
```

**Use this when:**
- ✅ Developing algorithm on PC
- ✅ Testing without Raspberry Pi
- ✅ No robot hardware available

---

### Mode 2: Raspberry Pi Camera (Real Robot)

```bash
# Use Raspberry Pi camera stream
python MAIN.py --pi-camera --pi-ip 192.168.1.100
```

**Use this when:**
- ✅ Raspberry Pi server is running
- ✅ Ready for real robot deployment
- ✅ Want to see robot's perspective

---

## 📋 Command Line Arguments

### Full Options:
```bash
python MAIN.py [OPTIONS]

Options:
  --pi-camera          Use Raspberry Pi camera instead of local webcam
  --pi-ip IP_ADDRESS   Raspberry Pi IP address (default: 192.168.1.100)
  -h, --help           Show help message
```

### Examples:

```bash
# Example 1: Local webcam (default)
python MAIN.py

# Example 2: Pi camera with default IP
python MAIN.py --pi-camera

# Example 3: Pi camera with custom IP
python MAIN.py --pi-camera --pi-ip 192.168.1.50

# Example 4: Show help
python MAIN.py --help
```

---

## 🔧 Setup Requirements

### For Local Webcam Mode:
```bash
# No special setup needed
# Just have a webcam connected
python MAIN.py
```

### For Raspberry Pi Camera Mode:
```bash
# 1. Start unified server on Raspberry Pi
ssh pi@192.168.1.100
sudo python3 unified_raspberry_pi_server.py

# 2. Verify camera stream in browser
# Open: http://192.168.1.100:5000/

# 3. Run MAIN.py with --pi-camera flag
python MAIN.py --pi-camera --pi-ip 192.168.1.100
```

---

## 🎯 Automatic Features

### Camera Source Detection:
The system automatically:
- ✅ Connects to correct camera source
- ✅ Tests connection before starting
- ✅ Shows connection status
- ✅ Auto-reconnects if stream drops

### Display Information:
```
[MAIN] Initializing Autonomous Navigation System...
[MAIN] Camera source: Raspberry Pi
[MAIN] Raspberry Pi IP: 192.168.1.100
[INPUT HANDLER] Configured for Raspberry Pi stream: http://192.168.1.100:5000/video_feed
[INPUT HANDLER] Connecting to Raspberry Pi camera stream...
[INPUT HANDLER] ✓ Connected to Raspberry Pi camera
```

---

## 🔄 Dynamic Switching (Advanced)

You can switch camera sources at runtime:

```python
# In your code, switch to Pi camera
nav_system.input_handler.switch_to_raspberry_pi("192.168.1.100")

# Or switch back to local camera
nav_system.input_handler.switch_to_local_camera(camera_id=0)
```

---

## 🐛 Troubleshooting

### Issue: "Cannot connect to Pi camera"

**Check:**
1. Is Raspberry Pi server running?
   ```bash
   ssh pi@192.168.1.100
   ps aux | grep unified_raspberry
   ```

2. Can you access camera in browser?
   ```
   http://192.168.1.100:5000/
   ```

3. Is IP address correct?
   ```bash
   # Find Pi IP
   ssh pi@192.168.1.100
   hostname -I
   ```

4. Network connectivity?
   ```bash
   ping 192.168.1.100
   ```

**Solution:**
```bash
# Restart Pi server
ssh pi@192.168.1.100
sudo pkill -f unified_raspberry
sudo python3 unified_raspberry_pi_server.py
```

---

### Issue: "Failed to read Pi camera frame"

**Possible causes:**
- Network lag/packet loss
- Pi camera not functioning
- Stream interrupted

**Solution:**
- System will auto-reconnect
- Check Pi camera: `rpicam-vid --help`
- Check network bandwidth

---

### Issue: Local webcam not working

**Check:**
1. Is webcam connected?
2. Is it being used by another program?
3. Try different camera ID:
   ```python
   # In InputHandler initialization
   self.input_handler = InputHandler(camera_id=1)  # Try 1 or 2
   ```

---

## 📊 Performance Comparison

| Metric | Local Webcam | Pi Camera Stream |
|--------|--------------|------------------|
| Latency | ~30ms | ~100-200ms |
| Quality | Depends on webcam | 320x240 @ 30 FPS |
| Reliability | Very High | High (network dependent) |
| Use Case | Development | Real Deployment |

---

## 🎮 Full Workflow Examples

### Workflow 1: Development on PC
```bash
# Step 1: Develop on PC with local webcam
python MAIN.py

# Step 2: Test algorithms
# Press 'A' for AUTO mode
# Press 'R' for path randomizer
# Test obstacle avoidance

# Step 3: Fine-tune parameters
# Edit Hard_Linker.py, ObstacleAvoidanceHandler.py, etc.
```

---

### Workflow 2: Deploy to Real Robot
```bash
# Step 1: Start Pi server
ssh pi@192.168.1.100
sudo python3 unified_raspberry_pi_server.py

# Step 2: Run system with Pi camera (on PC)
python MAIN.py --pi-camera --pi-ip 192.168.1.100

# Step 3: Enable AUTO mode
# Press 'A' to start autonomous navigation

# Step 4: Monitor
# Watch robot navigate using its own camera!
# Commands sent to motors automatically
```

---

### Workflow 3: Hybrid Testing
```bash
# Test with local camera first
python MAIN.py

# If everything works, switch to Pi camera
python MAIN.py --pi-camera --pi-ip 192.168.1.100

# Compare behavior between local and Pi camera
```

---

## 🔍 Code Changes Summary

### InputHandler.py Changes:

1. **New Parameters:**
   ```python
   InputHandler(
       width=320, 
       height=240, 
       use_raspberry_pi=False,    # NEW!
       raspberry_pi_ip=None        # NEW!
   )
   ```

2. **New Methods:**
   - `_initialize_local_camera()` - Local webcam setup
   - `_initialize_pi_stream()` - Pi stream setup
   - `_get_local_frame()` - Get frame from webcam
   - `_get_pi_frame()` - Get frame from Pi stream
   - `switch_to_raspberry_pi()` - Dynamic switching
   - `switch_to_local_camera()` - Dynamic switching

3. **Auto-reconnection:**
   - If Pi stream drops, automatically reconnects
   - No manual intervention needed

---

### MAIN.py Changes:

1. **New Constructor Parameters:**
   ```python
   AutonomousNavigationSystem(
       use_raspberry_pi_camera=False,    # NEW!
       raspberry_pi_ip="192.168.1.100"   # NEW!
   )
   ```

2. **Command Line Arguments:**
   ```bash
   --pi-camera    # Enable Pi camera
   --pi-ip        # Set Pi IP address
   ```

3. **Automatic Configuration:**
   - Reads command line args
   - Configures InputHandler automatically
   - Displays current mode

---

## 🎊 Benefits

### For Development:
- ✅ Test on PC without robot
- ✅ Fast iteration
- ✅ No hardware dependencies
- ✅ Same code works for both modes

### For Deployment:
- ✅ Real robot perspective
- ✅ Test actual camera quality
- ✅ Validate in real environment
- ✅ Seamless transition from dev to production

---

## 📝 Quick Reference

### Start Commands:

```bash
# Local webcam (development)
python MAIN.py

# Pi camera (deployment)
python MAIN.py --pi-camera --pi-ip 192.168.1.100

# Show help
python MAIN.py -h
```

### Runtime Controls:

| Key | Action |
|-----|--------|
| A | Toggle AUTO mode |
| E | Emergency stop |
| R | Toggle path randomizer |
| Q | Quit program |
| WASD | Manual movement (keyboard mode) |

---

## ✅ Migration Checklist

If you have existing code:

- [x] **InputHandler.py** - Updated with dual mode support
- [x] **MAIN.py** - Updated with command line args
- [x] **Hard_Linker.py** - Already compatible
- [x] **unified_raspberry_pi_server.py** - Provides camera stream
- [ ] Update your custom scripts if they use InputHandler directly

---

## 🚀 You're Ready!

Your system now supports both local and remote cameras! 

**Development:** Use local webcam
**Deployment:** Use Raspberry Pi camera

Same code, different perspectives! 🎥🤖
