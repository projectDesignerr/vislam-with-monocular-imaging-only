"""
DATA_SHARING_EXAMPLE.py
Example showing how to access and use cell state data from the depth estimation module
"""

# Example of cell_states dictionary structure returned by DepthEstimationHandler
# This is what you get from depth_result['cell_states']

"""
cell_states = {
    'a1': True,   # Row a, Column 1 - Obstacle detected
    'a2': False,  # Row a, Column 2 - Clear/Safe
    'a3': False,
    'a4': True,
    'a5': False,
    'a6': False,
    'a7': True,
    'a8': False,
    'a9': False,
    'a10': False,
    'b1': False,  # Row b, Column 1
    'b2': True,   # Row b, Column 2 - Obstacle
    # ... continues for all rows (a-j) and columns (1-10)
    'j1': False,
    'j2': False,
    # ... up to j10
}

Cell Naming Convention:
- Rows: a, b, c, d, e, f, g, h, i, j (top to bottom)
- Cols: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 (left to right)

Cell States:
- True  = Obstacle detected (RED zone)
- False = Clear/Safe (GREEN or PINK zone)
"""


# ============================================
# HOW TO USE IN OTHER MODULES
# ============================================

def example_navigation_decision(depth_result):
    """
    Example: How a navigation module would use cell states
    """
    if depth_result is None:
        return None
    
    cell_states = depth_result['cell_states']
    analysis = depth_result['analysis']
    
    # Example 1: Check specific cells
    if cell_states['e5']:  # Center cell
        print("[NAV] Obstacle in center!")
    
    # Example 2: Check a row
    row_d_obstacles = [cell_states[f'd{i}'] for i in range(1, 11)]
    if any(row_d_obstacles):
        print("[NAV] Obstacles in row d")
    
    # Example 3: Check left side (columns 1-5)
    left_side_clear = all(not cell_states[f'{row}{col}'] 
                          for row in ['a','b','c','d','e'] 
                          for col in range(1, 6))
    if left_side_clear:
        print("[NAV] Left side is clear!")
    
    # Example 4: Use helper methods
    from DepthEstimationHandler import DepthEstimationHandler
    depth_handler = DepthEstimationHandler()
    
    obstacle_cells = depth_handler.get_obstacle_cells(cell_states)
    safe_cells = depth_handler.get_safe_cells(cell_states)
    
    print(f"[NAV] Obstacle cells: {obstacle_cells}")
    print(f"[NAV] Safe cells: {len(safe_cells)} total")
    
    # Example 5: Use analysis statistics
    if analysis['left_red_count'] > 6:
        print("[NAV] Turn RIGHT - left obstacle detected")
    elif analysis['right_red_count'] > 6:
        print("[NAV] Turn LEFT - right obstacle detected")
    elif analysis['green_count'] > 20:
        print("[NAV] FORWARD - path is clear")
    
    return "decision_made"


def example_path_planning(cell_states):
    """
    Example: How a path planning module would use cell states
    """
    # Create a simple 2D map
    grid_map = []
    rows = ['a','b','c','d','e','f','g','h','i','j']
    
    for row in rows:
        row_data = []
        for col in range(1, 11):
            cell_name = f"{row}{col}"
            row_data.append(1 if cell_states[cell_name] else 0)  # 1=obstacle, 0=free
        grid_map.append(row_data)
    
    print("[PATH] Grid map created:")
    for i, row_data in enumerate(grid_map):
        print(f"[PATH] Row {rows[i]}: {row_data}")
    
    return grid_map


def example_mapping_module(cell_states, timestamp):
    """
    Example: How a mapping module would log cell states over time
    """
    # Store cell states with timestamp for mapping
    map_entry = {
        'timestamp': timestamp,
        'obstacles': [cell for cell, state in cell_states.items() if state],
        'safe_zones': [cell for cell, state in cell_states.items() if not state]
    }
    
    print(f"[MAP] Logged {len(map_entry['obstacles'])} obstacles at time {timestamp}")
    
    return map_entry


# ============================================
# QUICK REFERENCE
# ============================================
"""
# In any module, access cell states like this:

# Get depth result from main
depth_result = depth_handler.estimate_depth(frame)

# Access cell states
cell_states = depth_result['cell_states']

# Check individual cells
if cell_states['a1']:  # True if obstacle
    print("Obstacle at a1")

# Check multiple cells
front_clear = not any([cell_states['d4'], cell_states['d5'], cell_states['d6']])

# Get list of all obstacle cells
obstacle_list = [cell for cell, state in cell_states.items() if state]

# Or use helper methods
from DepthEstimationHandler import DepthEstimationHandler
depth_handler = DepthEstimationHandler()
obstacles = depth_handler.get_obstacle_cells(cell_states)
safe = depth_handler.get_safe_cells(cell_states)
"""
