"""
ObstacleAvoidanceHandler.py
Handles real-time obstacle avoidance decisions based on LIDAR data
Uses zone-based detection to determine safe movement directions
"""

import random


class ObstacleAvoidanceHandler:
    def __init__(self):
        """
        Initialize the Obstacle Avoidance Handler
        LIDAR zones: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        Left zones: 0, 1, 2
        Center zones: 3, 4, 5
        Right zones: 6, 7, 8
        """
        self.left_zones = [0, 1, 2]
        self.center_zones = [3, 4, 5]
        self.right_zones = [6, 7, 8]
        
        # Decision thresholds
        self.trigger_threshold = 2  # At least 2 zones must detect obstacle
        
        # Current avoidance state
        self.avoidance_active = False
        self.avoidance_direction = None  # 'left', 'right', or None
        self.obstacle_detected = {
            'left': False,
            'center': False,
            'right': False
        }
        
        print("[OBSTACLE AVOIDANCE] Initialized")
        print(f"[OBSTACLE AVOIDANCE] Left zones: {self.left_zones}")
        print(f"[OBSTACLE AVOIDANCE] Center zones: {self.center_zones}")
        print(f"[OBSTACLE AVOIDANCE] Right zones: {self.right_zones}")
        print(f"[OBSTACLE AVOIDANCE] Trigger threshold: {self.trigger_threshold} zones")
    
    def analyze_lidar(self, lidar_array):
        """
        Analyze LIDAR data and detect obstacles in left, center, right zones
        
        Args:
            lidar_array (list): List of 10 boolean values [T/F for each zone]
        
        Returns:
            dict: Obstacle detection results
        """
        if not lidar_array or len(lidar_array) != 10:
            print("[OBSTACLE AVOIDANCE] Invalid LIDAR data")
            return self.obstacle_detected
        
        # Count obstacles in each region
        left_count = sum(1 for i in self.left_zones if lidar_array[i])
        center_count = sum(1 for i in self.center_zones if lidar_array[i])
        right_count = sum(1 for i in self.right_zones if lidar_array[i])
        
        # Determine if obstacles detected (at least 2 zones must trigger)
        self.obstacle_detected['left'] = left_count >= self.trigger_threshold
        self.obstacle_detected['center'] = center_count >= self.trigger_threshold
        self.obstacle_detected['right'] = right_count >= self.trigger_threshold
        
        return self.obstacle_detected
    
    def decide_direction(self, obstacle_detected=None):
        """
        Decide avoidance direction based on obstacle locations
        
        Logic:
        - If LEFT blocked (zones 0,1,2): Turn RIGHT
        - If RIGHT blocked (zones 6,7,8): Turn LEFT
        - If CENTER blocked (zones 3,4,5): Turn randomly LEFT or RIGHT
        - If multiple regions blocked: Prioritize avoiding center, then random
        
        Args:
            obstacle_detected (dict): Optional pre-analyzed obstacle data
        
        Returns:
            str: Direction to turn ('left', 'right', 'forward', or 'stop')
        """
        if obstacle_detected is None:
            obstacle_detected = self.obstacle_detected
        
        left_blocked = obstacle_detected['left']
        center_blocked = obstacle_detected['center']
        right_blocked = obstacle_detected['right']
        
        # Print detection status
        status = []
        if left_blocked:
            status.append("LEFT")
        if center_blocked:
            status.append("CENTER")
        if right_blocked:
            status.append("RIGHT")
        
        if status:
            print(f"[OBSTACLE AVOIDANCE] Obstacles detected in: {', '.join(status)}")
        
        # Decision logic
        # Priority 1: Center blocked - must turn
        if center_blocked:
            self.avoidance_active = True
            # If center blocked, choose random direction unless one side is clear
            if not left_blocked and not right_blocked:
                # Both sides clear, random choice
                self.avoidance_direction = random.choice(['left', 'right'])
            elif not left_blocked:
                # Left is clear
                self.avoidance_direction = 'left'
            elif not right_blocked:
                # Right is clear
                self.avoidance_direction = 'right'
            else:
                # All blocked - stop or reverse
                self.avoidance_direction = 'stop'
            
            print(f"[OBSTACLE AVOIDANCE] CENTER blocked → Turn {self.avoidance_direction.upper()}")
            return self.avoidance_direction
        
        # Priority 2: Left blocked - turn right
        if left_blocked:
            self.avoidance_active = True
            self.avoidance_direction = 'right'
            print(f"[OBSTACLE AVOIDANCE] LEFT blocked → Turn RIGHT")
            return 'right'
        
        # Priority 3: Right blocked - turn left
        if right_blocked:
            self.avoidance_active = True
            self.avoidance_direction = 'left'
            print(f"[OBSTACLE AVOIDANCE] RIGHT blocked → Turn LEFT")
            return 'left'
        
        # No obstacles detected - safe to move forward
        self.avoidance_active = False
        self.avoidance_direction = None
        return 'forward'
    
    def update(self, lidar_array):
        """
        Main update function - analyze LIDAR and decide direction
        
        Args:
            lidar_array (list): List of 10 boolean values from LIDAR
        
        Returns:
            dict: Complete avoidance state with decision
        """
        # Analyze LIDAR data
        obstacle_detected = self.analyze_lidar(lidar_array)
        
        # Decide direction
        direction = self.decide_direction(obstacle_detected)
        
        # Return complete state
        return {
            'direction': direction,
            'avoidance_active': self.avoidance_active,
            'obstacle_detected': obstacle_detected.copy(),
            'avoidance_direction': self.avoidance_direction
        }
    
    def get_state(self):
        """
        Get current avoidance state
        
        Returns:
            dict: Current state information
        """
        return {
            'avoidance_active': self.avoidance_active,
            'avoidance_direction': self.avoidance_direction,
            'obstacle_detected': self.obstacle_detected.copy()
        }
    
    def reset(self):
        """Reset avoidance state"""
        self.avoidance_active = False
        self.avoidance_direction = None
        self.obstacle_detected = {
            'left': False,
            'center': False,
            'right': False
        }
        print("[OBSTACLE AVOIDANCE] State reset")
