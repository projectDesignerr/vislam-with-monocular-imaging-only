"""
PathExplorerHandler.py
Simple kinematic memory-based exploration system
Robot rotates to random direction → moves forward until obstacle → turns 45° using memory → repeat
"""

import random
import time


class PathExplorerHandler:
    def __init__(self):
        """
        Initialize the Simple Kinematic Memory-based Explorer
        
        States:
        - ROTATING: Pick random heading (0-360°)
        - ALIGNING: Rotate to target until within threshold
        - MOVING: Move forward until obstacle detected
        - TURNING: Turn 45° using kinematic memory
        """
        # Exploration control
        self.exploration_enabled = False
        
        # State machine
        self.exploration_state = 'rotating'  # 'rotating', 'aligning', 'moving', 'turning'
        self.target_heading = None  # Target angle to align to (0-360°)
        self.alignment_threshold = 10.0  # Degrees threshold for alignment
        
        # Kinematic memory
        self.last_turn_direction = 'right'  # Memory: 'left' or 'right' (alternates)
        
        print(f"[PATH EXPLORER] Kinematic Memory-based Explorer initialized")
        print(f"[PATH EXPLORER] Alignment threshold: {self.alignment_threshold}°")
    
    def toggle_exploration(self):
        """Toggle exploration on/off"""
        self.exploration_enabled = not self.exploration_enabled
        state = "ENABLED" if self.exploration_enabled else "DISABLED"
        print(f"\n[PATH EXPLORER] ========================================")
        print(f"[PATH EXPLORER] Kinematic Exploration {state}")
        print(f"[PATH EXPLORER] ========================================")
        
        if self.exploration_enabled:
            # Start with random rotation
            self.exploration_state = 'rotating'
            print(f"[PATH EXPLORER] Starting kinematic exploration...")
        else:
            # Reset state when disabled
            self.reset_exploration()
    
    def reset_exploration(self):
        """Reset exploration state to initial conditions"""
        self.exploration_state = 'rotating'
        self.target_heading = None
        print(f"[PATH EXPLORER] Exploration state reset")
    
    def execute_kinematic_exploration(self, current_heading, avoidance_state, hard_linker):
        """
        Execute simple kinematic memory-based exploration
        
        Logic:
        1. ROTATING: Pick random heading (0-360°), start aligning
        2. ALIGNING: Rotate toward target until within 10° threshold
        3. MOVING: Move forward until obstacle detected
        4. TURNING: Turn 45° using kinematic memory, then back to ROTATING
        
        Args:
            current_heading (float): Current robot heading in degrees
            avoidance_state (dict): Obstacle avoidance state
            hard_linker: Hardware communication object
        
        Returns:
            tuple: (success, duration_ms) or (False, 0) if exploration not active
        """
        if not self.exploration_enabled:
            return False, 0
        
        if self.exploration_state == 'rotating':
            # Step 1: Pick random target heading
            self.target_heading = random.uniform(0, 360)
            self.exploration_state = 'aligning'
            print(f"\n[PATH EXPLORER] KINEMATIC: New target heading {self.target_heading:.1f}°")
            return False, 0  # Will align next cycle
        
        elif self.exploration_state == 'aligning':
            # Step 2: Align to target heading
            if self.target_heading is None:
                self.exploration_state = 'rotating'
                return False, 0
            
            # Calculate angle difference
            angle_diff = (self.target_heading - current_heading + 360) % 360
            if angle_diff > 180:
                angle_diff -= 360
            
            if abs(angle_diff) <= self.alignment_threshold:
                # Aligned! Start moving forward
                self.exploration_state = 'moving'
                print(f"\n[PATH EXPLORER] KINEMATIC: Aligned ({abs(angle_diff):.1f}°)! Moving forward")
                # Execute forward movement (use medium speed for exploration)
                cmd = "f,150}"  # 150ms forward = 5.25cm
                success = hard_linker.send_command(cmd)
                if success:
                    time.sleep(0.35)  # Wait for movement (150ms + buffer)
                return success, 150
            else:
                # Still aligning - rotate toward target
                direction = 'left' if angle_diff > 0 else 'right'
                cmd = f"{direction[0]},300}}"
                print(f"\n[PATH EXPLORER] KINEMATIC: Aligning {direction} ({angle_diff:.1f}°)")
                success = hard_linker.send_command(cmd)
                if success:
                    time.sleep(0.5)  # Wait for rotation
                return success, 300
        
        elif self.exploration_state == 'moving':
            # Step 3: Move forward until obstacle
            if avoidance_state['avoidance_active']:
                # Obstacle detected! Switch to turning
                self.exploration_state = 'turning'
                print(f"\n[PATH EXPLORER] KINEMATIC: Obstacle detected! Turning {self.last_turn_direction}")
                return False, 0  # Will turn next cycle
            else:
                # Path clear - keep moving forward
                print(f"\n[PATH EXPLORER] KINEMATIC: Path clear - moving forward")
                cmd = "f,150}"  # 150ms forward = 5.25cm
                success = hard_linker.send_command(cmd)
                if success:
                    time.sleep(0.35)  # Wait for movement
                return success, 150
        
        elif self.exploration_state == 'turning':
            # Step 4: Turn 45° using kinematic memory (use 450ms for ~45°)
            turn_cmd = f"{self.last_turn_direction[0]},450}}"
            print(f"\n[PATH EXPLORER] KINEMATIC: Turning 45° {self.last_turn_direction} (memory-based)")
            
            # Update kinematic memory (alternate direction for next obstacle)
            self.last_turn_direction = 'left' if self.last_turn_direction == 'right' else 'right'
            
            # Execute turn and go back to rotating
            success = hard_linker.send_command(turn_cmd)
            if success:
                time.sleep(0.7)  # Wait for 45° turn (450ms + buffer)
                self.exploration_state = 'rotating'
                print(f"[PATH EXPLORER] KINEMATIC: Turn complete - selecting new heading")
            return success, 450
        
        return False, 0
    
    def get_exploration_state(self):
        """
        Get current exploration state (for compatibility with odometry display)
        
        Returns:
            dict: Basic exploration state information
        """
        return {
            'exploration_enabled': self.exploration_enabled,
            'exploration_state': self.exploration_state,
            'target_heading': self.target_heading,
            'last_turn_direction': self.last_turn_direction
        }
